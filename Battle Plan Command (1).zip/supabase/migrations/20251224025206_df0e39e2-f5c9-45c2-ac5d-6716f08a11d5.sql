-- Remove the overly permissive "Require authentication for profiles" policy
-- The existing policies "Users can view own profile" and "Admins can view all profiles" 
-- already properly restrict access. Anonymous users are naturally blocked since all
-- existing policies require auth.uid() checks that return FALSE for anonymous requests.

DROP POLICY IF EXISTS "Require authentication for profiles" ON public.profiles;