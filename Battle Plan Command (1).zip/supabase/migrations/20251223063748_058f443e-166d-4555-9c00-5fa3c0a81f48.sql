-- Add going deeper fields to user_visions table
ALTER TABLE public.user_visions 
ADD COLUMN IF NOT EXISTS yearly_theme text,
ADD COLUMN IF NOT EXISTS life_categories jsonb DEFAULT '{}',
ADD COLUMN IF NOT EXISTS body_metrics jsonb DEFAULT '{}',
ADD COLUMN IF NOT EXISTS financial_metrics jsonb DEFAULT '{}',
ADD COLUMN IF NOT EXISTS bucket_list jsonb DEFAULT '[]',
ADD COLUMN IF NOT EXISTS accountability_needs text,
ADD COLUMN IF NOT EXISTS help_needed text;