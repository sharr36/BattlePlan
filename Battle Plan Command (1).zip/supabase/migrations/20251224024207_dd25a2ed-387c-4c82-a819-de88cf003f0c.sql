-- Add restrictive policy to require authentication for accessing team invite codes
-- This ensures anonymous users cannot access the table under any circumstances
CREATE POLICY "Require authentication for invite codes"
ON public.team_invite_codes
AS RESTRICTIVE
FOR ALL
TO public
USING (auth.uid() IS NOT NULL);