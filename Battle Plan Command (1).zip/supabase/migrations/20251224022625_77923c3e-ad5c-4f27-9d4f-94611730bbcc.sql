-- Drop the overly broad restrictive policy
-- The permissive policies already correctly scope access:
-- 1. "Users can view own profile" - only own profile
-- 2. "Admins can view all profiles" - only admins
-- With RLS enabled and no matching permissive policy, access is denied by default
DROP POLICY IF EXISTS "Require authentication for profiles" ON public.profiles;