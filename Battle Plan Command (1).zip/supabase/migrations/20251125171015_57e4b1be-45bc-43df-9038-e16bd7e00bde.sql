-- Fix infinite recursion in team_members RLS policies

-- 1) Create helper functions that bypass RLS safely via SECURITY DEFINER
create or replace function public.is_team_leader_or_xo(_user_id uuid, _team_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.team_members
    where user_id = _user_id
      and team_id = _team_id
      and role = any (array['leader'::app_role, 'xo'::app_role])
      and status = 'active'
  );
$$;

create or replace function public.is_active_team_member(_user_id uuid, _team_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.team_members
    where user_id = _user_id
      and team_id = _team_id
      and status = 'active'
  );
$$;

-- 2) Replace self-referential policies that cause infinite recursion
DROP POLICY IF EXISTS "Leaders can manage team members" ON public.team_members;
DROP POLICY IF EXISTS "Team members can view their team's members" ON public.team_members;

CREATE POLICY "Leaders can manage team members"
ON public.team_members
FOR UPDATE
TO authenticated
USING (public.is_team_leader_or_xo(auth.uid(), team_id));

CREATE POLICY "Team members can view their team's members"
ON public.team_members
FOR SELECT
TO authenticated
USING (public.is_active_team_member(auth.uid(), team_id));