-- Remove the invite_code column from teams table since codes are now 
-- securely managed in the team_invite_codes table with proper RLS

-- First drop all triggers that depend on set_invite_code function
DROP TRIGGER IF EXISTS set_invite_code_before_insert ON public.teams;
DROP TRIGGER IF EXISTS teams_invite_code_trigger ON public.teams;

-- Drop the function (now that triggers are removed)
DROP FUNCTION IF EXISTS public.set_invite_code();

-- Remove the invite_code column from teams table
ALTER TABLE public.teams DROP COLUMN IF EXISTS invite_code;