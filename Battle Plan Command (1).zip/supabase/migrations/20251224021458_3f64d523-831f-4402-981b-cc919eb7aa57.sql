-- Block direct profile creation - profiles are created by handle_new_user trigger (SECURITY DEFINER)
-- This policy explicitly denies INSERT for all users since the trigger bypasses RLS
CREATE POLICY "Block direct profile inserts"
ON public.profiles
FOR INSERT
TO authenticated, anon
WITH CHECK (false);