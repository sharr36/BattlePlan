-- Block anonymous/unauthenticated access to user_visions table
CREATE POLICY "Block anonymous access"
ON public.user_visions
FOR SELECT
TO anon
USING (false);