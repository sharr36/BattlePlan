-- Upgrade the generate_share_token function to create longer, more secure tokens
-- Using 32 characters (alphanumeric + mixed case) provides ~190 bits of entropy
-- This makes enumeration attacks computationally infeasible

CREATE OR REPLACE FUNCTION public.generate_share_token()
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  chars TEXT := 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  result TEXT := '';
  i INTEGER;
BEGIN
  -- Generate 32-character token for ~190 bits of entropy
  -- This makes brute-force enumeration practically impossible
  FOR i IN 1..32 LOOP
    result := result || substr(chars, floor(random() * length(chars) + 1)::int, 1);
  END LOOP;
  RETURN result;
END;
$function$;