-- Create after_action_reviews table for quarterly and yearly reviews
CREATE TABLE public.after_action_reviews (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  team_id UUID NOT NULL REFERENCES public.teams(id) ON DELETE CASCADE,
  review_type TEXT NOT NULL CHECK (review_type IN ('quarterly', 'yearly')),
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  what_went_well TEXT,
  what_could_improve TEXT,
  lessons_learned TEXT,
  action_items JSONB DEFAULT '[]'::jsonb,
  overall_rating INTEGER CHECK (overall_rating >= 1 AND overall_rating <= 5),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.after_action_reviews ENABLE ROW LEVEL SECURITY;

-- Users can view their own reviews
CREATE POLICY "Users can view own reviews"
  ON public.after_action_reviews FOR SELECT
  USING (auth.uid() = user_id);

-- Users can create their own reviews
CREATE POLICY "Users can create own reviews"
  ON public.after_action_reviews FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Users can update their own reviews
CREATE POLICY "Users can update own reviews"
  ON public.after_action_reviews FOR UPDATE
  USING (auth.uid() = user_id);

-- Users can delete their own reviews
CREATE POLICY "Users can delete own reviews"
  ON public.after_action_reviews FOR DELETE
  USING (auth.uid() = user_id);

-- Team members can view team reviews
CREATE POLICY "Team members can view team reviews"
  ON public.after_action_reviews FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM team_members tm
      WHERE tm.team_id = after_action_reviews.team_id
        AND tm.user_id = auth.uid()
        AND tm.status = 'active'
    )
  );

-- Add trigger for updated_at
CREATE TRIGGER update_after_action_reviews_updated_at
  BEFORE UPDATE ON public.after_action_reviews
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();