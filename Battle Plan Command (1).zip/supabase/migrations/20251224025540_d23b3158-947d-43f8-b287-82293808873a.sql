-- Create storage bucket for team logos
INSERT INTO storage.buckets (id, name, public)
VALUES ('team-logos', 'team-logos', true);

-- Allow authenticated users to upload logos for teams they lead
CREATE POLICY "Team leaders can upload logos"
ON storage.objects
FOR INSERT
WITH CHECK (
  bucket_id = 'team-logos' 
  AND auth.uid() IS NOT NULL
  AND is_team_leader_or_xo(auth.uid(), (storage.foldername(name))[1]::uuid)
);

-- Allow team leaders to update/delete their team's logos
CREATE POLICY "Team leaders can update logos"
ON storage.objects
FOR UPDATE
USING (
  bucket_id = 'team-logos'
  AND is_team_leader_or_xo(auth.uid(), (storage.foldername(name))[1]::uuid)
);

CREATE POLICY "Team leaders can delete logos"
ON storage.objects
FOR DELETE
USING (
  bucket_id = 'team-logos'
  AND is_team_leader_or_xo(auth.uid(), (storage.foldername(name))[1]::uuid)
);

-- Allow public read access to team logos
CREATE POLICY "Team logos are publicly accessible"
ON storage.objects
FOR SELECT
USING (bucket_id = 'team-logos');

-- Add logo_url column to teams table
ALTER TABLE public.teams ADD COLUMN logo_url TEXT;