-- Drop the overly permissive policy
DROP POLICY IF EXISTS "Users can view all profiles" ON public.profiles;

-- Create policy: Users can always view their own full profile
CREATE POLICY "Users can view own profile" 
ON public.profiles 
FOR SELECT 
USING (auth.uid() = id);

-- Create policy: Team members can view basic info of teammates (display_name, avatar_url only)
-- This uses a security definer function to check team membership
CREATE OR REPLACE FUNCTION public.is_teammate(_profile_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM team_members tm1
    JOIN team_members tm2 ON tm1.team_id = tm2.team_id
    WHERE tm1.user_id = auth.uid()
      AND tm2.user_id = _profile_id
      AND tm1.status = 'active'
      AND tm2.status = 'active'
  )
$$;

-- Create policy: Teammates can view each other's profiles (for team features)
CREATE POLICY "Team members can view teammate profiles" 
ON public.profiles 
FOR SELECT 
USING (public.is_teammate(id));