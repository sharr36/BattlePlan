-- Create a table to store battle plan drafts
CREATE TABLE public.battle_plan_drafts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  team_id UUID NOT NULL REFERENCES public.teams(id) ON DELETE CASCADE,
  form_data JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add unique constraint so each user has one draft per team
ALTER TABLE public.battle_plan_drafts 
  ADD CONSTRAINT battle_plan_drafts_user_team_unique UNIQUE (user_id, team_id);

-- Enable RLS
ALTER TABLE public.battle_plan_drafts ENABLE ROW LEVEL SECURITY;

-- Users can view their own drafts
CREATE POLICY "Users can view own drafts" 
ON public.battle_plan_drafts 
FOR SELECT 
USING (auth.uid() = user_id);

-- Users can create their own drafts
CREATE POLICY "Users can create own drafts" 
ON public.battle_plan_drafts 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Users can update their own drafts
CREATE POLICY "Users can update own drafts" 
ON public.battle_plan_drafts 
FOR UPDATE 
USING (auth.uid() = user_id);

-- Users can delete their own drafts
CREATE POLICY "Users can delete own drafts" 
ON public.battle_plan_drafts 
FOR DELETE 
USING (auth.uid() = user_id);

-- Add trigger for updated_at
CREATE TRIGGER update_battle_plan_drafts_updated_at
BEFORE UPDATE ON public.battle_plan_drafts
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();