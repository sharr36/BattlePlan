-- Add AI tone preference to profiles table
ALTER TABLE public.profiles 
ADD COLUMN ai_tone_preference text DEFAULT 'motivational';