-- Drop the overly permissive policy that exposes email addresses
DROP POLICY IF EXISTS "Team leaders can view teammate profiles for management" ON public.profiles;

-- Create a secure function that returns only safe profile fields for teammates
CREATE OR REPLACE FUNCTION public.get_team_member_profiles(_team_id uuid)
RETURNS TABLE (
  id uuid,
  display_name text,
  avatar_url text
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT p.id, p.display_name, p.avatar_url
  FROM profiles p
  INNER JOIN team_members tm ON tm.user_id = p.id
  WHERE tm.team_id = _team_id
    AND tm.status = 'active'
    AND EXISTS (
      SELECT 1 FROM team_members caller
      WHERE caller.team_id = _team_id
        AND caller.user_id = auth.uid()
        AND caller.status = 'active'
    );
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION public.get_team_member_profiles(uuid) TO authenticated;

COMMENT ON FUNCTION public.get_team_member_profiles IS 'Returns limited profile info (no email) for team members. Only callable by active team members.';