-- Fix overly permissive comments SELECT policy
-- Drop the existing policy that allows any authenticated user to see all comments
DROP POLICY IF EXISTS "Team members can view comments" ON public.comments;

-- Create a proper policy that restricts comment visibility to team members only
CREATE POLICY "Team members can view team comments"
  ON public.comments FOR SELECT
  USING (
    -- Allow viewing if user is active member of the team associated with the commented post
    CASE post_type
      WHEN 'plan' THEN EXISTS (
        SELECT 1 FROM battle_plans bp
        JOIN team_members tm ON tm.team_id = bp.team_id
        WHERE bp.id = comments.post_id::uuid
          AND tm.user_id = auth.uid()
          AND tm.status = 'active'
      )
      WHEN 'metric' THEN EXISTS (
        SELECT 1 FROM weekly_metrics wm
        JOIN battle_plans bp ON bp.id = wm.plan_id
        JOIN team_members tm ON tm.team_id = bp.team_id
        WHERE wm.id = comments.post_id::uuid
          AND tm.user_id = auth.uid()
          AND tm.status = 'active'
      )
      WHEN 'challenge' THEN EXISTS (
        SELECT 1 FROM challenges c
        JOIN team_members tm ON tm.team_id = c.team_id
        WHERE c.id = comments.post_id::uuid
          AND tm.user_id = auth.uid()
          AND tm.status = 'active'
      )
      ELSE false
    END
  );