-- Add is_admin flag to profiles table for app-level administration
ALTER TABLE public.profiles ADD COLUMN is_admin BOOLEAN DEFAULT false;

-- Create a function to check if user is admin (for RLS policies)
CREATE OR REPLACE FUNCTION public.is_app_admin()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(
    (SELECT is_admin FROM public.profiles WHERE id = auth.uid()),
    false
  )
$$;

-- Update teams RLS to allow admins to view all teams
CREATE POLICY "Admins can view all teams"
  ON public.teams FOR SELECT
  USING (is_app_admin());

-- Allow admins to view all team members
CREATE POLICY "Admins can view all team members"
  ON public.team_members FOR SELECT
  USING (is_app_admin());

-- Allow admins to manage team members
CREATE POLICY "Admins can manage team members"
  ON public.team_members FOR ALL
  USING (is_app_admin());

-- Allow admins to view all profiles
-- (already covered by existing "Users can view all profiles" policy)

COMMENT ON COLUMN public.profiles.is_admin IS 'App-level admin flag for testing and management purposes';