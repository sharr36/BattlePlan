-- Create table for wizard progress persistence
CREATE TABLE public.wizard_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  wizard_type text NOT NULL DEFAULT 'battle_plan',
  current_step_index integer NOT NULL DEFAULT 0,
  collected_data jsonb NOT NULL DEFAULT '{}'::jsonb,
  messages jsonb NOT NULL DEFAULT '[]'::jsonb,
  current_quadrant text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(user_id, wizard_type)
);

-- Enable RLS
ALTER TABLE public.wizard_progress ENABLE ROW LEVEL SECURITY;

-- Users can only access their own wizard progress
CREATE POLICY "Users can view own wizard progress"
ON public.wizard_progress
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own wizard progress"
ON public.wizard_progress
FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own wizard progress"
ON public.wizard_progress
FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own wizard progress"
ON public.wizard_progress
FOR DELETE
USING (auth.uid() = user_id);

-- Add updated_at trigger
CREATE TRIGGER update_wizard_progress_updated_at
BEFORE UPDATE ON public.wizard_progress
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();