-- Add opt-in sharing column for user visions
ALTER TABLE public.user_visions 
ADD COLUMN shared_with_team boolean NOT NULL DEFAULT false;

-- Drop the existing permissive team visibility policy
DROP POLICY IF EXISTS "Team members can view teammate visions" ON public.user_visions;

-- Create new policy that only allows viewing if user explicitly opted in
CREATE POLICY "Team members can view shared visions only"
ON public.user_visions
FOR SELECT
USING (
  (team_id IS NOT NULL) 
  AND (shared_with_team = true)
  AND (EXISTS (
    SELECT 1
    FROM team_members tm
    WHERE tm.team_id = user_visions.team_id
      AND tm.user_id = auth.uid()
      AND tm.status = 'active'
  ))
);

-- Add comment explaining the column
COMMENT ON COLUMN public.user_visions.shared_with_team IS 'When true, team members can view this vision. Default is false for privacy.';