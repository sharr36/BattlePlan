-- Drop the overly permissive "Block anonymous access" policy
-- The existing "Users can view own profile" and "Admins can view all profiles" policies 
-- already properly restrict access and implicitly block anonymous users
DROP POLICY IF EXISTS "Block anonymous access" ON public.profiles;