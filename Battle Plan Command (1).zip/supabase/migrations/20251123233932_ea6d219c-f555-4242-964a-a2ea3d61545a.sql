-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create enum for user roles
CREATE TYPE app_role AS ENUM ('leader', 'xo', 'member');

-- Create enum for quadrant types
CREATE TYPE quadrant_type AS ENUM ('calibration', 'connection', 'condition', 'contribution');

-- Teams table
CREATE TABLE public.teams (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  description TEXT,
  created_by UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  invite_code TEXT UNIQUE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Profiles table (extends auth.users with additional data)
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT,
  email TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Team members junction table
CREATE TABLE public.team_members (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  team_id UUID REFERENCES public.teams(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL DEFAULT 'member',
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'inactive')),
  joined_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(team_id, user_id)
);

-- Battle plans table
CREATE TABLE public.battle_plans (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  team_id UUID REFERENCES public.teams(id) ON DELETE CASCADE NOT NULL,
  vision TEXT NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Quadrant objectives table
CREATE TABLE public.quadrant_objectives (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  plan_id UUID REFERENCES public.battle_plans(id) ON DELETE CASCADE NOT NULL,
  quadrant quadrant_type NOT NULL,
  objective TEXT NOT NULL,
  primary_tactic TEXT NOT NULL,
  secondary_tactics JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(plan_id, quadrant)
);

-- Checkpoints table
CREATE TABLE public.checkpoints (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  plan_id UUID REFERENCES public.battle_plans(id) ON DELETE CASCADE NOT NULL,
  quadrant quadrant_type NOT NULL,
  day_30 TEXT,
  day_60 TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(plan_id, quadrant)
);

-- Daily logs table
CREATE TABLE public.daily_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  team_id UUID REFERENCES public.teams(id) ON DELETE CASCADE NOT NULL,
  log_date DATE NOT NULL,
  non_negotiables JSONB DEFAULT '[]'::jsonb,
  tasks JSONB DEFAULT '[]'::jsonb,
  objectives JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, team_id, log_date)
);

-- Weekly metrics table
CREATE TABLE public.weekly_metrics (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  plan_id UUID REFERENCES public.battle_plans(id) ON DELETE CASCADE NOT NULL,
  week_number INTEGER NOT NULL,
  submission_date TIMESTAMPTZ DEFAULT now(),
  quadrant_data JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, plan_id, week_number)
);

-- Emergency plans table
CREATE TABLE public.emergency_plans (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  team_id UUID REFERENCES public.teams(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  plan_details JSONB NOT NULL,
  activated_at TIMESTAMPTZ,
  deactivated_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Challenges table
CREATE TABLE public.challenges (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  team_id UUID REFERENCES public.teams(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  created_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Comments table
CREATE TABLE public.comments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  post_type TEXT NOT NULL CHECK (post_type IN ('metric', 'plan', 'challenge')),
  post_id UUID NOT NULL,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Function to generate random invite codes
CREATE OR REPLACE FUNCTION generate_invite_code() RETURNS TEXT AS $$
DECLARE
  chars TEXT := 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  result TEXT := '';
  i INTEGER;
BEGIN
  FOR i IN 1..6 LOOP
    result := result || substr(chars, floor(random() * length(chars) + 1)::int, 1);
  END LOOP;
  RETURN result;
END;
$$ LANGUAGE plpgsql;

-- Trigger to auto-generate invite codes
CREATE OR REPLACE FUNCTION set_invite_code() RETURNS TRIGGER AS $$
BEGIN
  IF NEW.invite_code IS NULL THEN
    NEW.invite_code := generate_invite_code();
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER teams_invite_code_trigger
  BEFORE INSERT ON public.teams
  FOR EACH ROW
  EXECUTE FUNCTION set_invite_code();

-- Function to handle new user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, display_name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1))
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Update timestamp triggers
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_teams_updated_at BEFORE UPDATE ON public.teams
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_battle_plans_updated_at BEFORE UPDATE ON public.battle_plans
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_quadrant_objectives_updated_at BEFORE UPDATE ON public.quadrant_objectives
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_checkpoints_updated_at BEFORE UPDATE ON public.checkpoints
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_daily_logs_updated_at BEFORE UPDATE ON public.daily_logs
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_emergency_plans_updated_at BEFORE UPDATE ON public.emergency_plans
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_challenges_updated_at BEFORE UPDATE ON public.challenges
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Enable Row Level Security
ALTER TABLE public.teams ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.team_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.battle_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quadrant_objectives ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.checkpoints ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.daily_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.weekly_metrics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.emergency_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;

-- RLS Policies for profiles
CREATE POLICY "Users can view all profiles"
  ON public.profiles FOR SELECT
  USING (true);

CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

-- RLS Policies for teams
CREATE POLICY "Team members can view their teams"
  ON public.teams FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.team_members
      WHERE team_members.team_id = teams.id
        AND team_members.user_id = auth.uid()
        AND team_members.status = 'active'
    )
  );

CREATE POLICY "Users can create teams"
  ON public.teams FOR INSERT
  WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Team leaders can update their teams"
  ON public.teams FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.team_members
      WHERE team_members.team_id = teams.id
        AND team_members.user_id = auth.uid()
        AND team_members.role IN ('leader', 'xo')
        AND team_members.status = 'active'
    )
  );

-- RLS Policies for team_members
CREATE POLICY "Team members can view their team's members"
  ON public.team_members FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.team_members tm
      WHERE tm.team_id = team_members.team_id
        AND tm.user_id = auth.uid()
        AND tm.status = 'active'
    )
  );

CREATE POLICY "Users can request to join teams"
  ON public.team_members FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Leaders can manage team members"
  ON public.team_members FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.team_members tm
      WHERE tm.team_id = team_members.team_id
        AND tm.user_id = auth.uid()
        AND tm.role IN ('leader', 'xo')
        AND tm.status = 'active'
    )
  );

-- RLS Policies for battle_plans
CREATE POLICY "Team members can view battle plans"
  ON public.battle_plans FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.team_members
      WHERE team_members.team_id = battle_plans.team_id
        AND team_members.user_id = auth.uid()
        AND team_members.status = 'active'
    )
  );

CREATE POLICY "Users can create own battle plans"
  ON public.battle_plans FOR INSERT
  WITH CHECK (
    auth.uid() = user_id
    AND EXISTS (
      SELECT 1 FROM public.team_members
      WHERE team_members.team_id = battle_plans.team_id
        AND team_members.user_id = auth.uid()
        AND team_members.status = 'active'
    )
  );

CREATE POLICY "Users can update own battle plans"
  ON public.battle_plans FOR UPDATE
  USING (auth.uid() = user_id);

-- RLS Policies for quadrant_objectives
CREATE POLICY "Team members can view quadrant objectives"
  ON public.quadrant_objectives FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.battle_plans bp
      JOIN public.team_members tm ON tm.team_id = bp.team_id
      WHERE bp.id = quadrant_objectives.plan_id
        AND tm.user_id = auth.uid()
        AND tm.status = 'active'
    )
  );

CREATE POLICY "Users can manage own quadrant objectives"
  ON public.quadrant_objectives FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM public.battle_plans
      WHERE battle_plans.id = quadrant_objectives.plan_id
        AND battle_plans.user_id = auth.uid()
    )
  );

-- RLS Policies for checkpoints
CREATE POLICY "Team members can view checkpoints"
  ON public.checkpoints FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.battle_plans bp
      JOIN public.team_members tm ON tm.team_id = bp.team_id
      WHERE bp.id = checkpoints.plan_id
        AND tm.user_id = auth.uid()
        AND tm.status = 'active'
    )
  );

CREATE POLICY "Users can manage own checkpoints"
  ON public.checkpoints FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM public.battle_plans
      WHERE battle_plans.id = checkpoints.plan_id
        AND battle_plans.user_id = auth.uid()
    )
  );

-- RLS Policies for daily_logs
CREATE POLICY "Team members can view daily logs"
  ON public.daily_logs FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.team_members
      WHERE team_members.team_id = daily_logs.team_id
        AND team_members.user_id = auth.uid()
        AND team_members.status = 'active'
    )
  );

CREATE POLICY "Users can manage own daily logs"
  ON public.daily_logs FOR ALL
  USING (auth.uid() = user_id);

-- RLS Policies for weekly_metrics
CREATE POLICY "Team members can view weekly metrics"
  ON public.weekly_metrics FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.battle_plans bp
      JOIN public.team_members tm ON tm.team_id = bp.team_id
      WHERE bp.id = weekly_metrics.plan_id
        AND tm.user_id = auth.uid()
        AND tm.status = 'active'
    )
  );

CREATE POLICY "Users can manage own weekly metrics"
  ON public.weekly_metrics FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM public.battle_plans
      WHERE battle_plans.id = weekly_metrics.plan_id
        AND battle_plans.user_id = auth.uid()
    )
  );

-- RLS Policies for emergency_plans
CREATE POLICY "Team members can view emergency plans"
  ON public.emergency_plans FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.team_members
      WHERE team_members.team_id = emergency_plans.team_id
        AND team_members.user_id = auth.uid()
        AND team_members.status = 'active'
    )
  );

CREATE POLICY "Users can manage own emergency plans"
  ON public.emergency_plans FOR ALL
  USING (auth.uid() = user_id);

-- RLS Policies for challenges
CREATE POLICY "Team members can view challenges"
  ON public.challenges FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.team_members
      WHERE team_members.team_id = challenges.team_id
        AND team_members.user_id = auth.uid()
        AND team_members.status = 'active'
    )
  );

CREATE POLICY "Leaders can manage challenges"
  ON public.challenges FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM public.team_members
      WHERE team_members.team_id = challenges.team_id
        AND team_members.user_id = auth.uid()
        AND team_members.role IN ('leader', 'xo')
        AND team_members.status = 'active'
    )
  );

-- RLS Policies for comments
CREATE POLICY "Team members can view comments"
  ON public.comments FOR SELECT
  USING (true);

CREATE POLICY "Users can create comments"
  ON public.comments FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own comments"
  ON public.comments FOR UPDATE
  USING (auth.uid() = user_id);