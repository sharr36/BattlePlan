-- Add restrictive policy to require authentication for accessing profiles
-- This ensures anonymous users cannot access the table under any circumstances
CREATE POLICY "Require authentication for profiles"
ON public.profiles
AS RESTRICTIVE
FOR ALL
TO public
USING (auth.uid() IS NOT NULL);