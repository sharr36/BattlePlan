-- Add back teammate policy but ONLY for team leaders/XO who need to manage members
-- Regular members should only see display_name (not email) via the secure view

CREATE POLICY "Team leaders can view teammate profiles for management" 
ON public.profiles 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1
    FROM team_members tm1
    JOIN team_members tm2 ON tm1.team_id = tm2.team_id
    WHERE tm1.user_id = auth.uid()
      AND tm2.user_id = profiles.id
      AND tm1.status = 'active'
      AND tm2.status = 'active'
      AND tm1.role IN ('leader', 'xo')
  )
);

-- App admins can view all profiles for management
CREATE POLICY "Admins can view all profiles" 
ON public.profiles 
FOR SELECT 
USING (public.has_role(auth.uid(), 'admin'));