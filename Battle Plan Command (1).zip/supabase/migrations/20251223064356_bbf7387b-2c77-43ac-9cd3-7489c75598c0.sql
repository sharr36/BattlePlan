-- Add team_id column to user_visions for team sharing
ALTER TABLE public.user_visions 
ADD COLUMN team_id uuid REFERENCES public.teams(id) ON DELETE SET NULL;

-- Create index for faster team lookups
CREATE INDEX idx_user_visions_team_id ON public.user_visions(team_id);

-- Add RLS policy for team members to view visions (read-only)
CREATE POLICY "Team members can view teammate visions" 
ON public.user_visions 
FOR SELECT 
USING (
  team_id IS NOT NULL AND 
  EXISTS (
    SELECT 1 FROM team_members tm
    WHERE tm.team_id = user_visions.team_id
    AND tm.user_id = auth.uid()
    AND tm.status = 'active'
  )
);