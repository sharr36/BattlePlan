-- Create separate table for invite codes with leader-only access
CREATE TABLE public.team_invite_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  team_id uuid NOT NULL REFERENCES public.teams(id) ON DELETE CASCADE,
  invite_code text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(team_id)
);

-- Enable RLS
ALTER TABLE public.team_invite_codes ENABLE ROW LEVEL SECURITY;

-- Only leaders and XOs can view invite codes
CREATE POLICY "Leaders and XOs can view invite codes"
ON public.team_invite_codes
FOR SELECT
USING (is_team_leader_or_xo(auth.uid(), team_id));

-- Only leaders and XOs can update/regenerate invite codes
CREATE POLICY "Leaders and XOs can update invite codes"
ON public.team_invite_codes
FOR UPDATE
USING (is_team_leader_or_xo(auth.uid(), team_id));

-- App admins can view all invite codes
CREATE POLICY "Admins can view all invite codes"
ON public.team_invite_codes
FOR SELECT
USING (is_app_admin());

-- Migrate existing invite codes from teams table
INSERT INTO public.team_invite_codes (team_id, invite_code)
SELECT id, invite_code FROM public.teams WHERE invite_code IS NOT NULL;

-- Add trigger to auto-create invite code when team is created
CREATE OR REPLACE FUNCTION public.create_team_invite_code()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.team_invite_codes (team_id, invite_code)
  VALUES (NEW.id, generate_invite_code());
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_team_created_add_invite_code
  AFTER INSERT ON public.teams
  FOR EACH ROW
  EXECUTE FUNCTION public.create_team_invite_code();