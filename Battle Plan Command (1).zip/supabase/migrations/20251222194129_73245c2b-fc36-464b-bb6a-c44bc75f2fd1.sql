-- Drop the unused view that has no RLS protection
DROP VIEW IF EXISTS public.teammate_profiles;

-- Drop the unused helper function
DROP FUNCTION IF EXISTS public.is_teammate(uuid);