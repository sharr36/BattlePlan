-- Fix profiles table RLS policies to use proper permissive/restrictive pattern
-- Drop existing SELECT policies and recreate with correct configuration

DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
DROP POLICY IF EXISTS "Admins can view all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Block anonymous access" ON public.profiles;

-- Create PERMISSIVE policy for users to view their own profile (includes email)
CREATE POLICY "Users can view own profile"
ON public.profiles
FOR SELECT
TO authenticated
USING (auth.uid() = id);

-- Create PERMISSIVE policy for admins to view all profiles (includes email for admin purposes)
CREATE POLICY "Admins can view all profiles"
ON public.profiles
FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'admin'));

-- Note: We intentionally do NOT create any policy for anon role
-- Since RLS is enabled and there are no policies for anon, anonymous access is denied by default
-- The secure function get_team_member_profiles handles team member visibility without exposing email