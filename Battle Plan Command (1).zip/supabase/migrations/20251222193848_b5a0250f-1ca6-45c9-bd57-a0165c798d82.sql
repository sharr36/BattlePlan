-- Drop the teammate policy that exposes emails
DROP POLICY IF EXISTS "Team members can view teammate profiles" ON public.profiles;

-- Create a secure view for teammate profiles (excludes email)
CREATE OR REPLACE VIEW public.teammate_profiles AS
SELECT 
  p.id,
  p.display_name,
  p.avatar_url
FROM public.profiles p
WHERE public.is_teammate(p.id);

-- Grant access to the view
GRANT SELECT ON public.teammate_profiles TO authenticated;

-- The "Users can view own profile" policy remains - users can see their own full profile including email