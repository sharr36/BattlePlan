-- Drop the view with security definer issue
DROP VIEW IF EXISTS public.teammate_profiles;

-- Recreate the view with SECURITY INVOKER (default, but explicit is better)
CREATE VIEW public.teammate_profiles 
WITH (security_invoker = true)
AS
SELECT 
  p.id,
  p.display_name,
  p.avatar_url
FROM public.profiles p
WHERE public.is_teammate(p.id);

-- Grant access to the view
GRANT SELECT ON public.teammate_profiles TO authenticated;