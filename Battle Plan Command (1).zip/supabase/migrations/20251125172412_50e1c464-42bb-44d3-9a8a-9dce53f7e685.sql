-- Ensure invite codes are always generated for teams

-- 1) Update set_invite_code to treat empty strings as missing
CREATE OR REPLACE FUNCTION public.set_invite_code()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  IF NEW.invite_code IS NULL OR NEW.invite_code = '' THEN
    NEW.invite_code := generate_invite_code();
  END IF;
  RETURN NEW;
END;
$function$;

-- 2) Create trigger on teams to auto-generate invite_code
DROP TRIGGER IF EXISTS set_invite_code_before_insert ON public.teams;

CREATE TRIGGER set_invite_code_before_insert
BEFORE INSERT ON public.teams
FOR EACH ROW
EXECUTE FUNCTION public.set_invite_code();