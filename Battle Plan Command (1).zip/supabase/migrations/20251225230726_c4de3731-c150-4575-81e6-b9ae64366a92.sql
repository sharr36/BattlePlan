-- Add explicit policy to block anonymous access to profiles table
CREATE POLICY "Block anonymous access"
ON public.profiles
FOR SELECT
USING (auth.uid() IS NOT NULL);