-- Block anonymous/unauthenticated access to profiles table
CREATE POLICY "Block anonymous access"
ON public.profiles
FOR SELECT
TO anon
USING (false);