-- Add share_token column for generating shareable links
ALTER TABLE public.after_action_reviews
ADD COLUMN share_token TEXT UNIQUE,
ADD COLUMN is_shared BOOLEAN DEFAULT false;

-- Create index for faster share token lookups
CREATE INDEX idx_after_action_reviews_share_token ON public.after_action_reviews(share_token);

-- Create a function to generate share tokens
CREATE OR REPLACE FUNCTION public.generate_share_token()
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  chars TEXT := 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  result TEXT := '';
  i INTEGER;
BEGIN
  FOR i IN 1..16 LOOP
    result := result || substr(chars, floor(random() * length(chars) + 1)::int, 1);
  END LOOP;
  RETURN result;
END;
$$;

-- Allow public access to shared reviews via share token
CREATE POLICY "Anyone can view shared reviews via token"
  ON public.after_action_reviews FOR SELECT
  USING (is_shared = true AND share_token IS NOT NULL);