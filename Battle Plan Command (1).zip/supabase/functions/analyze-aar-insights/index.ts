import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "No authorization header" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get user's team IDs
    const { data: teamData } = await supabase
      .from("team_members")
      .select("team_id")
      .eq("user_id", user.id)
      .eq("status", "active");

    if (!teamData || teamData.length === 0) {
      return new Response(
        JSON.stringify({ error: "No teams found", insights: null }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const teamIds = teamData.map(t => t.team_id);

    // Fetch all AARs for the user's teams
    const { data: aars, error: aarsError } = await supabase
      .from("after_action_reviews")
      .select("*")
      .in("team_id", teamIds)
      .order("period_end", { ascending: false });

    if (aarsError) {
      console.error("Error fetching AARs:", aarsError);
      throw aarsError;
    }

    if (!aars || aars.length === 0) {
      return new Response(
        JSON.stringify({ 
          error: null, 
          insights: {
            summary: "No After Action Reviews found to analyze. Create some AARs to see insights!",
            themes: [],
            trends: [],
            recommendations: [],
            stats: { total: 0, avgRating: 0, quarterlyCount: 0, yearlyCount: 0 }
          }
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Prepare AAR content for analysis
    const aarSummaries = aars.map(aar => ({
      period: `${aar.period_start} to ${aar.period_end}`,
      type: aar.review_type,
      rating: aar.overall_rating,
      whatWentWell: aar.what_went_well || "",
      whatCouldImprove: aar.what_could_improve || "",
      lessonsLearned: aar.lessons_learned || "",
      actionItems: Array.isArray(aar.action_items) ? aar.action_items : []
    }));

    // Calculate basic stats
    const stats = {
      total: aars.length,
      avgRating: aars.reduce((sum, a) => sum + (a.overall_rating || 0), 0) / aars.length,
      quarterlyCount: aars.filter(a => a.review_type === "quarterly").length,
      yearlyCount: aars.filter(a => a.review_type === "yearly").length,
      completedActions: aars.reduce((sum, a) => {
        const items = Array.isArray(a.action_items) ? a.action_items : [];
        return sum + items.filter((i: any) => i.completed).length;
      }, 0),
      totalActions: aars.reduce((sum, a) => {
        const items = Array.isArray(a.action_items) ? a.action_items : [];
        return sum + items.length;
      }, 0)
    };

    const systemPrompt = `You are an expert at analyzing After Action Reviews (AARs) and identifying patterns, themes, and actionable insights. Analyze the provided AARs and extract:

1. RECURRING THEMES - What topics, challenges, or successes appear repeatedly?
2. TREND ANALYSIS - Are things improving or declining over time? What patterns emerge?
3. KEY INSIGHTS - What are the most important takeaways across all reviews?
4. RECOMMENDATIONS - Based on patterns, what should the user focus on?
5. STRENGTHS - What consistently goes well?
6. AREAS FOR GROWTH - What consistently needs improvement?

Be specific and actionable. Reference actual content from the AARs when possible.`;

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: `Analyze these ${aars.length} After Action Reviews and provide comprehensive insights:\n\n${JSON.stringify(aarSummaries, null, 2)}` }
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "generate_insights",
              description: "Generate structured insights from AAR analysis",
              parameters: {
                type: "object",
                properties: {
                  summary: { 
                    type: "string", 
                    description: "A 2-3 sentence executive summary of the overall patterns" 
                  },
                  themes: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        name: { type: "string", description: "Theme name" },
                        description: { type: "string", description: "Brief description of the theme" },
                        frequency: { type: "string", enum: ["high", "medium", "low"], description: "How often this theme appears" },
                        sentiment: { type: "string", enum: ["positive", "negative", "neutral"], description: "Overall sentiment of this theme" }
                      },
                      required: ["name", "description", "frequency", "sentiment"]
                    },
                    description: "Recurring themes identified across AARs"
                  },
                  trends: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        area: { type: "string", description: "Area of trend" },
                        direction: { type: "string", enum: ["improving", "declining", "stable"], description: "Trend direction" },
                        insight: { type: "string", description: "Explanation of the trend" }
                      },
                      required: ["area", "direction", "insight"]
                    },
                    description: "Trends observed over time"
                  },
                  strengths: {
                    type: "array",
                    items: { type: "string" },
                    description: "Consistent strengths identified"
                  },
                  growthAreas: {
                    type: "array",
                    items: { type: "string" },
                    description: "Areas that consistently need improvement"
                  },
                  recommendations: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        priority: { type: "string", enum: ["high", "medium", "low"], description: "Priority level" },
                        action: { type: "string", description: "Recommended action" },
                        rationale: { type: "string", description: "Why this is recommended based on AAR patterns" }
                      },
                      required: ["priority", "action", "rationale"]
                    },
                    description: "Actionable recommendations based on patterns"
                  }
                },
                required: ["summary", "themes", "trends", "strengths", "growthAreas", "recommendations"]
              }
            }
          }
        ],
        tool_choice: { type: "function", function: { name: "generate_insights" } }
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "Usage limit reached. Please add credits." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const errorText = await response.text();
      console.error("AI Gateway error:", response.status, errorText);
      throw new Error("Failed to analyze AARs with AI");
    }

    const aiResponse = await response.json();
    console.log("AI Response received for insights");

    const toolCall = aiResponse.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall || toolCall.function.name !== "generate_insights") {
      throw new Error("AI did not return expected structured data");
    }

    const insights = JSON.parse(toolCall.function.arguments);
    insights.stats = stats;
    insights.analyzedAt = new Date().toISOString();

    console.log("Successfully generated insights");

    return new Response(
      JSON.stringify({ success: true, insights }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("Error in analyze-aar-insights function:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error occurred" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
