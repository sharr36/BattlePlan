import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function parseCSV(csvContent: string): string {
  const lines = csvContent.split('\n').filter(line => line.trim());
  if (lines.length < 2) return csvContent;
  
  const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
  const result: string[] = [];
  
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].match(/(".*?"|[^,]+)/g)?.map(v => v.trim().replace(/"/g, '')) || [];
    const entry: string[] = [];
    headers.forEach((header, idx) => {
      if (values[idx]) {
        entry.push(`${header}: ${values[idx]}`);
      }
    });
    result.push(entry.join('\n'));
  }
  
  return result.join('\n\n');
}

async function extractTextFromPDFBase64(base64Content: string): Promise<string> {
  try {
    const binaryString = atob(base64Content);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    
    const text = new TextDecoder('utf-8', { fatal: false }).decode(bytes);
    const textMatches = text.match(/[\x20-\x7E\n\r\t]+/g) || [];
    const extractedText = textMatches
      .filter(chunk => chunk.length > 3)
      .join(' ')
      .replace(/\s+/g, ' ')
      .trim();
    
    return extractedText.length > 50 ? extractedText : "PDF content could not be fully extracted. Please paste the text content directly.";
  } catch (error) {
    console.error("PDF extraction error:", error);
    return "PDF content could not be extracted. Please paste the text content directly.";
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "No authorization header" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { aarText, fileContent, fileType, fileName, reviewType, teamId } = await req.json();

    let contentToProcess = aarText || '';
    
    if (fileType === 'csv' && fileContent) {
      contentToProcess = parseCSV(fileContent);
      console.log("Parsed CSV content");
    } else if (fileType === 'pdf' && fileContent) {
      contentToProcess = await extractTextFromPDFBase64(fileContent);
      console.log("Extracted PDF content, length:", contentToProcess.length);
    } else if (fileContent && fileType !== 'pdf') {
      contentToProcess = fileContent;
    }

    if (!contentToProcess || contentToProcess.length < 20) {
      return new Response(
        JSON.stringify({ error: "Insufficient content to process" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const systemPrompt = `You are an expert at parsing After Action Reviews (AARs) and extracting structured data. 
Your task is to analyze the provided AAR content and extract the following information:

1. Period dates (start and end) - extract or infer from context
2. What went well - successes, wins, achievements
3. What could improve - areas needing work, challenges faced
4. Lessons learned - key insights and takeaways
5. Action items - specific next steps (mark as completed if indicated with [x] or similar)
6. Overall rating (1-5) - infer from tone if not explicitly stated

Be thorough but concise. Combine similar points. Generate action items if none are provided based on improvement areas.`;

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: `Parse this After Action Review and extract structured data:\n\n${contentToProcess}` }
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "extract_aar",
              description: "Extract structured data from an After Action Review",
              parameters: {
                type: "object",
                properties: {
                  period_start: { 
                    type: "string", 
                    description: "Start date of the review period in YYYY-MM-DD format" 
                  },
                  period_end: { 
                    type: "string", 
                    description: "End date of the review period in YYYY-MM-DD format" 
                  },
                  what_went_well: { 
                    type: "string", 
                    description: "Summary of successes and achievements" 
                  },
                  what_could_improve: { 
                    type: "string", 
                    description: "Areas that need improvement" 
                  },
                  lessons_learned: { 
                    type: "string", 
                    description: "Key insights and takeaways" 
                  },
                  action_items: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        text: { type: "string", description: "The action item description" },
                        completed: { type: "boolean", description: "Whether the item is completed" }
                      },
                      required: ["text", "completed"]
                    },
                    description: "List of action items with completion status"
                  },
                  overall_rating: { 
                    type: "number", 
                    description: "Overall rating from 1-5" 
                  }
                },
                required: ["period_start", "period_end", "what_went_well", "what_could_improve", "lessons_learned", "action_items", "overall_rating"]
              }
            }
          }
        ],
        tool_choice: { type: "function", function: { name: "extract_aar" } }
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "Usage limit reached. Please add credits." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const errorText = await response.text();
      console.error("AI Gateway error:", response.status, errorText);
      throw new Error("Failed to process AAR with AI");
    }

    const aiResponse = await response.json();
    console.log("AI Response received");

    const toolCall = aiResponse.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall || toolCall.function.name !== "extract_aar") {
      throw new Error("AI did not return expected structured data");
    }

    const extractedData = JSON.parse(toolCall.function.arguments);
    
    // Add IDs to action items
    const actionItemsWithIds = extractedData.action_items.map((item: any) => ({
      id: crypto.randomUUID(),
      text: item.text,
      completed: item.completed || false
    }));

    const aar = {
      review_type: reviewType || "quarterly",
      period_start: extractedData.period_start,
      period_end: extractedData.period_end,
      what_went_well: extractedData.what_went_well,
      what_could_improve: extractedData.what_could_improve,
      lessons_learned: extractedData.lessons_learned,
      action_items: actionItemsWithIds,
      overall_rating: Math.min(5, Math.max(1, extractedData.overall_rating || 3))
    };

    console.log("Successfully parsed AAR:", JSON.stringify(aar, null, 2));

    return new Response(
      JSON.stringify({ success: true, aar }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("Error in import-aar function:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error occurred" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
