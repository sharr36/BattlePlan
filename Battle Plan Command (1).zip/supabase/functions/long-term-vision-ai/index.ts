import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // 1. Extract and validate authorization header
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      console.error("Missing authorization header");
      return new Response(
        JSON.stringify({ error: 'Missing authorization header' }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Extract the JWT token from the header
    const token = authHeader.replace('Bearer ', '');

    // 2. Create Supabase client with the user's JWT
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    );

    // 3. Get authenticated user from JWT - pass the token directly
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser(token);
    if (userError || !user) {
      console.error("Invalid or expired token:", userError);
      return new Response(
        JSON.stringify({ error: 'Invalid or expired token' }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("Authenticated user:", user.id);

    const { timeframe, conversationHistory = [], userInput } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    // 4. Fetch user's ACTUAL visions from database (don't trust client-provided existingVisions)
    const { data: existingVisions, error: visionError } = await supabaseClient
      .from('user_visions')
      .select('*')
      .eq('user_id', user.id)
      .maybeSingle();
    
    if (visionError) {
      console.error("Error fetching user visions:", visionError);
    } else {
      console.log("Fetched validated user visions from database");
    }

    const timeframeLabels: Record<string, string> = {
      "1_year": "1 year",
      "5_year": "5 years", 
      "10_year": "10 years"
    };

    const timeframeLabel = timeframeLabels[timeframe] || "1 year";

    // Deep probing questions based on timeframe
    const probingQuestions: Record<string, string[]> = {
      "1_year": [
        "What would make this year feel like a success?",
        "What's one thing you'd regret NOT doing in the next 12 months?",
        "If you could only change ONE area of your life this year, what would it be?",
        "What does 'being your best self' look like one year from now?",
        "What habits or patterns are you ready to break?"
      ],
      "5_year": [
        "Where do you want to be living and who do you want to be with?",
        "What kind of work do you see yourself doing?",
        "What level of financial freedom do you want?",
        "What would you want your family and relationships to look like?",
        "What would you be proud to have accomplished?"
      ],
      "10_year": [
        "What legacy do you want to be building?",
        "How do you want to be remembered by the people closest to you?",
        "What kind of impact do you want to have on the world?",
        "What does complete fulfillment look like for you?",
        "What would you tell your current self if you could look back from 10 years ahead?"
      ]
    };

    // Use validated visions from database (not client-provided)
    const contextFromOtherVisions = existingVisions ? `
Their other visions for context (don't repeat, build on these):
- 1-year: ${existingVisions.vision_1_year || "Not yet defined"}
- 5-year: ${existingVisions.vision_5_year || "Not yet defined"}  
- 10-year: ${existingVisions.vision_10_year || "Not yet defined"}
` : "";

    const systemPrompt = `You are a thoughtful facilitator helping someone articulate their ${timeframeLabel} vision for their life.

CRITICAL RULES:
- NEVER write their vision FOR them
- Ask ONE probing question at a time to help them think deeper
- Reflect back what THEY said in their own words
- Help them be more specific when they're vague
- The vision must come from THEM or it will be meaningless
- Keep responses concise (2-3 sentences max for questions)

${contextFromOtherVisions}

APPROACH for ${timeframeLabel} vision:
1. Start by asking what success looks like for them at that timeframe
2. Ask follow-up questions to explore different life areas (health, wealth, relationships, purpose)
3. Help them identify what's MOST important vs nice-to-have
4. When they've articulated something clear and meaningful, reflect it back for confirmation
5. Once confirmed, format THEIR vision and say "Here's your ${timeframeLabel} vision based on what you shared:"

Probing question ideas for ${timeframeLabel}:
${probingQuestions[timeframe]?.join("\n") || ""}

Be warm and supportive. Ask questions that make them THINK, not questions they can answer superficially.`;

    let messages: any[] = [];

    if (conversationHistory.length === 0) {
      // Opening message
      const openingPrompts: Record<string, string> = {
        "1_year": "Let's think about where you want to be one year from now. What's the ONE thing that, if you achieved it, would make this next year feel like a real success?",
        "5_year": "Five years is enough time for real transformation. When you close your eyes and imagine your life 5 years from now, what do you see? Don't hold back - what would be the ideal?",
        "10_year": "Ten years is a lifetime of possibility. If everything went right, where would you be? What kind of man would you have become?"
      };

      messages = [
        { role: "system", content: systemPrompt },
        { role: "assistant", content: openingPrompts[timeframe] || openingPrompts["1_year"] }
      ];

      console.log("Returning opening message for user:", user.id, "timeframe:", timeframe);

      // Return opening message directly
      return new Response(
        JSON.stringify({ suggestion: openingPrompts[timeframe] || openingPrompts["1_year"] }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    } else {
      messages = [
        { role: "system", content: systemPrompt },
        ...conversationHistory,
        { role: "user", content: userInput }
      ];
    }

    console.log("Calling AI for user:", user.id, "timeframe:", timeframe);

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: messages,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI usage limit reached. Please add credits to continue." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      throw new Error("AI gateway error");
    }

    const data = await response.json();
    const suggestion = data.choices[0].message.content.trim();

    console.log("AI response generated successfully for user:", user.id);

    return new Response(
      JSON.stringify({ suggestion }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error in long-term-vision-ai function:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
