import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Parse CSV content into text
function parseCSV(csvContent: string): string {
  const lines = csvContent.trim().split('\n');
  if (lines.length === 0) return "";
  
  // Try to detect the structure
  const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
  const result: string[] = [];
  
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',').map(v => v.trim().replace(/"/g, ''));
    const row: string[] = [];
    headers.forEach((header, idx) => {
      if (values[idx]) {
        row.push(`${header}: ${values[idx]}`);
      }
    });
    if (row.length > 0) {
      result.push(row.join('\n'));
    }
  }
  
  return result.join('\n\n');
}

// Extract text from PDF using pdf-parse equivalent for Deno
async function extractTextFromPDFBase64(base64Content: string): Promise<string> {
  try {
    // Decode base64 to binary
    const binaryString = atob(base64Content);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    
    // Simple PDF text extraction - look for text streams
    const pdfContent = new TextDecoder('utf-8', { fatal: false }).decode(bytes);
    
    // Extract text between stream markers and decode
    const textParts: string[] = [];
    
    // Look for text objects in PDF
    const textMatches = pdfContent.matchAll(/\(([^)]+)\)/g);
    for (const match of textMatches) {
      const text = match[1]
        .replace(/\\n/g, '\n')
        .replace(/\\r/g, '\r')
        .replace(/\\t/g, '\t')
        .replace(/\\\(/g, '(')
        .replace(/\\\)/g, ')')
        .replace(/\\\\/g, '\\');
      if (text.length > 2 && /[a-zA-Z]/.test(text)) {
        textParts.push(text);
      }
    }
    
    // Also try to extract from BT...ET blocks (text objects)
    const btEtMatches = pdfContent.matchAll(/BT\s*([\s\S]*?)\s*ET/g);
    for (const match of btEtMatches) {
      const tjMatches = match[1].matchAll(/\[([^\]]+)\]\s*TJ|\(([^)]+)\)\s*Tj/g);
      for (const tjMatch of tjMatches) {
        const text = (tjMatch[1] || tjMatch[2] || '')
          .replace(/\([^)]*\)/g, (m) => m.slice(1, -1))
          .replace(/\\n/g, '\n')
          .trim();
        if (text.length > 1) {
          textParts.push(text);
        }
      }
    }
    
    const extractedText = textParts.join(' ').trim();
    
    if (extractedText.length < 50) {
      console.log("Limited text extraction from PDF, using AI to interpret");
      // If we couldn't extract much, send a note that it's a PDF
      return `[PDF Document Content - Limited text extraction]\n\n${extractedText || 'Unable to extract text. Please ensure the PDF contains selectable text, not just images.'}`;
    }
    
    return extractedText;
  } catch (error) {
    console.error("Error extracting PDF text:", error);
    throw new Error("Failed to extract text from PDF. Please ensure the PDF contains selectable text.");
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // 1. Extract and validate authorization header
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      console.error("Missing authorization header");
      return new Response(
        JSON.stringify({ error: 'Missing authorization header' }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Extract the JWT token from the header
    const token = authHeader.replace('Bearer ', '');

    // 2. Create Supabase client with the user's JWT
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    );

    // 3. Get authenticated user from JWT
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser(token);
    if (userError || !user) {
      console.error("Invalid or expired token:", userError);
      return new Response(
        JSON.stringify({ error: 'Invalid or expired token' }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("Authenticated user:", user.id);

    const body = await req.json();
    const { planText, fileContent, fileType, fileName } = body;
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");

    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    let textContent = planText || "";

    // Handle file content based on type
    if (fileContent && fileType) {
      console.log(`Processing ${fileType} file: ${fileName}`);
      
      if (fileType === 'csv') {
        textContent = parseCSV(fileContent);
        console.log("CSV parsed, text length:", textContent.length);
      } else if (fileType === 'pdf') {
        // For PDFs, extract text from base64 content
        textContent = await extractTextFromPDFBase64(fileContent);
        console.log("PDF text extracted, length:", textContent.length);
      } else {
        // Plain text or other
        textContent = fileContent;
      }
    }

    if (!textContent || textContent.trim().length < 20) {
      return new Response(
        JSON.stringify({ error: "Could not extract enough content from the file. Please ensure it contains readable text." }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log("Parsing battle plan text, length:", textContent.length);

    const systemPrompt = `You are an expert at parsing battle plans and strategic documents. Your task is to extract structured data from the provided text.

A battle plan consists of:
1. An overall VISION statement (the 12-week goal/theme)
2. Four QUADRANTS, each with:
   - Calibration (personal development, mindset, spiritual growth)
   - Connection (relationships, family, social)
   - Condition (physical health, fitness, nutrition)
   - Contribution (career, business, financial, giving back)

Each quadrant should have:
- An objective (the main goal for that area)
- A primary tactic (the #1 action/habit to achieve the objective)
- Secondary tactics (2-3 supporting actions)
- 30-day checkpoint (milestone to hit by day 30)
- 60-day checkpoint (milestone to hit by day 60)

Extract as much as you can from the provided text. If certain fields are not explicitly mentioned, try to infer reasonable values based on context. If you cannot determine a value, leave it as an empty string.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: `Please parse this battle plan and extract the structured data:\n\n${textContent}` }
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "extract_battle_plan",
              description: "Extract structured battle plan data from text",
              parameters: {
                type: "object",
                properties: {
                  vision: {
                    type: "string",
                    description: "The overall vision or theme for the 12-week period"
                  },
                  calibration: {
                    type: "object",
                    properties: {
                      objective: { type: "string", description: "Main goal for personal development/mindset" },
                      primaryTactic: { type: "string", description: "Primary action for calibration" },
                      secondaryTactic1: { type: "string", description: "First supporting action" },
                      secondaryTactic2: { type: "string", description: "Second supporting action" },
                      secondaryTactic3: { type: "string", description: "Third supporting action" },
                      checkpoint30: { type: "string", description: "30-day milestone" },
                      checkpoint60: { type: "string", description: "60-day milestone" }
                    },
                    required: ["objective", "primaryTactic", "secondaryTactic1", "checkpoint30", "checkpoint60"]
                  },
                  connection: {
                    type: "object",
                    properties: {
                      objective: { type: "string", description: "Main goal for relationships/social" },
                      primaryTactic: { type: "string", description: "Primary action for connection" },
                      secondaryTactic1: { type: "string", description: "First supporting action" },
                      secondaryTactic2: { type: "string", description: "Second supporting action" },
                      secondaryTactic3: { type: "string", description: "Third supporting action" },
                      checkpoint30: { type: "string", description: "30-day milestone" },
                      checkpoint60: { type: "string", description: "60-day milestone" }
                    },
                    required: ["objective", "primaryTactic", "secondaryTactic1", "checkpoint30", "checkpoint60"]
                  },
                  condition: {
                    type: "object",
                    properties: {
                      objective: { type: "string", description: "Main goal for physical health/fitness" },
                      primaryTactic: { type: "string", description: "Primary action for condition" },
                      secondaryTactic1: { type: "string", description: "First supporting action" },
                      secondaryTactic2: { type: "string", description: "Second supporting action" },
                      secondaryTactic3: { type: "string", description: "Third supporting action" },
                      checkpoint30: { type: "string", description: "30-day milestone" },
                      checkpoint60: { type: "string", description: "60-day milestone" }
                    },
                    required: ["objective", "primaryTactic", "secondaryTactic1", "checkpoint30", "checkpoint60"]
                  },
                  contribution: {
                    type: "object",
                    properties: {
                      objective: { type: "string", description: "Main goal for career/business/giving" },
                      primaryTactic: { type: "string", description: "Primary action for contribution" },
                      secondaryTactic1: { type: "string", description: "First supporting action" },
                      secondaryTactic2: { type: "string", description: "Second supporting action" },
                      secondaryTactic3: { type: "string", description: "Third supporting action" },
                      checkpoint30: { type: "string", description: "30-day milestone" },
                      checkpoint60: { type: "string", description: "60-day milestone" }
                    },
                    required: ["objective", "primaryTactic", "secondaryTactic1", "checkpoint30", "checkpoint60"]
                  }
                },
                required: ["vision", "calibration", "connection", "condition", "contribution"]
              }
            }
          }
        ],
        tool_choice: { type: "function", function: { name: "extract_battle_plan" } }
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI usage limit reached. Please try again later." }),
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    console.log("AI response received");

    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall || toolCall.function.name !== "extract_battle_plan") {
      throw new Error("Failed to extract battle plan data");
    }

    const extractedPlan = JSON.parse(toolCall.function.arguments);
    console.log("Successfully extracted battle plan");

    return new Response(
      JSON.stringify({ success: true, plan: extractedPlan }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error("Error in import-battle-plan function:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Failed to parse battle plan" }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
