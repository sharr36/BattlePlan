import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Missing authorization header' }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const token = authHeader.replace('Bearer ', '');
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: userError } = await supabaseClient.auth.getUser(token);
    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: 'Invalid or expired token' }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { section, conversationHistory = [], userInput, currentData } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    // Section-specific prompts for the Going Deeper vision worksheet
    const sectionPrompts: Record<string, { system: string; opener: string }> = {
      yearly_theme: {
        system: `You are helping someone define their "theme" or "word" for the year. This should be a single word or short phrase that captures their main focus.

Keep responses concise (2-3 sentences). Be warm, encouraging, and direct. Help them distill their focus into a powerful theme.`,
        opener: "What do you want this year to be about? What's the one thing you want to focus on more than anything else?"
      },
      life_categories: {
        system: `You are helping someone think through their goals across 8 life categories:
1. Health & Nutrition
2. Spiritual & Contribution  
3. Lifestyle & Adventure
4. Personal Growth / Intellectual
5. Business & Career
6. Friends / Family / Relationships
7. Financial & Investment
8. Environment / Tribe

Help them set 3 specific, measurable targets per category. Be concise and ask one question at a time.`,
        opener: "Looking at the 8 life categories - which 2-3 feel most important for you to focus on right now? Let's start there and get specific."
      },
      financial: {
        system: `You are helping someone think through their financial goals and analysis. Help them think about:
- Income (horizontal/active vs vertical/passive)
- Assets and debt management
- Net worth goals
- Financial freedom percentage
- Contribution goals

Be practical and help them set realistic but ambitious targets. Keep responses to 2-3 sentences.`,
        opener: "Let's talk about your financial vision. What does financial freedom look like for you? What income or net worth would let you live life on your terms?"
      },
      body_stats: {
        system: `You are helping someone set their health and body goals. Consider:
- Weight goals
- Body fat percentage
- Blood pressure targets
- Fitness benchmarks (like the GB 9 or other metrics)
- Lifestyle Health Index (LHI)

Be encouraging and help them set healthy, sustainable goals. Keep responses brief.`,
        opener: "What are your health and body goals? Think about where you are now and where you want to be - what would make you feel your best?"
      },
      contribution: {
        system: `You are helping someone think about their contribution to others - both financially and with their time. Help them consider:
- Financial giving goals
- Time contribution (volunteer hours)
- Value they want to create for others
- Give-to-income ratio

Be inspiring and help them think about impact. Keep responses to 2-3 sentences.`,
        opener: "Contribution is about giving back. How do you want to contribute to others this year - with your money, time, or expertise?"
      },
      highlights: {
        system: `You are helping someone reflect on their past year's highlights and plan exciting highlights for the upcoming year. Help them:
- Celebrate wins from the past year
- Identify what made those moments special
- Plan memorable experiences for the coming year

Be celebratory about the past and inspiring about the future. Keep responses brief.`,
        opener: "Let's celebrate! What were your biggest wins or most memorable moments from the past year? What made them special?"
      },
      bucket_list: {
        system: `You are helping someone identify their top 5 bucket list adventures - experiences and adventures they truly want to have.

Push them to think beyond the typical. Help them be specific (not just "travel" but "hike Machu Picchu at sunrise"). Encourage adventures that would be truly meaningful to them personally.

Keep it fun and inspiring. 2-3 sentences max.`,
        opener: "Let's dream big! What's an experience or adventure you've always wanted to have? Don't worry about whether it's practical - what would truly excite you?"
      },
      accountability: {
        system: `You are helping someone identify:
1. What they want to be held accountable for
2. What they need help with

Be specific - vague accountability doesn't work. Help them articulate concrete commitments and the support they need. Keep it real and practical. 2-3 sentences.`,
        opener: "Accountability is about having someone who won't let you off the hook. What specific commitments do you want someone to hold you to?"
      },
      general: {
        system: `You are a helpful vision planning assistant helping someone complete their life vision worksheet (similar to the GoBundance One Sheet). 

You can help with:
- Setting a theme for the year
- Financial analysis and goals
- Health and body stats goals
- Contribution goals (giving back)
- Reflecting on highlights and planning new ones
- Bucket list adventures
- Goals across 8 life categories
- Accountability and getting help

Be encouraging, practical, and help them think big while staying actionable. Keep responses concise (2-4 sentences).`,
        opener: "I'm here to help you fill out your vision worksheet! What section would you like to work on? I can help with your yearly theme, financial goals, health targets, life category goals, bucket list, or accountability needs."
      }
    };

    const sectionConfig = sectionPrompts[section] || sectionPrompts.general;

    if (conversationHistory.length === 0 && !userInput) {
      return new Response(
        JSON.stringify({ suggestion: sectionConfig.opener }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const contextInfo = currentData ? `\n\nCurrent user data context: ${JSON.stringify(currentData)}` : '';
    
    const messages = [
      { role: "system", content: sectionConfig.system + contextInfo },
      ...conversationHistory,
    ];
    
    if (userInput) {
      messages.push({ role: "user", content: userInput });
    }

    console.log("Sending request to AI gateway for section:", section);

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: messages,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        console.error("Rate limit exceeded");
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        console.error("Usage limit reached");
        return new Response(
          JSON.stringify({ error: "AI usage limit reached. Please add credits to continue." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      throw new Error("AI gateway error");
    }

    const data = await response.json();
    const suggestion = data.choices[0].message.content.trim();
    console.log("AI response received successfully");

    return new Response(
      JSON.stringify({ suggestion }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error in vision-wizard-ai function:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
