import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // 1. Extract and validate authorization header
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      console.error("Missing authorization header");
      return new Response(
        JSON.stringify({ error: 'Missing authorization header' }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Extract the JWT token from the header
    const token = authHeader.replace('Bearer ', '');

    // 2. Create Supabase client with the user's JWT
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    );

    // 3. Get authenticated user from JWT - pass the token directly
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser(token);
    if (userError || !user) {
      console.error("Invalid or expired token:", userError);
      return new Response(
        JSON.stringify({ error: 'Invalid or expired token' }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("Authenticated user:", user.id);

    const { type, context, tone = "motivational", conversationMode = false, userInput, conversationHistory = [], wizardMode = false, currentStep, isResuming = false } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    // 4. Fetch user's actual long-term visions from database (don't trust client)
    let validatedLongTermVisions = null;
    if (type === "vision" && context?.longTermVisions) {
      const { data: actualVisions, error: visionError } = await supabaseClient
        .from('user_visions')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();
      
      if (!visionError && actualVisions) {
        validatedLongTermVisions = actualVisions;
        console.log("Fetched validated user visions from database");
      }
    }

    // 4b. Fetch user's past AARs for context (lessons learned, patterns)
    let aarContext = "";
    try {
      // Get user's team IDs first
      const { data: teamData } = await supabaseClient
        .from("team_members")
        .select("team_id")
        .eq("user_id", user.id)
        .eq("status", "active");

      if (teamData && teamData.length > 0) {
        const teamIds = teamData.map(t => t.team_id);
        
        // Fetch recent AARs (last 4) for context
        const { data: aars, error: aarsError } = await supabaseClient
          .from("after_action_reviews")
          .select("what_went_well, what_could_improve, lessons_learned, action_items, overall_rating, review_type, period_start, period_end")
          .in("team_id", teamIds)
          .eq("user_id", user.id)
          .order("period_end", { ascending: false })
          .limit(4);

        if (!aarsError && aars && aars.length > 0) {
          const aarSummaries = aars.map(aar => {
            const items: string[] = [];
            if (aar.lessons_learned) items.push(`Lessons: ${aar.lessons_learned}`);
            if (aar.what_went_well) items.push(`Strengths: ${aar.what_went_well}`);
            if (aar.what_could_improve) items.push(`Areas to improve: ${aar.what_could_improve}`);
            
            // Extract incomplete action items
            const actionItems = Array.isArray(aar.action_items) ? aar.action_items : [];
            const incompleteActions = actionItems.filter((a: any) => !a.completed).map((a: any) => a.text);
            if (incompleteActions.length > 0) {
              items.push(`Pending actions: ${incompleteActions.join('; ')}`);
            }
            
            return `[${aar.review_type} review, ${aar.period_start} to ${aar.period_end}]:\n${items.join('\n')}`;
          });
          
          aarContext = `\n\n📊 INSIGHTS FROM PAST AFTER ACTION REVIEWS:\nThe user has ${aars.length} recent AAR(s). Use these insights to inform your guidance:\n\n${aarSummaries.join('\n\n')}`;
          console.log("Fetched AAR context for battle plan guidance");
        }
      }
    } catch (aarError) {
      console.error("Error fetching AAR context (non-fatal):", aarError);
      // Continue without AAR context
    }

    // 5. If a planId is provided, validate the user owns it or is a team member
    if (context?.planId) {
      const { data: plan, error: planError } = await supabaseClient
        .from('battle_plans')
        .select('id, user_id, team_id')
        .eq('id', context.planId)
        .maybeSingle();
      
      if (planError || !plan) {
        console.error("Plan not found or unauthorized:", planError);
        return new Response(
          JSON.stringify({ error: 'Plan not found or unauthorized' }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Verify user is either the owner or an active team member
      if (plan.user_id !== user.id) {
        const { data: membership, error: memberError } = await supabaseClient
          .from('team_members')
          .select('id')
          .eq('team_id', plan.team_id)
          .eq('user_id', user.id)
          .eq('status', 'active')
          .maybeSingle();
        
        if (memberError || !membership) {
          console.error("User is not authorized to access this plan");
          return new Response(
            JSON.stringify({ error: 'Not authorized to access this plan' }),
            { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      }
      console.log("Plan access validated for user");
    }

    // Use validated visions instead of client-provided ones
    const safeContext = {
      ...context,
      longTermVisions: validatedLongTermVisions || context?.longTermVisions,
      aarContext
    };

    // Build context summary for better AI awareness when resuming
    let completedContextSummary = "";
    if (context?.completedData && Object.keys(context.completedData).length > 0) {
      const completed = context.completedData;
      const summaryParts: string[] = [];
      
      if (completed.vision) summaryParts.push(`Vision: "${completed.vision.substring(0, 100)}..."`);
      
      const quadrants = ["calibration", "connection", "condition", "contribution"];
      quadrants.forEach(q => {
        if (completed[`${q}_objective`]) summaryParts.push(`${q} objective completed`);
        if (completed[`${q}_primary_tactic`]) summaryParts.push(`${q} primary tactic completed`);
        if (completed[`${q}_secondary_tactics`]) summaryParts.push(`${q} secondary tactics completed`);
        if (completed[`${q}_checkpoints`]) summaryParts.push(`${q} checkpoints completed`);
      });
      
      if (summaryParts.length > 0) {
        completedContextSummary = `\n\nPREVIOUSLY COMPLETED: ${summaryParts.join(", ")}.`;
      }
    }

    let systemPrompt = "";
    let messages: any[] = [];

    const toneInstructions = {
      motivational: "Be encouraging and warm.",
      tactical: "Be direct and focused. No fluff.",
      professional: "Be structured and thoughtful.",
      casual: "Be conversational and relaxed.",
      "drill-sergeant": "Be demanding but caring.",
      coach: "Be a supportive mentor.",
      stoic: "Be reflective and grounded.",
      brotherhood: "Speak as a fellow warrior."
    };

    const selectedTone = toneInstructions[tone as keyof typeof toneInstructions] || toneInstructions.coach;

    // Core instruction - balanced: conversational but efficient
    const facilitatorCore = `You are a BATTLE PLAN COACH having a meaningful conversation. Be warm, insightful, and efficient.

APPROACH:
- Be conversational but purposeful - every exchange should move toward a concrete outcome
- When you have context (long-term vision, previous answers, AAR lessons), use it to make smart suggestions
- Reference past lessons learned and patterns from their After Action Reviews when relevant
- Propose drafts when you have enough context, but genuinely engage with their refinements
- Aim for 2-4 exchanges per item - enough for good refinement, not endless back-and-forth
- ${selectedTone}
${completedContextSummary}
${safeContext.aarContext || ""}

AVOID: Circular questioning, asking the same thing multiple ways, or proposing something then asking 5 clarifying questions.`;

    switch (type) {
      case "vision":
        // Build long-term vision context if available (using validated data)
        let longTermContext = "";
        if (safeContext.longTermVisions) {
          const v = safeContext.longTermVisions;
          if (v.vision_1_year || v.vision_5_year || v.vision_10_year) {
            longTermContext = `\n\nUser's long-term vision for context:`;
            if (v.vision_1_year) longTermContext += `\n- 1-Year: "${v.vision_1_year}"`;
            if (v.vision_5_year) longTermContext += `\n- 5-Year: "${v.vision_5_year}"`;
            if (v.vision_10_year) longTermContext += `\n- 10-Year: "${v.vision_10_year}"`;
          }
        }

        systemPrompt = `${facilitatorCore}

You're helping craft a COMPELLING PERSONAL VISION for a 90-day Battle Plan (ending ${safeContext.endDate || "in 12 weeks"}).${longTermContext}

This is NOT about goals, tactics, metrics, or milestones - those come later when we work through each of the 4 quadrants (Calibration, Connection, Condition, Contribution) in detail.

A personal vision is about WHO YOU ARE BECOMING and WHY IT MATTERS. It should:
- Paint a vivid picture of your future self and the life you're building
- Connect to your deeper values, purpose, and what drives you
- Be aspirational and inspiring - something that pulls you forward
- Feel personally meaningful, not generic

EXAMPLES of the right tone (but we want MORE depth):
- "My vision is to be a lifelong adventurer, traveling the world and exploring new cultures. I will build a life that allows me to embrace my curiosity and take risks."
- "I envision a future where I am a successful entrepreneur, using creativity and innovation to make a positive impact. I will build a business aligned with my values that creates opportunities for others."
- "My vision is to live a life of balance and harmony, pursuing my passions while prioritizing my physical, emotional, and spiritual health."
- "I want to help sensitive people overcome the fear of speaking through coaching. This is important because it makes me feel useful and connects me to my own sensitivity."

CONVERSATIONAL APPROACH:
1. If they have a long-term vision: Use it to help them articulate a 90-day vision that captures who they're becoming and why this journey matters. How does this quarter move them toward that bigger picture?

2. If no long-term vision: Ask powerful questions to uncover their deeper "why":
   - What kind of person do you want to become?
   - What would it mean for your life if you truly showed up for yourself these 90 days?
   - What are you really fighting for?

3. Help them craft a vision statement (3-5 sentences) that captures:
   - The transformation they're pursuing (who they're becoming)
   - Why it matters to them personally (values, purpose, impact)
   - How it connects to their deeper aspirations

4. Ask: "Does this capture what you're really fighting for? What resonates? What's missing?"

5. When confirmed: Format starting with "Your 90-Day Vision:" followed by the statement.

Remember: This is about identity, purpose, and meaning - NOT about specific goals or metrics. Those details come in the quadrant steps.`;

        if (conversationHistory.length === 0) {
          const hasLongTermVision = safeContext.longTermVisions?.vision_1_year || safeContext.longTermVisions?.vision_5_year;
          messages = [
            { role: "system", content: systemPrompt },
            { role: "user", content: hasLongTermVision 
              ? `I have my long-term vision set. Help me craft a compelling 90-day vision that moves me toward that bigger picture.`
              : `Help me define a compelling vision for the next 90 days.` }
          ];
        } else {
          messages = [
            { role: "system", content: systemPrompt },
            ...conversationHistory,
            { role: "user", content: userInput }
          ];
        }
        break;

      case "objective":
        const quadrantContext = {
          calibration: "mental, spiritual, and emotional growth - your inner game, mindset, faith, emotional resilience",
          connection: "relationships and community - the people who matter most to you",
          condition: "physical health and fitness - your body, energy, and vitality",
          contribution: "career, wealth, and giving back - building financial stability and making an impact"
        };
        
        systemPrompt = `${facilitatorCore}

You're helping define a SMART objective for the ${safeContext.quadrant?.toUpperCase()} quadrant (${quadrantContext[safeContext.quadrant as keyof typeof quadrantContext]}).

Their 90-Day Vision: "${safeContext.vision}"

CRITICAL: DO NOT pre-populate or suggest an objective immediately. You must ASK DISCOVERY QUESTIONS FIRST to understand their specific situation and desires for this quadrant.

LEVERAGING PAST LESSONS: If you have AAR context above, use it to:
- Reference specific lessons learned that relate to this quadrant
- Acknowledge past challenges they've faced and suggest how this objective can address them
- Build on strengths they've demonstrated
- Incorporate any pending action items that fit this quadrant

CONVERSATIONAL APPROACH:
1. FIRST, acknowledge their vision and connect it to this quadrant. If you have AAR insights, briefly reference relevant lessons: "I noticed from your past reviews that [insight]..." Then ask 1-2 powerful discovery questions such as:
   - "Looking at your vision, what aspect of ${safeContext.quadrant} feels most important to focus on?"
   - "What would success in ${safeContext.quadrant} look like for you by the end of 12 weeks?"
   - "What's been holding you back in this area?"
   - "What would change in your life if you truly showed up for your ${safeContext.quadrant}?"

2. LISTEN to their response and ask follow-up questions if needed to understand what truly matters to them.

3. ONLY AFTER understanding their direction, propose a specific, measurable objective. Present it warmly: "Based on what you've shared, here's what I'm thinking..." Then ask: "How does this land? Should we adjust?"

4. When confirmed: Format starting with "Your ${safeContext.quadrant?.charAt(0).toUpperCase()}${safeContext.quadrant?.slice(1)} Objective:"

The objective should be SMART - specific, measurable, achievable, relevant, time-bound. Include numbers, frequencies, or clear milestones.`;

        if (conversationHistory.length === 0) {
          messages = [
            { role: "system", content: systemPrompt },
            { role: "user", content: `I've completed my vision. Now help me define my ${safeContext.quadrant} objective. My vision is: "${safeContext.vision}"` }
          ];
        } else {
          messages = [
            { role: "system", content: systemPrompt },
            ...conversationHistory,
            { role: "user", content: userInput }
          ];
        }
        break;

      case "primary_tactic":
        systemPrompt = `${facilitatorCore}

Help define ONE primary daily tactic for this objective: "${safeContext.objective}"

LEVERAGING PAST LESSONS: If you have AAR context, consider:
- What daily habits worked well for them in past quarters?
- What challenges did they face with consistency? Suggest tactics that address those.
- Reference pending action items that could become daily habits.

CONVERSATIONAL APPROACH:
1. Propose the single most impactful daily habit that would drive progress on this objective. Think about what's both meaningful AND sustainable for 84 days straight.

2. Present it conversationally: "The daily habit that would move the needle most here is..." Then ask: "Is this realistic for your daily life? What might get in the way?"

3. If they have concerns or want alternatives: Discuss briefly, then propose an adjusted version that addresses their reality.

4. When confirmed: Output cleanly starting with "Your primary daily tactic:"

The tactic should be specific enough to know if you did it (e.g., "30 minutes of focused reading" not just "read more").`;

        if (conversationHistory.length === 0) {
          messages = [
            { role: "system", content: systemPrompt },
            { role: "user", content: `What's the most important daily habit for this objective?` }
          ];
        } else {
          messages = [
            { role: "system", content: systemPrompt },
            ...conversationHistory,
            { role: "user", content: userInput }
          ];
        }
        break;

      case "secondary_tactics":
        systemPrompt = `${facilitatorCore}

Help define 2-3 supporting daily tactics.
Objective: "${safeContext.objective}"
Primary tactic: "${safeContext.primaryTactic}"

LEVERAGING PAST LESSONS: If you have AAR context:
- Include pending action items from past reviews that fit as supporting tactics
- Build on habits that worked well in past quarters
- Avoid suggesting things they've struggled with unless addressing the root cause

CONVERSATIONAL APPROACH:
1. Propose 2-3 complementary daily habits that support the objective without duplicating the primary tactic. These should reinforce success.

2. Present as a numbered list with brief reasoning: "To support your main habit, I'd suggest..." Then ask: "Which of these resonate? Want to swap any out?"

3. If they want changes: Adjust based on their feedback - maybe they already do one of these, or one doesn't fit their lifestyle.

4. When confirmed: Output as a clean numbered list starting with "Here are your supporting tactics:"
   Example format:
   1. First tactic description
   2. Second tactic description
   3. Third tactic description

Keep tactics simple and stackable - things that can be done alongside the primary tactic without overwhelming.`;

        if (conversationHistory.length === 0) {
          messages = [
            { role: "system", content: systemPrompt },
            { role: "user", content: `Suggest some supporting daily habits that complement my main tactic.` }
          ];
        } else {
          messages = [
            { role: "system", content: systemPrompt },
            ...conversationHistory,
            { role: "user", content: userInput }
          ];
        }
        break;

      case "checkpoints":
        let week4Date = "week 4";
        let week8Date = "week 8";
        
        if (safeContext.startDate) {
          try {
            const start = new Date(safeContext.startDate);
            const week4 = new Date(start);
            week4.setDate(start.getDate() + 28);
            const week8 = new Date(start);
            week8.setDate(start.getDate() + 56);
            
            week4Date = week4.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
            week8Date = week8.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
          } catch (e) {
            console.error("Error calculating checkpoint dates:", e);
          }
        }

        systemPrompt = `${facilitatorCore}

Help set progress checkpoints for: "${safeContext.objective}"
Checkpoint dates: Day 30 (${week4Date}) and Day 60 (${week8Date})

CONVERSATIONAL APPROACH:
1. Propose specific, measurable milestones for both checkpoints. Think about realistic progress curves - where should they be at 1/3 and 2/3 of the way through?

2. Present conversationally: "For your 30-day check-in, I'm thinking... And by day 60..." Then ask: "Do these feel like the right pace? Too aggressive or too easy?"

3. If they want adjustments: Discuss their reasoning and propose refined milestones.

4. When confirmed: Output starting with "Here are your checkpoints:" followed by:
   **Day 30:** [milestone description]
   **Day 60:** [milestone description]

Milestones should be specific enough to clearly assess - numbers, completed actions, or observable outcomes.`;

        if (conversationHistory.length === 0) {
          messages = [
            { role: "system", content: systemPrompt },
            { role: "user", content: `Help me set meaningful 30 and 60 day checkpoints for this objective.` }
          ];
        } else {
          messages = [
            { role: "system", content: systemPrompt },
            ...conversationHistory,
            { role: "user", content: userInput }
          ];
        }
        break;

      case "non_negotiables":
        // Build a summary of all primary tactics from the quadrants
        const allTactics = [
          { quadrant: "Calibration", tactic: safeContext.calibrationTactic },
          { quadrant: "Connection", tactic: safeContext.connectionTactic },
          { quadrant: "Condition", tactic: safeContext.conditionTactic },
          { quadrant: "Contribution", tactic: safeContext.contributionTactic },
        ].filter(t => t.tactic);

        const tacticsContext = allTactics.length > 0 
          ? `Here are the primary tactics you've already defined:\n${allTactics.map(t => `- ${t.quadrant}: ${t.tactic}`).join('\n')}`
          : '';

        systemPrompt = `${facilitatorCore}

You're helping define Daily Non-Negotiables - the 6-8 foundational habits that will be tracked EVERY SINGLE DAY of the 12-week battle plan.

Their 90-Day Vision: "${safeContext.vision}"

${tacticsContext}

IMPORTANT CONTEXT:
Non-negotiables are DIFFERENT from the primary tactics. Primary tactics are specific to each quadrant's objective. Non-negotiables are the UNIVERSAL daily foundation that supports ALL four quadrants - things like morning routines, exercise, meditation, reading, planning, etc.

CONVERSATIONAL APPROACH:
1. FIRST, acknowledge their completed quadrant work and explain what non-negotiables are: "Now let's define your daily foundation - the non-negotiable habits you'll complete EVERY day, no exceptions. These are the keystone habits that make everything else easier."

2. Ask discovery questions:
   - "What morning or evening routines already serve you well?"
   - "What habits, when you do them consistently, make you feel unstoppable?"
   - "What's the ONE thing that, if you do it every day, changes everything?"

3. LISTEN to their responses and build a personalized list of 6-8 non-negotiables that:
   - Include foundational habits (exercise, meditation, reading, journaling, planning)
   - Incorporate their existing successful habits
   - Support all four quadrants holistically

4. Present as a numbered list: "Based on what you've shared, here are your daily non-negotiables..." Then ask: "Which resonate? What would you add or remove?"

5. When confirmed: Output as a clean numbered list starting with "Here are your daily non-negotiables:"
   Example format:
   1. Morning meditation (10 min)
   2. Exercise/movement (30 min)
   3. Reading (20 min)
   4. Journaling/reflection
   5. Daily planning session
   6. Evening review

These should be SIMPLE, TRACKABLE, and SUSTAINABLE for 84 consecutive days.`;

        if (conversationHistory.length === 0) {
          messages = [
            { role: "system", content: systemPrompt },
            { role: "user", content: `I've completed all four quadrants. Now help me define my daily non-negotiables - the foundational habits I'll track every single day.` }
          ];
        } else {
          messages = [
            { role: "system", content: systemPrompt },
            ...conversationHistory,
            { role: "user", content: userInput }
          ];
        }
        break;

      default:
        throw new Error("Invalid suggestion type");
    }

    console.log("Calling AI with type:", type, "for user:", user.id);

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: messages,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI usage limit reached. Please add credits to continue." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      throw new Error("AI gateway error");
    }

    const data = await response.json();
    const suggestion = data.choices[0].message.content.trim();

    console.log("AI response generated successfully for user:", user.id);

    return new Response(
      JSON.stringify({ suggestion }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error in battle-plan-ai function:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
