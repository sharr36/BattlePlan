import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { signIn, signUp } from "@/lib/supabase";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Shield, Users, Plus, Search, ArrowLeft, ArrowRight, Check } from "lucide-react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

type SignupStep = "account" | "team";
type TeamOption = "create" | "join" | "skip";

const Auth = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [signupStep, setSignupStep] = useState<SignupStep>("account");
  const [teamOption, setTeamOption] = useState<TeamOption>("join");
  const [accountData, setAccountData] = useState({ email: "", password: "", displayName: "" });
  const [teamData, setTeamData] = useState({ name: "", description: "", inviteCode: "" });
  const [foundTeam, setFoundTeam] = useState<{ id: string; name: string; description: string | null } | null>(null);
  const [searchError, setSearchError] = useState("");
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSignIn = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);

    const formData = new FormData(e.currentTarget);
    const email = formData.get("email") as string;
    const password = formData.get("password") as string;

    const { error } = await signIn(email, password);

    if (error) {
      toast({
        title: "Authentication Failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Welcome Back",
        description: "Authentication successful.",
      });
      navigate("/");
    }

    setIsLoading(false);
  };

  const handleAccountSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    setAccountData({
      email: formData.get("email") as string,
      password: formData.get("password") as string,
      displayName: formData.get("displayName") as string,
    });
    setSignupStep("team");
  };

  const searchTeamByCode = async () => {
    if (!teamData.inviteCode.trim()) {
      setSearchError("Please enter an invite code");
      return;
    }

    setIsLoading(true);
    setSearchError("");
    setFoundTeam(null);

    try {
      // Search for team by invite code from the secure invite codes table
      const { data: inviteData, error } = await supabase
        .from("team_invite_codes")
        .select("team_id, teams(id, name, description)")
        .eq("invite_code", teamData.inviteCode.toUpperCase().trim())
        .maybeSingle();

      const data = inviteData?.teams as { id: string; name: string; description: string | null } | null;

      if (error) throw error;

      if (data) {
        setFoundTeam(data);
      } else {
        setSearchError("No team found with that invite code");
      }
    } catch (error: any) {
      setSearchError("Error searching for team");
    } finally {
      setIsLoading(false);
    }
  };

  const handleFinalSignup = async () => {
    setIsLoading(true);

    try {
      // Create the account
      const { error: signUpError, data: authData } = await signUp(
        accountData.email,
        accountData.password,
        accountData.displayName
      );

      if (signUpError) throw signUpError;

      // Get the user ID from the session
      const { data: sessionData } = await supabase.auth.getSession();
      const userId = sessionData?.session?.user?.id;

      if (!userId) {
        toast({
          title: "Account Created",
          description: "Please sign in to continue.",
        });
        setSignupStep("account");
        setIsLoading(false);
        return;
      }

      // Handle team creation or joining
      if (teamOption === "create" && teamData.name.trim()) {
        // Create a new team
        const { data: newTeam, error: teamError } = await supabase
          .from("teams")
          .insert({
            name: teamData.name.trim(),
            description: teamData.description.trim() || null,
            created_by: userId,
          })
          .select()
          .single();

        if (teamError) throw teamError;

        // Add user as team leader
        const { error: memberError } = await supabase
          .from("team_members")
          .insert({
            team_id: newTeam.id,
            user_id: userId,
            role: "leader",
            status: "active",
          });

        if (memberError) throw memberError;

        toast({
          title: "Welcome to Battle Plan!",
          description: `Account created and team "${teamData.name}" has been set up.`,
        });
      } else if (teamOption === "join" && foundTeam) {
        // Join existing team
        const { error: memberError } = await supabase
          .from("team_members")
          .insert({
            team_id: foundTeam.id,
            user_id: userId,
            role: "member",
            status: "pending",
          });

        if (memberError) throw memberError;

        toast({
          title: "Welcome to Battle Plan!",
          description: `Account created and request to join "${foundTeam.name}" submitted.`,
        });
      } else {
        toast({
          title: "Mission Accepted",
          description: "Account created successfully. You can join or create a team later.",
        });
      }

      navigate("/");
    } catch (error: any) {
      toast({
        title: "Registration Failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const renderSignupStep = () => {
    if (signupStep === "account") {
      return (
        <form onSubmit={handleAccountSubmit}>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="signup-name">Display Name</Label>
              <Input
                id="signup-name"
                name="displayName"
                type="text"
                placeholder="John Operator"
                defaultValue={accountData.displayName}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="signup-email">Email</Label>
              <Input
                id="signup-email"
                name="email"
                type="email"
                placeholder="you@example.com"
                defaultValue={accountData.email}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="signup-password">Password</Label>
              <Input
                id="signup-password"
                name="password"
                type="password"
                defaultValue={accountData.password}
                required
                minLength={6}
              />
            </div>
          </CardContent>
          <CardFooter>
            <Button type="submit" className="w-full">
              Next: Team Setup
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </CardFooter>
        </form>
      );
    }

    return (
      <div>
        <CardContent className="space-y-6">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => setSignupStep("account")}
              className="p-0 h-auto"
            >
              <ArrowLeft className="w-4 h-4 mr-1" />
              Back
            </Button>
            <span>Step 2: Team Setup</span>
          </div>

          <RadioGroup
            value={teamOption}
            onValueChange={(value) => {
              setTeamOption(value as TeamOption);
              setFoundTeam(null);
              setSearchError("");
            }}
            className="space-y-3"
          >
            <div className="flex items-center space-x-3 p-3 rounded-lg border border-border hover:bg-muted/50 cursor-pointer">
              <RadioGroupItem value="join" id="join" />
              <Label htmlFor="join" className="flex items-center gap-2 cursor-pointer flex-1">
                <Search className="w-4 h-4 text-primary" />
                Join an existing team
              </Label>
            </div>
            <div className="flex items-center space-x-3 p-3 rounded-lg border border-border hover:bg-muted/50 cursor-pointer">
              <RadioGroupItem value="create" id="create" />
              <Label htmlFor="create" className="flex items-center gap-2 cursor-pointer flex-1">
                <Plus className="w-4 h-4 text-primary" />
                Create a new team
              </Label>
            </div>
            <div className="flex items-center space-x-3 p-3 rounded-lg border border-border hover:bg-muted/50 cursor-pointer">
              <RadioGroupItem value="skip" id="skip" />
              <Label htmlFor="skip" className="flex items-center gap-2 cursor-pointer flex-1">
                <Users className="w-4 h-4 text-muted-foreground" />
                Skip for now
              </Label>
            </div>
          </RadioGroup>

          {teamOption === "join" && (
            <div className="space-y-4 pt-2">
              <div className="space-y-2">
                <Label htmlFor="invite-code">Team Invite Code</Label>
                <div className="flex gap-2">
                  <Input
                    id="invite-code"
                    placeholder="Enter 6-character code"
                    value={teamData.inviteCode}
                    onChange={(e) => {
                      setTeamData({ ...teamData, inviteCode: e.target.value.toUpperCase() });
                      setFoundTeam(null);
                      setSearchError("");
                    }}
                    maxLength={6}
                    className="font-mono uppercase"
                  />
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={searchTeamByCode}
                    disabled={isLoading}
                  >
                    <Search className="w-4 h-4" />
                  </Button>
                </div>
                {searchError && (
                  <p className="text-sm text-destructive">{searchError}</p>
                )}
              </div>

              {foundTeam && (
                <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
                  <div className="flex items-center gap-2 mb-1">
                    <Check className="w-4 h-4 text-primary" />
                    <span className="font-medium text-primary">Team Found!</span>
                  </div>
                  <p className="font-semibold">{foundTeam.name}</p>
                  {foundTeam.description && (
                    <p className="text-sm text-muted-foreground mt-1">{foundTeam.description}</p>
                  )}
                </div>
              )}
            </div>
          )}

          {teamOption === "create" && (
            <div className="space-y-4 pt-2">
              <div className="space-y-2">
                <Label htmlFor="team-name">Team Name</Label>
                <Input
                  id="team-name"
                  placeholder="Alpha Squad"
                  value={teamData.name}
                  onChange={(e) => setTeamData({ ...teamData, name: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="team-description">Description (optional)</Label>
                <Input
                  id="team-description"
                  placeholder="Our mission..."
                  value={teamData.description}
                  onChange={(e) => setTeamData({ ...teamData, description: e.target.value })}
                />
              </div>
            </div>
          )}

          {teamOption === "skip" && (
            <p className="text-sm text-muted-foreground pt-2">
              You can create or join a team later from your dashboard.
            </p>
          )}
        </CardContent>
        <CardFooter>
          <Button
            type="button"
            className="w-full"
            onClick={handleFinalSignup}
            disabled={isLoading || (teamOption === "join" && !foundTeam) || (teamOption === "create" && !teamData.name.trim())}
          >
            {isLoading ? "Creating Account..." : "Complete Registration"}
          </Button>
        </CardFooter>
      </div>
    );
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="w-full max-w-md animate-fade-in">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-primary mb-4">
            <Shield className="w-10 h-10 text-primary-foreground" />
          </div>
          <h1 className="text-4xl font-display font-bold text-foreground mb-2">
            BATTLE PLAN
          </h1>
          <p className="text-muted-foreground">Strategic Planning & Team Accountability</p>
        </div>

        <Card className="shadow-tactical">
          <Tabs defaultValue="signin" className="w-full">
            <CardHeader>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="signin" onClick={() => setSignupStep("account")}>Sign In</TabsTrigger>
                <TabsTrigger value="signup">Sign Up</TabsTrigger>
              </TabsList>
            </CardHeader>

            <TabsContent value="signin">
              <form onSubmit={handleSignIn}>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="signin-email">Email</Label>
                    <Input
                      id="signin-email"
                      name="email"
                      type="email"
                      placeholder="you@example.com"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="signin-password">Password</Label>
                    <Input
                      id="signin-password"
                      name="password"
                      type="password"
                      required
                    />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button type="submit" className="w-full" disabled={isLoading}>
                    {isLoading ? "Authenticating..." : "Sign In"}
                  </Button>
                </CardFooter>
              </form>
            </TabsContent>

            <TabsContent value="signup">
              {renderSignupStep()}
            </TabsContent>
          </Tabs>
        </Card>
      </div>
    </div>
  );
};

export default Auth;
