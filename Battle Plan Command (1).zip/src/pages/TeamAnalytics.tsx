import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { ArrowLeft, TrendingUp, Users, Target, Activity } from "lucide-react";

interface TeamMember {
  user_id: string;
  profiles: {
    display_name: string;
    email: string;
  };
}

interface MemberStats {
  userId: string;
  displayName: string;
  email: string;
  activePlans: number;
  completedMetrics: number;
  totalMetricsExpected: number;
  completionRate: number;
  currentStreak: number;
}

export default function TeamAnalytics() {
  const { teamId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [team, setTeam] = useState<any>(null);
  const [isLeaderOrXO, setIsLeaderOrXO] = useState(false);
  const [memberStats, setMemberStats] = useState<MemberStats[]>([]);
  const [teamOverview, setTeamOverview] = useState({
    totalMembers: 0,
    activePlans: 0,
    avgCompletionRate: 0,
    avgStreak: 0,
  });

  useEffect(() => {
    if (teamId) {
      checkPermissions();
      loadTeamData();
    }
  }, [teamId]);

  const checkPermissions = async () => {
    try {
      const { data, error } = await supabase
        .from("team_members")
        .select("role")
        .eq("team_id", teamId)
        .eq("user_id", user?.id)
        .eq("status", "active")
        .single();

      if (error) throw error;

      const hasPermission = data.role === "leader" || data.role === "xo";
      setIsLeaderOrXO(hasPermission);

      if (!hasPermission) {
        toast.error("You don't have permission to view team analytics");
        navigate(`/teams/${teamId}`);
      }
    } catch (error) {
      console.error("Error checking permissions:", error);
      navigate(`/teams/${teamId}`);
    }
  };

  const loadTeamData = async () => {
    setLoading(true);
    try {
      // Load team info
      const { data: teamData, error: teamError } = await supabase
        .from("teams")
        .select("*")
        .eq("id", teamId)
        .single();

      if (teamError) throw teamError;
      setTeam(teamData);

      // Load team members
      const { data: membersData, error: membersError } = await supabase
        .from("team_members")
        .select(`
          user_id,
          profiles (
            display_name,
            email
          )
        `)
        .eq("team_id", teamId)
        .eq("status", "active");

      if (membersError) throw membersError;

      // Calculate stats for each member
      const stats: MemberStats[] = [];
      for (const member of membersData as TeamMember[]) {
        const memberStat = await calculateMemberStats(member);
        stats.push(memberStat);
      }

      setMemberStats(stats);

      // Calculate team overview
      const overview = {
        totalMembers: stats.length,
        activePlans: stats.reduce((sum, s) => sum + s.activePlans, 0),
        avgCompletionRate: stats.length > 0
          ? Math.round(stats.reduce((sum, s) => sum + s.completionRate, 0) / stats.length)
          : 0,
        avgStreak: stats.length > 0
          ? Math.round(stats.reduce((sum, s) => sum + s.currentStreak, 0) / stats.length)
          : 0,
      };

      setTeamOverview(overview);
    } catch (error) {
      console.error("Error loading team data:", error);
      toast.error("Failed to load team analytics");
    } finally {
      setLoading(false);
    }
  };

  const calculateMemberStats = async (member: TeamMember): Promise<MemberStats> => {
    // Get active battle plans
    const { data: plans } = await supabase
      .from("battle_plans")
      .select("id, start_date, end_date")
      .eq("user_id", member.user_id)
      .eq("team_id", teamId)
      .eq("active", true);

    const activePlans = plans?.length || 0;

    // Get completed weekly metrics
    const { data: metrics } = await supabase
      .from("weekly_metrics")
      .select("id")
      .eq("user_id", member.user_id)
      .in("plan_id", plans?.map(p => p.id) || []);

    const completedMetrics = metrics?.length || 0;

    // Calculate expected metrics (weeks elapsed * number of plans)
    let totalMetricsExpected = 0;
    if (plans) {
      for (const plan of plans) {
        const startDate = new Date(plan.start_date);
        const now = new Date();
        const weeksElapsed = Math.floor((now.getTime() - startDate.getTime()) / (7 * 24 * 60 * 60 * 1000));
        totalMetricsExpected += Math.min(Math.max(weeksElapsed, 0), 12);
      }
    }

    const completionRate = totalMetricsExpected > 0
      ? Math.round((completedMetrics / totalMetricsExpected) * 100)
      : 0;

    // Calculate streak
    const { data: dailyLogs } = await supabase
      .from("daily_logs")
      .select("log_date")
      .eq("user_id", member.user_id)
      .eq("team_id", teamId)
      .order("log_date", { ascending: false });

    let currentStreak = 0;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (dailyLogs) {
      for (let i = 0; i < dailyLogs.length; i++) {
        const logDate = new Date(dailyLogs[i].log_date);
        logDate.setHours(0, 0, 0, 0);
        const expectedDate = new Date(today);
        expectedDate.setDate(today.getDate() - i);
        expectedDate.setHours(0, 0, 0, 0);

        if (logDate.getTime() === expectedDate.getTime()) {
          currentStreak++;
        } else {
          break;
        }
      }
    }

    return {
      userId: member.user_id,
      displayName: member.profiles?.display_name || "Unknown",
      email: member.profiles?.email || "",
      activePlans,
      completedMetrics,
      totalMetricsExpected,
      completionRate,
      currentStreak,
    };
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="text-muted-foreground">Loading analytics...</div>
        </div>
      </div>
    );
  }

  if (!isLeaderOrXO) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate(`/teams/${teamId}`)}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-display font-bold">Team Analytics</h1>
              <p className="text-sm text-muted-foreground">{team?.name}</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="space-y-6">
          {/* Team Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Total Members</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{teamOverview.totalMembers}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Active Plans</CardTitle>
                <Target className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{teamOverview.activePlans}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Avg Completion</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{teamOverview.avgCompletionRate}%</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Avg Streak</CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{teamOverview.avgStreak} days</div>
              </CardContent>
            </Card>
          </div>

          {/* Member Statistics */}
          <Card>
            <CardHeader>
              <CardTitle>Member Progress</CardTitle>
              <CardDescription>
                Individual performance metrics for each team member
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {memberStats.map((stat) => (
                  <div key={stat.userId} className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-semibold">{stat.displayName}</h4>
                        <p className="text-sm text-muted-foreground">{stat.email}</p>
                      </div>
                      <div className="flex gap-2">
                        <Badge variant="outline">
                          {stat.activePlans} {stat.activePlans === 1 ? "Plan" : "Plans"}
                        </Badge>
                        <Badge variant="secondary">
                          🔥 {stat.currentStreak} day streak
                        </Badge>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">
                          Weekly Metrics: {stat.completedMetrics} / {stat.totalMetricsExpected}
                        </span>
                        <span className="font-semibold">{stat.completionRate}%</span>
                      </div>
                      <Progress value={stat.completionRate} />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
