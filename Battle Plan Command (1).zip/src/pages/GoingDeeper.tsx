import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  ArrowLeft, Save, Loader2, Target, Heart, Sparkles, Compass, 
  Brain, Briefcase, Users, Wallet, Mountain, Activity, Scale,
  HelpCircle, Camera, TrendingUp, DollarSign, Clock, Calendar,
  MessageCircle
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { VisionAIChat, AIAssistButton } from "@/components/VisionAIChat";

interface LifeCategory {
  target1: string;
  target2: string;
  target3: string;
  status1: string;
  status2: string;
  status3: string;
}

interface FormData {
  yearly_theme: string;
  photo_url: string;
  // Financial Analysis
  horizontal_income_current: string;
  horizontal_income_goal: string;
  vertical_income_current: string;
  vertical_income_goal: string;
  total_gross_income_current: string;
  total_gross_income_goal: string;
  personal_expenses: string;
  personal_taxes: string;
  left_to_invest: string;
  gross_asset_value_current: string;
  gross_asset_value_goal: string;
  total_debt_current: string;
  total_debt_goal: string;
  net_worth_current: string;
  net_worth_goal: string;
  recourse_debt: string;
  recourse_debt_percent: string;
  liquidity: string;
  financial_freedom_percent: string;
  // Contribution
  financial_contribution_current: string;
  financial_contribution_goal: string;
  time_contribution_current: string;
  time_contribution_goal: string;
  hourly_rate: string;
  total_contributed: string;
  give_to_income_ratio: string;
  // Body Stats
  weight: string;
  body_fat: string;
  gb_9: string;
  blood_pressure: string;
  lhi: string;
  // Highlights
  highlight_reel: string[];
  upcoming_highlights: string[];
  // Bucket List
  bucket_list: string[];
  // Life Categories (8 areas with status)
  life_categories: Record<string, LifeCategory>;
  // Accountability
  accountability_needs: string;
  help_needed: string;
}

const LIFE_CATEGORIES = [
  { id: "health", label: "Health / Nutrition", icon: Heart, color: "text-red-400" },
  { id: "spiritual", label: "Spiritual / Contribution", icon: Sparkles, color: "text-purple-400" },
  { id: "adventure", label: "Lifestyle / Adventure", icon: Compass, color: "text-orange-400" },
  { id: "personal_growth", label: "Personal Growth / Intellectual", icon: Brain, color: "text-blue-400" },
  { id: "career", label: "Business / Career", icon: Briefcase, color: "text-green-400" },
  { id: "relationships", label: "Friends / Family / Relationships", icon: Users, color: "text-pink-400" },
  { id: "financial", label: "Financial / Investment", icon: Wallet, color: "text-yellow-400" },
  { id: "community", label: "Environment / Tribe", icon: Mountain, color: "text-cyan-400" },
];

const defaultFormData: FormData = {
  yearly_theme: "",
  photo_url: "",
  horizontal_income_current: "",
  horizontal_income_goal: "",
  vertical_income_current: "",
  vertical_income_goal: "",
  total_gross_income_current: "",
  total_gross_income_goal: "",
  personal_expenses: "",
  personal_taxes: "",
  left_to_invest: "",
  gross_asset_value_current: "",
  gross_asset_value_goal: "",
  total_debt_current: "",
  total_debt_goal: "",
  net_worth_current: "",
  net_worth_goal: "",
  recourse_debt: "",
  recourse_debt_percent: "",
  liquidity: "",
  financial_freedom_percent: "",
  financial_contribution_current: "",
  financial_contribution_goal: "",
  time_contribution_current: "",
  time_contribution_goal: "",
  hourly_rate: "",
  total_contributed: "",
  give_to_income_ratio: "",
  weight: "",
  body_fat: "",
  gb_9: "",
  blood_pressure: "",
  lhi: "",
  highlight_reel: ["", "", "", "", ""],
  upcoming_highlights: ["", "", "", "", ""],
  bucket_list: ["", "", "", "", ""],
  life_categories: {},
  accountability_needs: "",
  help_needed: "",
};

export default function GoingDeeper() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState<FormData>(defaultFormData);
  const [teamId, setTeamId] = useState<string | null>(null);
  const [aiChatOpen, setAiChatOpen] = useState(false);
  const [aiSection, setAiSection] = useState("general");

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    try {
      // Load team membership
      const { data: teamData } = await supabase
        .from("team_members")
        .select("team_id")
        .eq("user_id", user?.id)
        .eq("status", "active")
        .limit(1)
        .maybeSingle();
      
      if (teamData) {
        setTeamId(teamData.team_id);
      }

      // Load existing vision data
      const { data, error } = await supabase
        .from("user_visions")
        .select("*")
        .eq("user_id", user?.id)
        .maybeSingle();

      if (error && error.code !== "PGRST116") throw error;

      if (data) {
        // Merge existing data with form structure
        const lifeCategoriesData = data.life_categories as unknown as Record<string, LifeCategory> | null;
        const bucketListData = data.bucket_list as unknown as string[] | null;
        const bodyMetricsData = data.body_metrics as unknown as Record<string, string> | null;
        const financialMetricsData = data.financial_metrics as unknown as Record<string, string> | null;
        
        const existingData = {
          yearly_theme: data.yearly_theme || "",
          life_categories: lifeCategoriesData || {},
          bucket_list: bucketListData || ["", "", "", "", ""],
          accountability_needs: data.accountability_needs || "",
          help_needed: data.help_needed || "",
          // Parse body_metrics for legacy data
          ...(bodyMetricsData ? {
            weight: bodyMetricsData.weight || "",
            body_fat: bodyMetricsData.body_fat || "",
            blood_pressure: bodyMetricsData.blood_pressure || "",
          } : {}),
          ...(financialMetricsData ? {
            net_worth_goal: financialMetricsData.net_worth_goal || "",
          } : {}),
        };
        setFormData(prev => ({ ...prev, ...existingData }));
      }
    } catch (error) {
      console.error("Error loading data:", error);
      toast.error("Failed to load your vision data");
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      // Transform form data for storage
      const bodyMetrics = {
        weight: formData.weight,
        body_fat: formData.body_fat,
        gb_9: formData.gb_9,
        blood_pressure: formData.blood_pressure,
        lhi: formData.lhi,
      };

      const financialMetrics = {
        horizontal_income_current: formData.horizontal_income_current,
        horizontal_income_goal: formData.horizontal_income_goal,
        vertical_income_current: formData.vertical_income_current,
        vertical_income_goal: formData.vertical_income_goal,
        total_gross_income_current: formData.total_gross_income_current,
        total_gross_income_goal: formData.total_gross_income_goal,
        personal_expenses: formData.personal_expenses,
        personal_taxes: formData.personal_taxes,
        left_to_invest: formData.left_to_invest,
        gross_asset_value_current: formData.gross_asset_value_current,
        gross_asset_value_goal: formData.gross_asset_value_goal,
        total_debt_current: formData.total_debt_current,
        total_debt_goal: formData.total_debt_goal,
        net_worth_current: formData.net_worth_current,
        net_worth_goal: formData.net_worth_goal,
        recourse_debt: formData.recourse_debt,
        recourse_debt_percent: formData.recourse_debt_percent,
        liquidity: formData.liquidity,
        financial_freedom_percent: formData.financial_freedom_percent,
        financial_contribution_current: formData.financial_contribution_current,
        financial_contribution_goal: formData.financial_contribution_goal,
        time_contribution_current: formData.time_contribution_current,
        time_contribution_goal: formData.time_contribution_goal,
        hourly_rate: formData.hourly_rate,
        total_contributed: formData.total_contributed,
        give_to_income_ratio: formData.give_to_income_ratio,
        highlight_reel: formData.highlight_reel,
        upcoming_highlights: formData.upcoming_highlights,
      };

      if (!user?.id) {
        toast.error("You must be logged in to save");
        return;
      }

      const upsertData = {
        user_id: user.id,
        team_id: teamId,
        yearly_theme: formData.yearly_theme || null,
        life_categories: formData.life_categories,
        body_metrics: bodyMetrics,
        financial_metrics: financialMetrics,
        bucket_list: formData.bucket_list,
        accountability_needs: formData.accountability_needs || null,
        help_needed: formData.help_needed || null,
      };

      const { error } = await supabase
        .from("user_visions")
        .upsert(upsertData as any, { onConflict: "user_id" });

      if (error) throw error;
      toast.success("Vision saved successfully!");
    } catch (error) {
      console.error("Error saving:", error);
      toast.error("Failed to save vision");
    } finally {
      setSaving(false);
    }
  };

  const updateField = (field: keyof FormData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const updateLifeCategory = (categoryId: string, field: keyof LifeCategory, value: string) => {
    setFormData(prev => ({
      ...prev,
      life_categories: {
        ...prev.life_categories,
        [categoryId]: {
          ...(prev.life_categories[categoryId] || { target1: "", target2: "", target3: "", status1: "", status2: "", status3: "" }),
          [field]: value,
        },
      },
    }));
  };

  const updateArrayField = (field: "bucket_list" | "highlight_reel" | "upcoming_highlights", index: number, value: string) => {
    setFormData(prev => {
      const arr = [...prev[field]];
      arr[index] = value;
      return { ...prev, [field]: arr };
    });
  };

  const handleAICopyToField = (content: string, section: string) => {
    // Map section to appropriate field and update it
    switch (section) {
      case "yearly_theme":
        updateField("yearly_theme", content);
        break;
      case "accountability":
        updateField("accountability_needs", content);
        break;
      case "bucket_list":
        // Find first empty bucket list slot or append
        const bucketIndex = formData.bucket_list.findIndex(item => !item.trim());
        if (bucketIndex !== -1) {
          updateArrayField("bucket_list", bucketIndex, content);
        } else {
          updateField("bucket_list", [...formData.bucket_list, content]);
        }
        break;
      default:
        // For other sections, copy to clipboard as fallback
        navigator.clipboard.writeText(content);
        break;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-xl font-bold flex items-center gap-2">
                <Target className="h-5 w-5 text-primary" />
                Going Deeper - One Sheet Vision
              </h1>
              <p className="text-sm text-muted-foreground">Your comprehensive life planning worksheet</p>
            </div>
          </div>
          <Button onClick={handleSave} disabled={saving}>
            {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
            Save Vision
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 max-w-6xl space-y-8">
        {/* Theme & Photo Section */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-primary" />
                Theme for the Year
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => { setAiSection("yearly_theme"); setAiChatOpen(true); }}
                className="gap-1 text-muted-foreground hover:text-primary"
              >
                <MessageCircle className="h-4 w-4" />
                AI Help
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <Input
              placeholder="e.g., Year of Discipline, Build the Foundation, Breakthrough..."
              value={formData.yearly_theme}
              onChange={(e) => updateField("yearly_theme", e.target.value)}
              className="text-lg font-semibold"
            />
          </CardContent>
        </Card>

        {/* Financial Analysis */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-green-500" />
                  Financial Analysis
                </CardTitle>
                <CardDescription>Track your income, assets, and net worth</CardDescription>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => { setAiSection("financial"); setAiChatOpen(true); }}
                className="gap-1 text-muted-foreground hover:text-primary"
              >
                <MessageCircle className="h-4 w-4" />
                AI Help
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {/* Income */}
              <div className="space-y-3">
                <h4 className="font-medium text-sm text-muted-foreground">Income</h4>
                <div className="space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label className="text-xs">Horizontal Income (Current)</Label>
                      <Input placeholder="$0" value={formData.horizontal_income_current} onChange={(e) => updateField("horizontal_income_current", e.target.value)} className="h-8" />
                    </div>
                    <div>
                      <Label className="text-xs">Goal</Label>
                      <Input placeholder="$0" value={formData.horizontal_income_goal} onChange={(e) => updateField("horizontal_income_goal", e.target.value)} className="h-8" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label className="text-xs">Vertical Income (Current)</Label>
                      <Input placeholder="$0" value={formData.vertical_income_current} onChange={(e) => updateField("vertical_income_current", e.target.value)} className="h-8" />
                    </div>
                    <div>
                      <Label className="text-xs">Goal</Label>
                      <Input placeholder="$0" value={formData.vertical_income_goal} onChange={(e) => updateField("vertical_income_goal", e.target.value)} className="h-8" />
                    </div>
                  </div>
                  <div>
                    <Label className="text-xs">Personal Expenses</Label>
                    <Input placeholder="$0" value={formData.personal_expenses} onChange={(e) => updateField("personal_expenses", e.target.value)} className="h-8" />
                  </div>
                  <div>
                    <Label className="text-xs">Personal Taxes</Label>
                    <Input placeholder="$0" value={formData.personal_taxes} onChange={(e) => updateField("personal_taxes", e.target.value)} className="h-8" />
                  </div>
                  <div>
                    <Label className="text-xs">Left to Invest</Label>
                    <Input placeholder="$0" value={formData.left_to_invest} onChange={(e) => updateField("left_to_invest", e.target.value)} className="h-8" />
                  </div>
                </div>
              </div>

              {/* Assets & Debt */}
              <div className="space-y-3">
                <h4 className="font-medium text-sm text-muted-foreground">Assets & Debt</h4>
                <div className="space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label className="text-xs">Gross Asset Value (Current)</Label>
                      <Input placeholder="$0" value={formData.gross_asset_value_current} onChange={(e) => updateField("gross_asset_value_current", e.target.value)} className="h-8" />
                    </div>
                    <div>
                      <Label className="text-xs">Goal</Label>
                      <Input placeholder="$0" value={formData.gross_asset_value_goal} onChange={(e) => updateField("gross_asset_value_goal", e.target.value)} className="h-8" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label className="text-xs">Total Debt (Current)</Label>
                      <Input placeholder="$0" value={formData.total_debt_current} onChange={(e) => updateField("total_debt_current", e.target.value)} className="h-8" />
                    </div>
                    <div>
                      <Label className="text-xs">Goal</Label>
                      <Input placeholder="$0" value={formData.total_debt_goal} onChange={(e) => updateField("total_debt_goal", e.target.value)} className="h-8" />
                    </div>
                  </div>
                  <div>
                    <Label className="text-xs">Recourse Debt</Label>
                    <Input placeholder="$0" value={formData.recourse_debt} onChange={(e) => updateField("recourse_debt", e.target.value)} className="h-8" />
                  </div>
                  <div>
                    <Label className="text-xs">Liquidity</Label>
                    <Input placeholder="$0" value={formData.liquidity} onChange={(e) => updateField("liquidity", e.target.value)} className="h-8" />
                  </div>
                </div>
              </div>

              {/* Net Worth */}
              <div className="space-y-3">
                <h4 className="font-medium text-sm text-muted-foreground">Net Worth & Freedom</h4>
                <div className="space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label className="text-xs">Net Worth (Current)</Label>
                      <Input placeholder="$0" value={formData.net_worth_current} onChange={(e) => updateField("net_worth_current", e.target.value)} className="h-8" />
                    </div>
                    <div>
                      <Label className="text-xs">Goal</Label>
                      <Input placeholder="$0" value={formData.net_worth_goal} onChange={(e) => updateField("net_worth_goal", e.target.value)} className="h-8" />
                    </div>
                  </div>
                  <div>
                    <Label className="text-xs">Financial Freedom %</Label>
                    <Input placeholder="0%" value={formData.financial_freedom_percent} onChange={(e) => updateField("financial_freedom_percent", e.target.value)} className="h-8" />
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Genuine Contribution */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Heart className="h-5 w-5 text-pink-500" />
              Genuine Contribution
            </CardTitle>
            <CardDescription>Track your financial and time contributions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <div className="space-y-2">
                <Label className="text-xs">Financial Contribution (Current)</Label>
                <Input placeholder="$0" value={formData.financial_contribution_current} onChange={(e) => updateField("financial_contribution_current", e.target.value)} className="h-8" />
                <Label className="text-xs">Goal</Label>
                <Input placeholder="$0" value={formData.financial_contribution_goal} onChange={(e) => updateField("financial_contribution_goal", e.target.value)} className="h-8" />
              </div>
              <div className="space-y-2">
                <Label className="text-xs">Time Contribution Hrs (Current)</Label>
                <Input placeholder="0 hrs" value={formData.time_contribution_current} onChange={(e) => updateField("time_contribution_current", e.target.value)} className="h-8" />
                <Label className="text-xs">Goal</Label>
                <Input placeholder="0 hrs" value={formData.time_contribution_goal} onChange={(e) => updateField("time_contribution_goal", e.target.value)} className="h-8" />
              </div>
              <div className="space-y-2">
                <Label className="text-xs">Hourly Rate</Label>
                <Input placeholder="$0/hr" value={formData.hourly_rate} onChange={(e) => updateField("hourly_rate", e.target.value)} className="h-8" />
                <Label className="text-xs">Total Contributed</Label>
                <Input placeholder="$0" value={formData.total_contributed} onChange={(e) => updateField("total_contributed", e.target.value)} className="h-8" />
              </div>
              <div className="space-y-2">
                <Label className="text-xs">Give to Income Ratio</Label>
                <Input placeholder="0%" value={formData.give_to_income_ratio} onChange={(e) => updateField("give_to_income_ratio", e.target.value)} className="h-8" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Current Body Stats */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5 text-red-500" />
              Current Body Stats
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-5">
              <div>
                <Label className="text-xs">Weight</Label>
                <Input placeholder="e.g., 180 lbs" value={formData.weight} onChange={(e) => updateField("weight", e.target.value)} className="h-8" />
              </div>
              <div>
                <Label className="text-xs">Body Fat %</Label>
                <Input placeholder="e.g., 15%" value={formData.body_fat} onChange={(e) => updateField("body_fat", e.target.value)} className="h-8" />
              </div>
              <div>
                <Label className="text-xs">GB 9</Label>
                <Input placeholder="Score" value={formData.gb_9} onChange={(e) => updateField("gb_9", e.target.value)} className="h-8" />
              </div>
              <div>
                <Label className="text-xs">Blood Pressure</Label>
                <Input placeholder="e.g., 120/80" value={formData.blood_pressure} onChange={(e) => updateField("blood_pressure", e.target.value)} className="h-8" />
              </div>
              <div>
                <Label className="text-xs">LHI</Label>
                <Input placeholder="Score" value={formData.lhi} onChange={(e) => updateField("lhi", e.target.value)} className="h-8" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Highlights */}
        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-blue-500" />
                Past Year Highlight Reel
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {formData.highlight_reel.map((item, index) => (
                <div key={index} className="flex items-center gap-2">
                  <Badge variant="outline" className="w-6 h-6 flex items-center justify-center p-0">{index + 1}</Badge>
                  <Input
                    placeholder={`Highlight ${index + 1}...`}
                    value={item}
                    onChange={(e) => updateArrayField("highlight_reel", index, e.target.value)}
                  />
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-green-500" />
                Upcoming Year Highlights
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {formData.upcoming_highlights.map((item, index) => (
                <div key={index} className="flex items-center gap-2">
                  <Badge variant="outline" className="w-6 h-6 flex items-center justify-center p-0">{index + 1}</Badge>
                  <Input
                    placeholder={`Upcoming highlight ${index + 1}...`}
                    value={item}
                    onChange={(e) => updateArrayField("upcoming_highlights", index, e.target.value)}
                  />
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Bucket List */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Mountain className="h-5 w-5 text-orange-500" />
                Top 5 Bucket List Adventures
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => { setAiSection("bucket_list"); setAiChatOpen(true); }}
                className="gap-1 text-muted-foreground hover:text-primary"
              >
                <MessageCircle className="h-4 w-4" />
                AI Help
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-2">
            {formData.bucket_list.map((item, index) => (
              <div key={index} className="flex items-center gap-2">
                <Badge className="w-6 h-6 flex items-center justify-center p-0">{index + 1}</Badge>
                <Input
                  placeholder={`Adventure ${index + 1}...`}
                  value={item}
                  onChange={(e) => updateArrayField("bucket_list", index, e.target.value)}
                />
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  Top 3 Targets by Life Category
                </CardTitle>
                <CardDescription>Define your top 3 goals in each area of life with status tracking</CardDescription>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => { setAiSection("life_categories"); setAiChatOpen(true); }}
                className="gap-1 text-muted-foreground hover:text-primary"
              >
                <MessageCircle className="h-4 w-4" />
                AI Help
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {LIFE_CATEGORIES.map((category) => {
                const Icon = category.icon;
                const data = formData.life_categories[category.id] || { target1: "", target2: "", target3: "", status1: "", status2: "", status3: "" };
                
                return (
                  <Card key={category.id} className="bg-muted/30">
                    <CardHeader className="pb-2 pt-3 px-3">
                      <CardTitle className="text-sm flex items-center gap-2">
                        <Icon className={`h-4 w-4 ${category.color}`} />
                        {category.label}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="px-3 pb-3 space-y-2">
                      {[1, 2, 3].map((num) => (
                        <div key={num} className="grid grid-cols-3 gap-1">
                          <Input
                            placeholder={`Target ${num}`}
                            value={data[`target${num}` as keyof LifeCategory]}
                            onChange={(e) => updateLifeCategory(category.id, `target${num}` as keyof LifeCategory, e.target.value)}
                            className="text-xs h-7 col-span-2"
                          />
                          <Input
                            placeholder="Status"
                            value={data[`status${num}` as keyof LifeCategory]}
                            onChange={(e) => updateLifeCategory(category.id, `status${num}` as keyof LifeCategory, e.target.value)}
                            className="text-xs h-7"
                          />
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Accountability */}
        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  What do you want to be held accountable for?
                </CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => { setAiSection("accountability"); setAiChatOpen(true); }}
                  className="gap-1 text-muted-foreground hover:text-primary"
                >
                  <MessageCircle className="h-4 w-4" />
                  AI Help
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="List the specific commitments you want others to hold you to..."
                value={formData.accountability_needs}
                onChange={(e) => updateField("accountability_needs", e.target.value)}
                className="min-h-[120px]"
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <HelpCircle className="h-5 w-5 text-blue-500" />
                What do you need help with?
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="What challenges are you facing? What support or resources do you need?"
                value={formData.help_needed}
                onChange={(e) => updateField("help_needed", e.target.value)}
                className="min-h-[120px]"
              />
            </CardContent>
          </Card>
        </div>

        {/* Save Button */}
        <div className="flex justify-end pb-8">
          <Button size="lg" onClick={handleSave} disabled={saving}>
            {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
            Save Vision
          </Button>
        </div>
      </main>

      {/* AI Chat */}
      {!aiChatOpen && (
        <Button
          onClick={() => {
            setAiSection("general");
            setAiChatOpen(true);
          }}
          className="fixed bottom-4 right-4 h-14 w-14 rounded-full shadow-lg z-40"
          size="icon"
        >
          <MessageCircle className="h-6 w-6" />
        </Button>
      )}
      
      <VisionAIChat
        section={aiSection}
        currentData={formData}
        isOpen={aiChatOpen}
        onClose={() => setAiChatOpen(false)}
        onCopyToField={handleAICopyToField}
      />
    </div>
  );
}
