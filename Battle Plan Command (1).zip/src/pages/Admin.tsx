import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { ArrowLeft, UserPlus, Shield, Users, Trash2, Flag, Crown } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface Profile {
  id: string;
  email: string;
  display_name: string;
  created_at: string;
  roles: string[];
}

interface Team {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
  member_count: number;
  creator_name: string | null;
  invite_code?: string;
}

interface TeamMember {
  id: string;
  user_id: string;
  role: string;
  status: string;
  profiles: {
    display_name: string | null;
    email: string | null;
  } | null;
}

const Admin = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [isCreating, setIsCreating] = useState(false);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [selectedTeam, setSelectedTeam] = useState<string | null>(null);
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [deleteTeamTarget, setDeleteTeamTarget] = useState<string | null>(null);

  useEffect(() => {
    checkAdminStatus();
  }, [user]);

  const checkAdminStatus = async () => {
    if (!user) {
      navigate("/auth");
      return;
    }

    try {
      const { data, error } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .eq("role", "admin")
        .maybeSingle();

      if (error) throw error;

      if (!data) {
        toast({
          title: "Access Denied",
          description: "You don't have admin privileges.",
          variant: "destructive",
        });
        navigate("/");
        return;
      }

      setIsAdmin(true);
      loadProfiles();
      loadTeams();
    } catch (error) {
      console.error("Error checking admin status:", error);
      navigate("/");
    } finally {
      setLoading(false);
    }
  };

  const loadProfiles = async () => {
    try {
      const { data: profilesData, error: profilesError } = await supabase
        .from("profiles")
        .select("*")
        .order("created_at", { ascending: false });

      if (profilesError) throw profilesError;

      // Fetch roles for each user
      const { data: rolesData, error: rolesError } = await supabase
        .from("user_roles")
        .select("user_id, role");

      if (rolesError) console.error("Error loading roles:", rolesError);

      // Combine profiles with their roles
      const rolesMap = new Map<string, string[]>();
      rolesData?.forEach(({ user_id, role }) => {
        if (!rolesMap.has(user_id)) {
          rolesMap.set(user_id, []);
        }
        rolesMap.get(user_id)?.push(role);
      });

      const profilesWithRoles = profilesData?.map(profile => ({
        ...profile,
        roles: rolesMap.get(profile.id) || []
      })) || [];

      setProfiles(profilesWithRoles);
    } catch (error) {
      console.error("Error loading profiles:", error);
    }
  };

  const handleCreateTestAccount = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsCreating(true);

    const formData = new FormData(e.currentTarget);
    const email = formData.get("email") as string;
    const password = formData.get("password") as string;
    const displayName = formData.get("displayName") as string;

    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            display_name: displayName,
          },
        },
      });

      if (error) throw error;

      toast({
        title: "Test Account Created",
        description: `Account ${email} created successfully.`,
      });

      (e.target as HTMLFormElement).reset();
      loadProfiles();
    } catch (error: any) {
      toast({
        title: "Creation Failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsCreating(false);
    }
  };

  const toggleAdminRole = async (userId: string, hasAdminRole: boolean) => {
    try {
      if (hasAdminRole) {
        // Remove admin role
        const { error } = await supabase
          .from("user_roles")
          .delete()
          .eq("user_id", userId)
          .eq("role", "admin");

        if (error) throw error;

        toast({
          title: "Admin Role Removed",
          description: "User is now a regular user.",
        });
      } else {
        // Add admin role
        const { error } = await supabase
          .from("user_roles")
          .insert({ user_id: userId, role: "admin" });

        if (error) throw error;

        toast({
          title: "Admin Role Assigned",
          description: "User is now an admin.",
        });
      }

      loadProfiles();
    } catch (error: any) {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const loadTeams = async () => {
    try {
      const { data: teamsData, error: teamsError } = await supabase
        .from("teams")
        .select("id, name, description, created_at, created_by")
        .order("created_at", { ascending: false });

      if (teamsError) throw teamsError;

      // Get member counts, creator names, and invite codes for each team
      const teamsWithCounts = await Promise.all(
        (teamsData || []).map(async (team) => {
          const { count } = await supabase
            .from("team_members")
            .select("*", { count: "exact", head: true })
            .eq("team_id", team.id);

          // Get creator profile
          let creator_name = null;
          if (team.created_by) {
            const { data: profileData } = await supabase
              .from("profiles")
              .select("display_name")
              .eq("id", team.created_by)
              .maybeSingle();
            creator_name = profileData?.display_name || null;
          }

          // Get invite code (admin has access via RLS)
          const { data: inviteData } = await supabase
            .from("team_invite_codes")
            .select("invite_code")
            .eq("team_id", team.id)
            .maybeSingle();

          return {
            ...team,
            member_count: count || 0,
            creator_name,
            invite_code: inviteData?.invite_code,
          };
        })
      );

      setTeams(teamsWithCounts);
    } catch (error) {
      console.error("Error loading teams:", error);
    }
  };

  const loadTeamMembers = async (teamId: string) => {
    try {
      const { data, error } = await supabase
        .from("team_members")
        .select(`
          *,
          profiles:user_id (
            display_name,
            email
          )
        `)
        .eq("team_id", teamId);

      if (error) throw error;
      setTeamMembers(data || []);
    } catch (error) {
      console.error("Error loading team members:", error);
    }
  };

  const handleDeleteTeam = async () => {
    if (!deleteTeamTarget) return;

    try {
      // Delete team members first
      const { error: membersError } = await supabase
        .from("team_members")
        .delete()
        .eq("team_id", deleteTeamTarget);

      if (membersError) throw membersError;

      // Delete the team
      const { error: teamError } = await supabase
        .from("teams")
        .delete()
        .eq("id", deleteTeamTarget);

      if (teamError) throw teamError;

      toast({
        title: "Team Deleted",
        description: "Team and all members have been removed.",
      });

      setDeleteTeamTarget(null);
      setSelectedTeam(null);
      loadTeams();
    } catch (error: any) {
      toast({
        title: "Delete Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleRemoveMember = async (memberId: string) => {
    try {
      const { error } = await supabase
        .from("team_members")
        .delete()
        .eq("id", memberId);

      if (error) throw error;

      toast({
        title: "Member Removed",
        description: "Member has been removed from the team.",
      });

      if (selectedTeam) {
        loadTeamMembers(selectedTeam);
        loadTeams();
      }
    } catch (error: any) {
      toast({
        title: "Remove Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleChangeRole = async (memberId: string, newRole: "leader" | "xo" | "member") => {
    try {
      const { error } = await supabase
        .from("team_members")
        .update({ role: newRole })
        .eq("id", memberId);

      if (error) throw error;

      toast({
        title: "Role Updated",
        description: `Member role changed to ${newRole}.`,
      });

      if (selectedTeam) {
        loadTeamMembers(selectedTeam);
      }
    } catch (error: any) {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <Shield className="w-12 h-12 text-primary mx-auto mb-4 animate-pulse" />
          <p className="text-muted-foreground">Verifying admin access...</p>
        </div>
      </div>
    );
  }

  if (!isAdmin) return null;

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-3 sm:px-4 py-3 sm:py-4 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 sm:gap-3">
            <Shield className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
            <h1 className="text-lg sm:text-2xl font-display font-bold">ADMIN PANEL</h1>
          </div>
          <Button variant="outline" size="sm" onClick={() => navigate("/")} className="hidden sm:flex">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
          <Button variant="outline" size="icon" onClick={() => navigate("/")} className="sm:hidden">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-3 sm:px-4 py-4 sm:py-8 max-w-6xl">
        <Tabs defaultValue="create" className="space-y-4 sm:space-y-6">
          <TabsList className="grid w-full grid-cols-3 max-w-2xl text-xs sm:text-sm">
            <TabsTrigger value="create" className="px-2 sm:px-4">Create</TabsTrigger>
            <TabsTrigger value="manage" className="px-2 sm:px-4">Users</TabsTrigger>
            <TabsTrigger value="teams" className="px-2 sm:px-4">Teams</TabsTrigger>
          </TabsList>

          <TabsContent value="create" className="space-y-4">
            <Card className="shadow-tactical">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <UserPlus className="w-5 h-5" />
                  Create Test Account
                </CardTitle>
                <CardDescription>
                  Create new test accounts for development and testing purposes.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleCreateTestAccount} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="displayName">Display Name</Label>
                    <Input
                      id="displayName"
                      name="displayName"
                      placeholder="John Operator"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      placeholder="test@battleplan.com"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <Input
                      id="password"
                      name="password"
                      type="password"
                      placeholder="Minimum 6 characters"
                      required
                      minLength={6}
                    />
                  </div>

                  <Button type="submit" disabled={isCreating} className="w-full">
                    {isCreating ? "Creating..." : "Create Test Account"}
                  </Button>
                </form>
              </CardContent>
            </Card>

            <Card className="shadow-tactical">
              <CardHeader>
                <CardTitle>Quick Setup Instructions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm text-muted-foreground">
                <p>1. Create test accounts using the form above</p>
                <p>2. Test accounts are created with auto-confirmed email</p>
                <p>3. Use the Manage Users tab to grant admin privileges</p>
                <p>4. Test accounts can create teams and battle plans</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="manage" className="space-y-4">
            <Card className="shadow-tactical">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  All Users ({profiles.length})
                </CardTitle>
                <CardDescription>
                  Manage user accounts and admin privileges.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {profiles.map((profile) => {
                    const hasAdminRole = profile.roles.includes("admin");
                    return (
                      <div
                        key={profile.id}
                        className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 sm:gap-4 p-3 rounded-lg border border-border hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex-1 min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <p className="font-medium truncate">{profile.display_name || "No name"}</p>
                            {hasAdminRole && (
                              <span className="text-[10px] sm:text-xs px-1.5 sm:px-2 py-0.5 rounded-md bg-primary/20 text-primary">
                                ADMIN
                              </span>
                            )}
                            {profile.id === user?.id && (
                              <span className="text-[10px] sm:text-xs px-1.5 sm:px-2 py-0.5 rounded-md bg-accent/20 text-accent">
                                YOU
                              </span>
                            )}
                          </div>
                          <p className="text-xs sm:text-sm text-muted-foreground truncate">{profile.email}</p>
                        </div>

                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant={hasAdminRole ? "destructive" : "secondary"}
                            onClick={() => toggleAdminRole(profile.id, hasAdminRole)}
                            disabled={profile.id === user?.id}
                            className="text-xs sm:text-sm w-full sm:w-auto"
                          >
                            {hasAdminRole ? "Remove Admin" : "Assign Admin"}
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="teams" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <Card className="shadow-tactical">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Flag className="w-5 h-5" />
                    All Teams ({teams.length})
                  </CardTitle>
                  <CardDescription>View and manage battle teams</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {teams.map((team) => (
                      <div
                        key={team.id}
                        className={`p-3 rounded-lg border border-border hover:bg-muted/50 transition-colors cursor-pointer ${
                          selectedTeam === team.id ? "bg-muted" : ""
                        }`}
                        onClick={() => {
                          setSelectedTeam(team.id);
                          loadTeamMembers(team.id);
                        }}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <p className="font-medium">{team.name}</p>
                            <p className="text-sm text-muted-foreground">
                              {team.member_count} members • Code: {team.invite_code}
                            </p>
                            {team.creator_name && (
                              <p className="text-xs text-muted-foreground">
                                Created by {team.creator_name}
                              </p>
                            )}
                          </div>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={(e) => {
                              e.stopPropagation();
                              setDeleteTeamTarget(team.id);
                            }}
                          >
                            <Trash2 className="w-4 h-4 text-destructive" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-tactical">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5" />
                    Team Members
                  </CardTitle>
                  <CardDescription>
                    {selectedTeam
                      ? `Members of ${teams.find((t) => t.id === selectedTeam)?.name}`
                      : "Select a team to view members"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {selectedTeam ? (
                    <div className="space-y-2 max-h-96 overflow-y-auto">
                      {teamMembers.map((member) => (
                        <div
                          key={member.id}
                          className="flex items-center justify-between gap-2 p-3 rounded-lg border border-border"
                        >
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="font-medium truncate">
                                {member.profiles?.display_name || "Unknown User"}
                              </p>
                              {member.role === "leader" && (
                                <Crown className="w-4 h-4 text-primary flex-shrink-0" />
                              )}
                            </div>
                            <p className="text-sm text-muted-foreground truncate">
                              {member.profiles?.email}
                            </p>
                            <span className="text-xs px-2 py-0.5 rounded-md bg-muted capitalize inline-block mt-1">
                              {member.status}
                            </span>
                          </div>
                          <div className="flex items-center gap-2 flex-shrink-0">
                            <Select
                              value={member.role}
                              onValueChange={(value) => handleChangeRole(member.id, value as "leader" | "xo" | "member")}
                            >
                              <SelectTrigger className="w-24">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="leader">Leader</SelectItem>
                                <SelectItem value="xo">XO</SelectItem>
                                <SelectItem value="member">Member</SelectItem>
                              </SelectContent>
                            </Select>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleRemoveMember(member.id)}
                            >
                              <Trash2 className="w-4 h-4 text-destructive" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <Users className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      <p>Select a team from the left to view members</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        <AlertDialog open={!!deleteTeamTarget} onOpenChange={() => setDeleteTeamTarget(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Team?</AlertDialogTitle>
              <AlertDialogDescription>
                This will permanently delete the team and remove all members. This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleDeleteTeam} className="bg-destructive text-destructive-foreground">
                Delete Team
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </main>
    </div>
  );
};

export default Admin;
