import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Calendar, Star, CheckCircle2, AlertCircle, Lightbulb, ListTodo } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface ActionItem {
  id: string;
  text: string;
  completed: boolean;
}

interface SharedReview {
  id: string;
  review_type: "quarterly" | "yearly";
  period_start: string;
  period_end: string;
  what_went_well: string | null;
  what_could_improve: string | null;
  lessons_learned: string | null;
  action_items: ActionItem[];
  overall_rating: number | null;
  created_at: string;
  profiles: {
    display_name: string | null;
  } | null;
  teams: {
    name: string;
  } | null;
}

const SharedReview = () => {
  const { token } = useParams<{ token: string }>();
  const navigate = useNavigate();
  const [review, setReview] = useState<SharedReview | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (token) {
      loadSharedReview();
    }
  }, [token]);

  const loadSharedReview = async () => {
    try {
      const { data, error: fetchError } = await supabase
        .from("after_action_reviews")
        .select(`
          *,
          profiles:user_id (display_name),
          teams:team_id (name)
        `)
        .eq("share_token", token)
        .eq("is_shared", true)
        .maybeSingle();

      if (fetchError) throw fetchError;

      if (!data) {
        setError("This review is no longer shared or doesn't exist.");
        return;
      }

      const formattedReview: SharedReview = {
        id: data.id,
        review_type: data.review_type as "quarterly" | "yearly",
        period_start: data.period_start,
        period_end: data.period_end,
        what_went_well: data.what_went_well,
        what_could_improve: data.what_could_improve,
        lessons_learned: data.lessons_learned,
        action_items: Array.isArray(data.action_items) 
          ? (data.action_items as unknown as ActionItem[]) 
          : [],
        overall_rating: data.overall_rating,
        created_at: data.created_at,
        profiles: data.profiles,
        teams: data.teams,
      };

      setReview(formattedReview);
    } catch (err) {
      console.error("Error loading shared review:", err);
      setError("Failed to load the shared review.");
    } finally {
      setLoading(false);
    }
  };

  const renderStars = (rating: number | null) => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`w-5 h-5 ${
              rating && star <= rating
                ? "fill-yellow-400 text-yellow-400"
                : "text-muted-foreground"
            }`}
          />
        ))}
      </div>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Loading shared review...</p>
      </div>
    );
  }

  if (error || !review) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-8">
          <Card className="max-w-2xl mx-auto">
            <CardContent className="py-12 text-center">
              <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h4 className="text-lg font-semibold mb-2">Review Not Found</h4>
              <p className="text-muted-foreground mb-4">
                {error || "This review is no longer available."}
              </p>
              <Button onClick={() => navigate("/")}>
                Go to Home
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-xl sm:text-2xl font-display font-bold">Shared After Action Review</h1>
              <p className="text-sm text-muted-foreground">
                Shared by {review.profiles?.display_name || "Team Member"}
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <Card className="max-w-3xl mx-auto shadow-tactical">
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
              <div>
                <CardTitle className="text-xl flex items-center gap-2">
                  <Calendar className="w-5 h-5" />
                  {review.review_type === "quarterly" ? "Quarterly" : "Yearly"} Review
                </CardTitle>
                <CardDescription className="mt-2">
                  <span className="block">
                    {new Date(review.period_start).toLocaleDateString()} - {new Date(review.period_end).toLocaleDateString()}
                  </span>
                  <span className="block mt-1">
                    Team: {review.teams?.name || "Unknown Team"}
                  </span>
                </CardDescription>
              </div>
              <div className="flex flex-col items-start sm:items-end gap-2">
                {renderStars(review.overall_rating)}
                <span className="text-xs text-muted-foreground">
                  Created {new Date(review.created_at).toLocaleDateString()}
                </span>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {review.what_went_well && (
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-base font-medium text-green-600">
                  <CheckCircle2 className="w-5 h-5" />
                  What Went Well
                </div>
                <p className="text-muted-foreground pl-7 whitespace-pre-wrap">{review.what_went_well}</p>
              </div>
            )}

            {review.what_could_improve && (
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-base font-medium text-orange-600">
                  <AlertCircle className="w-5 h-5" />
                  What Could Improve
                </div>
                <p className="text-muted-foreground pl-7 whitespace-pre-wrap">{review.what_could_improve}</p>
              </div>
            )}

            {review.lessons_learned && (
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-base font-medium text-blue-600">
                  <Lightbulb className="w-5 h-5" />
                  Lessons Learned
                </div>
                <p className="text-muted-foreground pl-7 whitespace-pre-wrap">{review.lessons_learned}</p>
              </div>
            )}

            {review.action_items && review.action_items.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-base font-medium text-purple-600">
                  <ListTodo className="w-5 h-5" />
                  Action Items
                </div>
                <div className="pl-7 space-y-2">
                  {review.action_items.map((item) => (
                    <div key={item.id} className="flex items-center gap-2">
                      <div className={`w-4 h-4 rounded border flex items-center justify-center ${
                        item.completed ? "bg-green-500 border-green-500" : "border-muted-foreground"
                      }`}>
                        {item.completed && <CheckCircle2 className="w-3 h-3 text-white" />}
                      </div>
                      <span className={item.completed ? "line-through text-muted-foreground" : ""}>
                        {item.text}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default SharedReview;
