import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import type { Json } from "@/integrations/supabase/types";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Plus, Calendar, Star, CheckCircle2, AlertCircle, Lightbulb, ListTodo, Trash2, Edit, Download, Share2, Link, Users, Sparkles } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import jsPDF from "jspdf";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { AARImport } from "@/components/AARImport";
import { AARInsightsDashboard } from "@/components/AARInsightsDashboard";

interface ActionItem {
  id: string;
  text: string;
  completed: boolean;
}

interface Review {
  id: string;
  review_type: "quarterly" | "yearly";
  period_start: string;
  period_end: string;
  what_went_well: string | null;
  what_could_improve: string | null;
  lessons_learned: string | null;
  action_items: ActionItem[];
  overall_rating: number | null;
  created_at: string;
  team_id: string;
  user_id: string;
  share_token: string | null;
  is_shared: boolean;
  profiles?: {
    display_name: string | null;
  } | null;
}

interface Team {
  id: string;
  name: string;
}

const AfterActionReview = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [teamReviews, setTeamReviews] = useState<Review[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingReview, setEditingReview] = useState<Review | null>(null);
  
  // Form state
  const [reviewType, setReviewType] = useState<"quarterly" | "yearly">("quarterly");
  const [selectedTeam, setSelectedTeam] = useState<string>("");
  const [periodStart, setPeriodStart] = useState("");
  const [periodEnd, setPeriodEnd] = useState("");
  const [whatWentWell, setWhatWentWell] = useState("");
  const [whatCouldImprove, setWhatCouldImprove] = useState("");
  const [lessonsLearned, setLessonsLearned] = useState("");
  const [actionItems, setActionItems] = useState<ActionItem[]>([]);
  const [newActionItem, setNewActionItem] = useState("");
  const [overallRating, setOverallRating] = useState<number>(3);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState("my-reviews");

  useEffect(() => {
    if (user) {
      loadTeams();
      loadReviews();
      loadTeamReviews();
    }
  }, [user]);

  const loadTeams = async () => {
    try {
      const { data, error } = await supabase
        .from("team_members")
        .select(`
          teams (
            id,
            name
          )
        `)
        .eq("user_id", user?.id)
        .eq("status", "active");

      if (error) throw error;

      const formattedTeams = data?.map((item: any) => ({
        id: item.teams.id,
        name: item.teams.name,
      })) || [];

      setTeams(formattedTeams);
      if (formattedTeams.length > 0) {
        setSelectedTeam(formattedTeams[0].id);
      }
    } catch (error) {
      console.error("Error loading teams:", error);
    }
  };

  const loadReviews = async () => {
    try {
      const { data, error } = await supabase
        .from("after_action_reviews")
        .select("*")
        .eq("user_id", user?.id)
        .order("period_end", { ascending: false });

      if (error) throw error;

      const formattedReviews = data?.map((review: any) => ({
        ...review,
        action_items: Array.isArray(review.action_items) ? review.action_items : [],
      })) || [];

      setReviews(formattedReviews);
    } catch (error) {
      console.error("Error loading reviews:", error);
    } finally {
      setLoading(false);
    }
  };

  const loadTeamReviews = async () => {
    try {
      // Get user's team IDs first
      const { data: memberData } = await supabase
        .from("team_members")
        .select("team_id")
        .eq("user_id", user?.id)
        .eq("status", "active");

      if (!memberData || memberData.length === 0) return;

      const teamIds = memberData.map(m => m.team_id);

      // Get reviews from team members (excluding own reviews)
      const { data, error } = await supabase
        .from("after_action_reviews")
        .select(`
          *,
          profiles:user_id (display_name)
        `)
        .in("team_id", teamIds)
        .neq("user_id", user?.id)
        .order("period_end", { ascending: false });

      if (error) throw error;

      const formattedReviews = data?.map((review: any) => ({
        ...review,
        action_items: Array.isArray(review.action_items) ? review.action_items : [],
      })) || [];

      setTeamReviews(formattedReviews);
    } catch (error) {
      console.error("Error loading team reviews:", error);
    }
  };

  const toggleShareReview = async (review: Review) => {
    try {
      if (review.is_shared) {
        // Disable sharing
        const { error } = await supabase
          .from("after_action_reviews")
          .update({ is_shared: false })
          .eq("id", review.id);

        if (error) throw error;
        toast.success("Sharing disabled");
      } else {
        // Enable sharing - generate token if needed
        let shareToken = review.share_token;
        if (!shareToken) {
          const { data: tokenData, error: tokenError } = await supabase
            .rpc("generate_share_token");
          
          if (tokenError) throw tokenError;
          shareToken = tokenData;
        }

        const { error } = await supabase
          .from("after_action_reviews")
          .update({ 
            is_shared: true,
            share_token: shareToken 
          })
          .eq("id", review.id);

        if (error) throw error;
        toast.success("Sharing enabled");
      }
      loadReviews();
    } catch (error) {
      console.error("Error toggling share:", error);
      toast.error("Failed to update sharing settings");
    }
  };

  const copyShareLink = async (review: Review) => {
    if (!review.share_token) {
      toast.error("Enable sharing first");
      return;
    }
    
    const shareUrl = `${window.location.origin}/shared-review/${review.share_token}`;
    try {
      await navigator.clipboard.writeText(shareUrl);
      toast.success("Share link copied to clipboard!");
    } catch (error) {
      toast.error("Failed to copy link");
    }
  };

  const resetForm = () => {
    setReviewType("quarterly");
    setPeriodStart("");
    setPeriodEnd("");
    setWhatWentWell("");
    setWhatCouldImprove("");
    setLessonsLearned("");
    setActionItems([]);
    setNewActionItem("");
    setOverallRating(3);
    setEditingReview(null);
    if (teams.length > 0) {
      setSelectedTeam(teams[0].id);
    }
  };

  const openEditDialog = (review: Review) => {
    setEditingReview(review);
    setReviewType(review.review_type);
    setSelectedTeam(review.team_id);
    setPeriodStart(review.period_start);
    setPeriodEnd(review.period_end);
    setWhatWentWell(review.what_went_well || "");
    setWhatCouldImprove(review.what_could_improve || "");
    setLessonsLearned(review.lessons_learned || "");
    setActionItems(review.action_items || []);
    setOverallRating(review.overall_rating || 3);
    setDialogOpen(true);
  };

  const addActionItem = () => {
    if (newActionItem.trim()) {
      setActionItems([
        ...actionItems,
        { id: crypto.randomUUID(), text: newActionItem.trim(), completed: false }
      ]);
      setNewActionItem("");
    }
  };

  const removeActionItem = (id: string) => {
    setActionItems(actionItems.filter(item => item.id !== id));
  };

  const toggleActionItem = (id: string) => {
    setActionItems(actionItems.map(item =>
      item.id === id ? { ...item, completed: !item.completed } : item
    ));
  };

  const handleSubmit = async () => {
    if (!selectedTeam || !periodStart || !periodEnd) {
      toast.error("Please fill in all required fields");
      return;
    }

    setSaving(true);
    try {
      const reviewData = {
        user_id: user?.id,
        team_id: selectedTeam,
        review_type: reviewType,
        period_start: periodStart,
        period_end: periodEnd,
        what_went_well: whatWentWell || null,
        what_could_improve: whatCouldImprove || null,
        lessons_learned: lessonsLearned || null,
        action_items: actionItems as unknown as Json,
        overall_rating: overallRating,
      };

      if (editingReview) {
        const { error } = await supabase
          .from("after_action_reviews")
          .update(reviewData)
          .eq("id", editingReview.id);

        if (error) throw error;
        toast.success("Review updated successfully");
      } else {
        const { error } = await supabase
          .from("after_action_reviews")
          .insert(reviewData);

        if (error) throw error;
        toast.success("Review created successfully");
      }

      setDialogOpen(false);
      resetForm();
      loadReviews();
    } catch (error) {
      console.error("Error saving review:", error);
      toast.error("Failed to save review");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this review?")) return;

    try {
      const { error } = await supabase
        .from("after_action_reviews")
        .delete()
        .eq("id", id);

      if (error) throw error;
      toast.success("Review deleted successfully");
      loadReviews();
    } catch (error) {
      console.error("Error deleting review:", error);
      toast.error("Failed to delete review");
    }
  };

  const getTeamName = (teamId: string) => {
    return teams.find(t => t.id === teamId)?.name || "Unknown Team";
  };

  const exportToPdf = (review: Review) => {
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    const margin = 20;
    const contentWidth = pageWidth - margin * 2;
    let yPosition = 20;

    // Helper function to add wrapped text
    const addWrappedText = (text: string, x: number, y: number, maxWidth: number, lineHeight: number = 7): number => {
      const lines = doc.splitTextToSize(text, maxWidth);
      doc.text(lines, x, y);
      return y + lines.length * lineHeight;
    };

    // Title
    doc.setFontSize(20);
    doc.setFont("helvetica", "bold");
    const reviewTypeTitle = review.review_type === "quarterly" ? "Quarterly" : "Yearly";
    doc.text(`${reviewTypeTitle} After Action Review`, margin, yPosition);
    yPosition += 15;

    // Period and Team
    doc.setFontSize(12);
    doc.setFont("helvetica", "normal");
    doc.text(`Period: ${new Date(review.period_start).toLocaleDateString()} - ${new Date(review.period_end).toLocaleDateString()}`, margin, yPosition);
    yPosition += 7;
    doc.text(`Team: ${getTeamName(review.team_id)}`, margin, yPosition);
    yPosition += 7;

    // Rating
    if (review.overall_rating) {
      const stars = "★".repeat(review.overall_rating) + "☆".repeat(5 - review.overall_rating);
      doc.text(`Overall Rating: ${stars}`, margin, yPosition);
      yPosition += 7;
    }

    doc.text(`Created: ${new Date(review.created_at).toLocaleDateString()}`, margin, yPosition);
    yPosition += 15;

    // Divider line
    doc.setDrawColor(200, 200, 200);
    doc.line(margin, yPosition, pageWidth - margin, yPosition);
    yPosition += 10;

    // What Went Well
    if (review.what_went_well) {
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(34, 139, 34); // Green
      doc.text("What Went Well", margin, yPosition);
      yPosition += 8;
      
      doc.setFontSize(11);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(60, 60, 60);
      yPosition = addWrappedText(review.what_went_well, margin, yPosition, contentWidth);
      yPosition += 10;
    }

    // What Could Improve
    if (review.what_could_improve) {
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(255, 140, 0); // Orange
      doc.text("What Could Improve", margin, yPosition);
      yPosition += 8;
      
      doc.setFontSize(11);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(60, 60, 60);
      yPosition = addWrappedText(review.what_could_improve, margin, yPosition, contentWidth);
      yPosition += 10;
    }

    // Lessons Learned
    if (review.lessons_learned) {
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(30, 144, 255); // Blue
      doc.text("Lessons Learned", margin, yPosition);
      yPosition += 8;
      
      doc.setFontSize(11);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(60, 60, 60);
      yPosition = addWrappedText(review.lessons_learned, margin, yPosition, contentWidth);
      yPosition += 10;
    }

    // Action Items
    if (review.action_items && review.action_items.length > 0) {
      // Check if we need a new page
      if (yPosition > 250) {
        doc.addPage();
        yPosition = 20;
      }

      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(128, 0, 128); // Purple
      doc.text("Action Items", margin, yPosition);
      yPosition += 8;

      doc.setFontSize(11);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(60, 60, 60);

      review.action_items.forEach((item) => {
        const checkbox = item.completed ? "[✓]" : "[ ]";
        const itemText = `${checkbox} ${item.text}`;
        yPosition = addWrappedText(itemText, margin, yPosition, contentWidth);
        yPosition += 3;
      });
    }

    // Footer
    doc.setFontSize(9);
    doc.setTextColor(150, 150, 150);
    doc.text("Generated by Battle Plan", margin, doc.internal.pageSize.getHeight() - 10);

    // Save the PDF
    const fileName = `AAR_${review.review_type}_${review.period_start}_to_${review.period_end}.pdf`;
    doc.save(fileName);
    toast.success("PDF exported successfully");
  };

  const quarterlyReviews = reviews.filter(r => r.review_type === "quarterly");
  const yearlyReviews = reviews.filter(r => r.review_type === "yearly");

  const renderStars = (rating: number | null) => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`w-4 h-4 ${
              rating && star <= rating
                ? "fill-yellow-400 text-yellow-400"
                : "text-muted-foreground"
            }`}
          />
        ))}
      </div>
    );
  };

  const renderReviewCard = (review: Review, isOwn: boolean = true) => (
    <Card key={review.id} className="shadow-tactical">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              {new Date(review.period_start).toLocaleDateString()} - {new Date(review.period_end).toLocaleDateString()}
            </CardTitle>
            <CardDescription className="mt-1">
              {!isOwn && review.profiles?.display_name && (
                <span className="font-medium text-foreground">{review.profiles.display_name} • </span>
              )}
              {getTeamName(review.team_id)} • {review.review_type === "quarterly" ? "Quarterly" : "Yearly"} Review
              {isOwn && review.is_shared && (
                <span className="ml-2 inline-flex items-center text-xs text-green-600">
                  <Share2 className="w-3 h-3 mr-1" />
                  Shared
                </span>
              )}
            </CardDescription>
          </div>
          <div className="flex items-center gap-1">
            {renderStars(review.overall_rating)}
            {isOwn && (
              <>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => toggleShareReview(review)}
                      className={review.is_shared ? "text-green-600" : ""}
                    >
                      <Share2 className="w-4 h-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    {review.is_shared ? "Disable sharing" : "Enable sharing"}
                  </TooltipContent>
                </Tooltip>
                {review.is_shared && (
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="ghost" size="icon" onClick={() => copyShareLink(review)}>
                        <Link className="w-4 h-4" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Copy share link</TooltipContent>
                  </Tooltip>
                )}
                <Button variant="ghost" size="icon" onClick={() => exportToPdf(review)} title="Export to PDF">
                  <Download className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => openEditDialog(review)} title="Edit">
                  <Edit className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => handleDelete(review.id)} title="Delete">
                  <Trash2 className="w-4 h-4 text-destructive" />
                </Button>
              </>
            )}
            {!isOwn && (
              <Button variant="ghost" size="icon" onClick={() => exportToPdf(review)} title="Export to PDF">
                <Download className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {review.what_went_well && (
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-sm font-medium text-green-600">
              <CheckCircle2 className="w-4 h-4" />
              What Went Well
            </div>
            <p className="text-sm text-muted-foreground pl-6">{review.what_went_well}</p>
          </div>
        )}

        {review.what_could_improve && (
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-sm font-medium text-orange-600">
              <AlertCircle className="w-4 h-4" />
              What Could Improve
            </div>
            <p className="text-sm text-muted-foreground pl-6">{review.what_could_improve}</p>
          </div>
        )}

        {review.lessons_learned && (
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-sm font-medium text-blue-600">
              <Lightbulb className="w-4 h-4" />
              Lessons Learned
            </div>
            <p className="text-sm text-muted-foreground pl-6">{review.lessons_learned}</p>
          </div>
        )}

        {review.action_items && review.action_items.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm font-medium text-purple-600">
              <ListTodo className="w-4 h-4" />
              Action Items
            </div>
            <div className="pl-6 space-y-1">
              {review.action_items.map((item) => (
                <div key={item.id} className="flex items-center gap-2 text-sm">
                  {isOwn ? (
                    <input
                      type="checkbox"
                      checked={item.completed}
                      onChange={() => {
                        const updatedItems = review.action_items.map(i =>
                          i.id === item.id ? { ...i, completed: !i.completed } : i
                        );
                        supabase
                          .from("after_action_reviews")
                          .update({ action_items: updatedItems as unknown as Json })
                          .eq("id", review.id)
                          .then(() => loadReviews());
                      }}
                      className="rounded"
                    />
                  ) : (
                    <div className={`w-4 h-4 rounded border flex items-center justify-center ${
                      item.completed ? "bg-green-500 border-green-500" : "border-muted-foreground"
                    }`}>
                      {item.completed && <CheckCircle2 className="w-3 h-3 text-white" />}
                    </div>
                  )}
                  <span className={item.completed ? "line-through text-muted-foreground" : ""}>
                    {item.text}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <h1 className="text-xl sm:text-2xl font-display font-bold">After Action Reviews</h1>
            </div>
            <div className="flex items-center gap-2">
              {teams.length > 0 && (
                <AARImport 
                  teamId={selectedTeam || teams[0]?.id} 
                  onImport={(aar) => {
                    setReviewType(aar.review_type);
                    setPeriodStart(aar.period_start);
                    setPeriodEnd(aar.period_end);
                    setWhatWentWell(aar.what_went_well);
                    setWhatCouldImprove(aar.what_could_improve);
                    setLessonsLearned(aar.lessons_learned);
                    setActionItems(aar.action_items);
                    setOverallRating(aar.overall_rating);
                    setDialogOpen(true);
                  }}
                />
              )}
              <Dialog open={dialogOpen} onOpenChange={(open) => {
                setDialogOpen(open);
                if (!open) resetForm();
              }}>
                <DialogTrigger asChild>
                  <Button disabled={teams.length === 0}>
                    <Plus className="w-4 h-4 mr-2" />
                    New Review
                  </Button>
                </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>{editingReview ? "Edit Review" : "Create After Action Review"}</DialogTitle>
                  <DialogDescription>
                    Reflect on your performance and identify areas for growth.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-6 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Review Type</Label>
                      <Select value={reviewType} onValueChange={(v: "quarterly" | "yearly") => setReviewType(v)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="quarterly">Quarterly</SelectItem>
                          <SelectItem value="yearly">Yearly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Team</Label>
                      <Select value={selectedTeam} onValueChange={setSelectedTeam}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select team" />
                        </SelectTrigger>
                        <SelectContent>
                          {teams.map((team) => (
                            <SelectItem key={team.id} value={team.id}>
                              {team.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Period Start</Label>
                      <Input
                        type="date"
                        value={periodStart}
                        onChange={(e) => setPeriodStart(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Period End</Label>
                      <Input
                        type="date"
                        value={periodEnd}
                        onChange={(e) => setPeriodEnd(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600" />
                      What Went Well
                    </Label>
                    <Textarea
                      placeholder="What successes did you achieve? What are you proud of?"
                      value={whatWentWell}
                      onChange={(e) => setWhatWentWell(e.target.value)}
                      rows={3}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-orange-600" />
                      What Could Improve
                    </Label>
                    <Textarea
                      placeholder="What challenges did you face? What didn't go as planned?"
                      value={whatCouldImprove}
                      onChange={(e) => setWhatCouldImprove(e.target.value)}
                      rows={3}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="flex items-center gap-2">
                      <Lightbulb className="w-4 h-4 text-blue-600" />
                      Lessons Learned
                    </Label>
                    <Textarea
                      placeholder="What insights will you carry forward? What would you do differently?"
                      value={lessonsLearned}
                      onChange={(e) => setLessonsLearned(e.target.value)}
                      rows={3}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="flex items-center gap-2">
                      <ListTodo className="w-4 h-4 text-purple-600" />
                      Action Items
                    </Label>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Add an action item..."
                        value={newActionItem}
                        onChange={(e) => setNewActionItem(e.target.value)}
                        onKeyDown={(e) => e.key === "Enter" && addActionItem()}
                      />
                      <Button type="button" variant="outline" onClick={addActionItem}>
                        Add
                      </Button>
                    </div>
                    {actionItems.length > 0 && (
                      <div className="space-y-2 mt-2">
                        {actionItems.map((item) => (
                          <div key={item.id} className="flex items-center gap-2 p-2 bg-muted rounded">
                            <input
                              type="checkbox"
                              checked={item.completed}
                              onChange={() => toggleActionItem(item.id)}
                              className="rounded"
                            />
                            <span className={`flex-1 text-sm ${item.completed ? "line-through text-muted-foreground" : ""}`}>
                              {item.text}
                            </span>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6"
                              onClick={() => removeActionItem(item.id)}
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label>Overall Rating</Label>
                    <div className="flex gap-2">
                      {[1, 2, 3, 4, 5].map((rating) => (
                        <button
                          key={rating}
                          type="button"
                          onClick={() => setOverallRating(rating)}
                          className="focus:outline-none"
                        >
                          <Star
                            className={`w-8 h-8 transition-colors ${
                              rating <= overallRating
                                ? "fill-yellow-400 text-yellow-400"
                                : "text-muted-foreground hover:text-yellow-400"
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>

                  <Button onClick={handleSubmit} disabled={saving} className="w-full">
                    {saving ? "Saving..." : editingReview ? "Update Review" : "Create Review"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {teams.length === 0 ? (
          <Card className="shadow-tactical">
            <CardContent className="py-12 text-center">
              <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h4 className="text-lg font-semibold mb-2">No Team Found</h4>
              <p className="text-muted-foreground mb-4">
                You need to be part of a team to create after action reviews.
              </p>
              <Button onClick={() => navigate("/teams/join")}>
                Join a Team
              </Button>
            </CardContent>
          </Card>
        ) : loading ? (
          <div className="text-center text-muted-foreground py-12">
            Loading reviews...
          </div>
        ) : (
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full max-w-2xl grid-cols-4">
              <TabsTrigger value="my-reviews" className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                <span className="hidden sm:inline">My Reviews</span> ({reviews.length})
              </TabsTrigger>
              <TabsTrigger value="team-reviews" className="flex items-center gap-2">
                <Users className="w-4 h-4" />
                <span className="hidden sm:inline">Team</span> ({teamReviews.length})
              </TabsTrigger>
              <TabsTrigger value="by-type" className="flex items-center gap-2">
                <ListTodo className="w-4 h-4" />
                <span className="hidden sm:inline">By Type</span>
              </TabsTrigger>
              <TabsTrigger value="insights" className="flex items-center gap-2">
                <Sparkles className="w-4 h-4" />
                <span className="hidden sm:inline">AI Insights</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="my-reviews" className="space-y-4">
              {reviews.length === 0 ? (
                <Card className="shadow-tactical">
                  <CardContent className="py-12 text-center">
                    <Calendar className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <h4 className="text-lg font-semibold mb-2">No Reviews Yet</h4>
                    <p className="text-muted-foreground mb-4">
                      Create your first after action review to track your progress.
                    </p>
                    <Button onClick={() => setDialogOpen(true)}>
                      <Plus className="w-4 h-4 mr-2" />
                      Create Review
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                reviews.map((review) => renderReviewCard(review, true))
              )}
            </TabsContent>

            <TabsContent value="team-reviews" className="space-y-4">
              {teamReviews.length === 0 ? (
                <Card className="shadow-tactical">
                  <CardContent className="py-12 text-center">
                    <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <h4 className="text-lg font-semibold mb-2">No Team Reviews</h4>
                    <p className="text-muted-foreground mb-4">
                      When your team members create reviews, they'll appear here.
                    </p>
                  </CardContent>
                </Card>
              ) : (
                teamReviews.map((review) => renderReviewCard(review, false))
              )}
            </TabsContent>

            <TabsContent value="by-type" className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Calendar className="w-5 h-5" />
                  Quarterly Reviews ({quarterlyReviews.length})
                </h3>
                {quarterlyReviews.length === 0 ? (
                  <Card className="shadow-tactical">
                    <CardContent className="py-8 text-center">
                      <p className="text-muted-foreground">No quarterly reviews yet.</p>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="space-y-4">
                    {quarterlyReviews.map((review) => renderReviewCard(review, true))}
                  </div>
                )}
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Calendar className="w-5 h-5" />
                  Yearly Reviews ({yearlyReviews.length})
                </h3>
                {yearlyReviews.length === 0 ? (
                  <Card className="shadow-tactical">
                    <CardContent className="py-8 text-center">
                      <p className="text-muted-foreground">No yearly reviews yet.</p>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="space-y-4">
                    {yearlyReviews.map((review) => renderReviewCard(review, true))}
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="insights">
              <AARInsightsDashboard />
            </TabsContent>
          </Tabs>
        )}
      </main>
    </div>
  );
};

export default AfterActionReview;
