import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { ArrowLeft, Shield, Users, Copy, RefreshCw, UserCheck, UserX, Crown, Image as ImageIcon } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import TeamLogoUpload from "@/components/TeamLogoUpload";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface Team {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
  logo_url: string | null;
}

interface TeamInviteCode {
  invite_code: string;
}

interface TeamMember {
  id: string;
  user_id: string;
  role: string;
  status: string;
  joined_at: string;
  profiles: {
    display_name: string | null;
    avatar_url: string | null;
  } | null;
}

const TeamAdmin = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { teamId } = useParams<{ teamId: string }>();
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [loading, setLoading] = useState(true);
  const [team, setTeam] = useState<Team | null>(null);
  const [inviteCode, setInviteCode] = useState<string | null>(null);
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [pendingMembers, setPendingMembers] = useState<TeamMember[]>([]);
  const [removeTarget, setRemoveTarget] = useState<string | null>(null);

  useEffect(() => {
    checkAuthorization();
  }, [user, teamId]);

  const checkAuthorization = async () => {
    if (!user || !teamId) {
      navigate("/");
      return;
    }

    try {
      // Check if user is leader or XO of this team
      const { data, error } = await supabase
        .from("team_members")
        .select("role, status")
        .eq("team_id", teamId)
        .eq("user_id", user.id)
        .maybeSingle();

      if (error) throw error;

      if (!data || data.status !== "active" || !["leader", "xo"].includes(data.role)) {
        toast({
          title: "Access Denied",
          description: "You don't have permission to manage this team.",
          variant: "destructive",
        });
        navigate("/");
        return;
      }

      setIsAuthorized(true);
      loadTeamData();
      loadMembers();
    } catch (error) {
      console.error("Error checking authorization:", error);
      navigate("/");
    } finally {
      setLoading(false);
    }
  };

  const loadTeamData = async () => {
    if (!teamId) return;

    try {
      const { data, error } = await supabase
        .from("teams")
        .select("id, name, description, created_at, logo_url")
        .eq("id", teamId)
        .single();

      if (error) throw error;
      setTeam(data);

      // Load invite code separately (leaders/XOs only)
      const { data: inviteData } = await supabase
        .from("team_invite_codes")
        .select("invite_code")
        .eq("team_id", teamId)
        .single();
      
      setInviteCode(inviteData?.invite_code || null);
    } catch (error) {
      console.error("Error loading team:", error);
    }
  };

  const loadMembers = async () => {
    if (!teamId) return;

    try {
      // Fetch team members with limited profile data (no email for privacy)
      const { data, error } = await supabase
        .from("team_members")
        .select(`
          *,
          profiles:user_id (
            display_name,
            avatar_url
          )
        `)
        .eq("team_id", teamId)
        .order("joined_at", { ascending: false });

      if (error) throw error;

      const active = data?.filter(m => m.status === "active") || [];
      const pending = data?.filter(m => m.status === "pending") || [];

      setMembers(active);
      setPendingMembers(pending);
    } catch (error) {
      console.error("Error loading members:", error);
    }
  };

  const handleCopyInviteCode = () => {
    if (inviteCode) {
      navigator.clipboard.writeText(inviteCode);
      toast({
        title: "Copied!",
        description: "Invite code copied to clipboard.",
      });
    }
  };

  const handleRegenerateCode = async () => {
    if (!teamId) return;

    try {
      const { data, error } = await supabase
        .rpc("generate_invite_code");

      if (error) throw error;

      const newCode = data;

      const { error: updateError } = await supabase
        .from("team_invite_codes")
        .update({ invite_code: newCode })
        .eq("team_id", teamId);

      if (updateError) throw updateError;

      toast({
        title: "Code Regenerated",
        description: "New invite code has been generated.",
      });

      loadTeamData();
    } catch (error: any) {
      toast({
        title: "Failed to Regenerate",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleApproveMember = async (memberId: string) => {
    try {
      const { error } = await supabase
        .from("team_members")
        .update({ status: "active" })
        .eq("id", memberId);

      if (error) throw error;

      toast({
        title: "Member Approved",
        description: "Member has been added to the team.",
      });

      loadMembers();
    } catch (error: any) {
      toast({
        title: "Approval Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleRejectMember = async (memberId: string) => {
    try {
      const { error } = await supabase
        .from("team_members")
        .delete()
        .eq("id", memberId);

      if (error) throw error;

      toast({
        title: "Member Rejected",
        description: "Join request has been rejected.",
      });

      loadMembers();
    } catch (error: any) {
      toast({
        title: "Rejection Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleChangeRole = async (memberId: string, newRole: "leader" | "xo" | "member") => {
    try {
      const { error } = await supabase
        .from("team_members")
        .update({ role: newRole })
        .eq("id", memberId);

      if (error) throw error;

      toast({
        title: "Role Updated",
        description: `Member role changed to ${newRole}.`,
      });

      loadMembers();
    } catch (error: any) {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleRemoveMember = async () => {
    if (!removeTarget) return;

    try {
      const { error } = await supabase
        .from("team_members")
        .delete()
        .eq("id", removeTarget);

      if (error) throw error;

      toast({
        title: "Member Removed",
        description: "Member has been removed from the team.",
      });

      setRemoveTarget(null);
      loadMembers();
    } catch (error: any) {
      toast({
        title: "Remove Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <Shield className="w-12 h-12 text-primary mx-auto mb-4 animate-pulse" />
          <p className="text-muted-foreground">Verifying access...</p>
        </div>
      </div>
    );
  }

  if (!isAuthorized) return null;

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Shield className="w-6 h-6 text-primary" />
            <h1 className="text-2xl font-display font-bold">{team?.name} - TEAM ADMIN</h1>
          </div>
          <Button variant="outline" onClick={() => navigate(`/teams/${teamId}`)}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Team
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-6xl">
        <Tabs defaultValue="members" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 max-w-md">
            <TabsTrigger value="members">Members</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="members" className="space-y-4">
            {pendingMembers.length > 0 && (
              <Card className="shadow-tactical">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <UserCheck className="w-5 h-5" />
                    Pending Approvals ({pendingMembers.length})
                  </CardTitle>
                  <CardDescription>
                    Review and approve new team member requests
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {pendingMembers.map((member) => (
                      <div
                        key={member.id}
                        className="flex items-center justify-between p-3 rounded-lg border border-border"
                      >
                        <div className="flex-1">
                          <p className="font-medium">
                            {member.profiles?.display_name || "Unknown User"}
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            onClick={() => handleApproveMember(member.id)}
                          >
                            Approve
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleRejectMember(member.id)}
                          >
                            Reject
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            <Card className="shadow-tactical">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  Active Members ({members.length})
                </CardTitle>
                <CardDescription>
                  Manage team member roles and access
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {members.map((member) => (
                    <div
                      key={member.id}
                      className="flex items-center justify-between p-3 rounded-lg border border-border"
                    >
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <p className="font-medium">
                              {member.profiles?.display_name || "Unknown User"}
                            </p>
                            {member.role === "leader" && (
                              <Crown className="w-4 h-4 text-primary" />
                            )}
                          </div>
                        </div>

                      <div className="flex items-center gap-2">
                        <Select
                          value={member.role}
                          onValueChange={(value) => handleChangeRole(member.id, value as "leader" | "xo" | "member")}
                          disabled={member.user_id === user?.id}
                        >
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="leader">Leader</SelectItem>
                            <SelectItem value="xo">XO</SelectItem>
                            <SelectItem value="member">Member</SelectItem>
                          </SelectContent>
                        </Select>

                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setRemoveTarget(member.id)}
                          disabled={member.user_id === user?.id}
                        >
                          <UserX className="w-4 h-4 text-destructive" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-4">
            <Card className="shadow-tactical">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ImageIcon className="w-5 h-5" />
                  Team Logo
                </CardTitle>
                <CardDescription>
                  Upload a logo to represent your team
                </CardDescription>
              </CardHeader>
              <CardContent>
                {team && (
                  <TeamLogoUpload
                    teamId={team.id}
                    currentLogoUrl={team.logo_url}
                    onLogoUpdated={(url) => setTeam({ ...team, logo_url: url })}
                  />
                )}
              </CardContent>
            </Card>

            <Card className="shadow-tactical">
              <CardHeader>
                <CardTitle>Team Invite Code</CardTitle>
                <CardDescription>
                  Share this code with people you want to invite to your team
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-2">
                  <div className="flex-1 p-4 bg-muted rounded-lg font-mono text-2xl font-bold text-center">
                    {inviteCode || "------"}
                  </div>
                  <Button onClick={handleCopyInviteCode}>
                    <Copy className="w-4 h-4 mr-2" />
                    Copy
                  </Button>
                </div>
                <Button variant="outline" onClick={handleRegenerateCode}>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Regenerate Code
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <AlertDialog open={!!removeTarget} onOpenChange={() => setRemoveTarget(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Remove Team Member?</AlertDialogTitle>
              <AlertDialogDescription>
                This will remove the member from the team. They can rejoin using the invite code.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleRemoveMember} className="bg-destructive text-destructive-foreground">
                Remove Member
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </main>
    </div>
  );
};

export default TeamAdmin;
