import { useState, useEffect, useCallback, useRef } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Loader2, Target, Brain, Users, Heart, TrendingUp, Sparkles, Wand2, Compass, ChevronDown, ChevronUp, Upload, Save, Cloud, CloudOff } from "lucide-react";
import type { Json } from "@/integrations/supabase/types";
import { BattlePlanImport } from "@/components/BattlePlanImport";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { BattlePlanAIChat } from "@/components/BattlePlanAIChat";
import { BattlePlanWizard } from "@/components/BattlePlanWizard";

const quadrantSchema = z.object({
  objective: z.string().min(10, "Objective must be at least 10 characters"),
  primaryTactic: z.string().min(5, "Primary tactic is required"),
  secondaryTactic1: z.string().min(5, "At least one secondary tactic is required"),
  secondaryTactic2: z.string().optional(),
  secondaryTactic3: z.string().optional(),
  checkpoint30: z.string().min(10, "30-day checkpoint is required"),
  checkpoint60: z.string().min(10, "60-day checkpoint is required"),
});

const battlePlanSchema = z.object({
  vision: z.string().min(20, "Vision must be at least 20 characters"),
  startDate: z.date({ required_error: "Start date is required" }),
  endDate: z.date({ required_error: "End date is required" }),
  calibration: quadrantSchema,
  connection: quadrantSchema,
  condition: quadrantSchema,
  contribution: quadrantSchema,
});

type BattlePlanFormValues = z.infer<typeof battlePlanSchema>;

const CreateBattlePlan = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { id } = useParams();
  const [loading, setLoading] = useState(false);
  const [currentTeam, setCurrentTeam] = useState<any>(null);
  const [teamLoading, setTeamLoading] = useState(true);
  const [aiLoading, setAiLoading] = useState<Record<string, boolean>>({});
  const [aiTone, setAiTone] = useState<string>("motivational");
  const [aiChatOpen, setAiChatOpen] = useState(false);
  const [aiChatConfig, setAiChatConfig] = useState<{
    fieldType: "vision" | "objective" | "primary_tactic" | "secondary_tactics" | "checkpoints";
    context: any;
    quadrant?: string;
  } | null>(null);
  const [wizardOpen, setWizardOpen] = useState(false);
  const [longTermVisions, setLongTermVisions] = useState<{
    vision_1_year: string | null;
    vision_5_year: string | null;
    vision_10_year: string | null;
  } | null>(null);
  const [visionsExpanded, setVisionsExpanded] = useState(false);
  const [draftSaving, setDraftSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [draftLoaded, setDraftLoaded] = useState(false);
  const autoSaveTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const isEditMode = !!id;

  const form = useForm<BattlePlanFormValues>({
    resolver: zodResolver(battlePlanSchema),
    defaultValues: {
      vision: "",
      calibration: { objective: "", primaryTactic: "", secondaryTactic1: "", secondaryTactic2: "", secondaryTactic3: "", checkpoint30: "", checkpoint60: "" },
      connection: { objective: "", primaryTactic: "", secondaryTactic1: "", secondaryTactic2: "", secondaryTactic3: "", checkpoint30: "", checkpoint60: "" },
      condition: { objective: "", primaryTactic: "", secondaryTactic1: "", secondaryTactic2: "", secondaryTactic3: "", checkpoint30: "", checkpoint60: "" },
      contribution: { objective: "", primaryTactic: "", secondaryTactic1: "", secondaryTactic2: "", secondaryTactic3: "", checkpoint30: "", checkpoint60: "" },
    },
  });

  useEffect(() => {
    loadCurrentTeam();
    loadUserTonePreference();
    loadLongTermVisions();
  }, []);

  // Load draft when team is available (only for new battle plans)
  useEffect(() => {
    if (!isEditMode && currentTeam && user && !draftLoaded) {
      loadDraft();
    }
  }, [currentTeam, user, isEditMode, draftLoaded]);

  // Auto-save on form changes (debounced)
  const formValues = form.watch();
  useEffect(() => {
    if (!isEditMode && currentTeam && user && draftLoaded) {
      // Clear existing timeout
      if (autoSaveTimeoutRef.current) {
        clearTimeout(autoSaveTimeoutRef.current);
      }
      // Set new timeout for auto-save (30 seconds)
      autoSaveTimeoutRef.current = setTimeout(() => {
        saveDraft(true);
      }, 30000);
    }
    return () => {
      if (autoSaveTimeoutRef.current) {
        clearTimeout(autoSaveTimeoutRef.current);
      }
    };
  }, [formValues, currentTeam, user, isEditMode, draftLoaded]);

  // Load draft from database
  const loadDraft = async () => {
    if (!user || !currentTeam) return;
    
    try {
      const { data, error } = await supabase
        .from("battle_plan_drafts")
        .select("*")
        .eq("user_id", user.id)
        .eq("team_id", currentTeam.id)
        .maybeSingle();

      if (error && error.code !== "PGRST116") throw error;

      if (data?.form_data) {
        const formData = data.form_data as any;
        // Apply draft data to form
        if (formData.vision) form.setValue("vision", formData.vision);
        if (formData.startDate) form.setValue("startDate", new Date(formData.startDate));
        if (formData.endDate) form.setValue("endDate", new Date(formData.endDate));
        
        const quadrants = ["calibration", "connection", "condition", "contribution"] as const;
        quadrants.forEach(quadrant => {
          if (formData[quadrant]) {
            const q = formData[quadrant];
            if (q.objective) form.setValue(`${quadrant}.objective`, q.objective);
            if (q.primaryTactic) form.setValue(`${quadrant}.primaryTactic`, q.primaryTactic);
            if (q.secondaryTactic1) form.setValue(`${quadrant}.secondaryTactic1`, q.secondaryTactic1);
            if (q.secondaryTactic2) form.setValue(`${quadrant}.secondaryTactic2`, q.secondaryTactic2);
            if (q.secondaryTactic3) form.setValue(`${quadrant}.secondaryTactic3`, q.secondaryTactic3);
            if (q.checkpoint30) form.setValue(`${quadrant}.checkpoint30`, q.checkpoint30);
            if (q.checkpoint60) form.setValue(`${quadrant}.checkpoint60`, q.checkpoint60);
          }
        });
        
        setLastSaved(new Date(data.updated_at));
        toast.info("Draft loaded from your last session");
      }
    } catch (error) {
      console.error("Failed to load draft:", error);
    } finally {
      setDraftLoaded(true);
    }
  };

  // Save draft to database
  const saveDraft = async (isAutoSave = false) => {
    if (!user || !currentTeam) return;
    
    setDraftSaving(true);
    try {
      const values = form.getValues();
      const formData = {
        vision: values.vision,
        startDate: values.startDate?.toISOString(),
        endDate: values.endDate?.toISOString(),
        calibration: values.calibration,
        connection: values.connection,
        condition: values.condition,
        contribution: values.contribution,
      };

      const { error } = await supabase
        .from("battle_plan_drafts")
        .upsert({
          user_id: user.id,
          team_id: currentTeam.id,
          form_data: formData as unknown as Json,
        }, { onConflict: 'user_id,team_id' });

      if (error) throw error;

      setLastSaved(new Date());
      if (!isAutoSave) {
        toast.success("Draft saved successfully");
      }
    } catch (error) {
      console.error("Failed to save draft:", error);
      if (!isAutoSave) {
        toast.error("Failed to save draft");
      }
    } finally {
      setDraftSaving(false);
    }
  };

  // Delete draft after successful submission
  const deleteDraft = async () => {
    if (!user || !currentTeam) return;
    
    try {
      await supabase
        .from("battle_plan_drafts")
        .delete()
        .eq("user_id", user.id)
        .eq("team_id", currentTeam.id);
    } catch (error) {
      console.error("Failed to delete draft:", error);
    }
  };

  useEffect(() => {
    if (isEditMode && id) {
      loadBattlePlan(id);
    }
  }, [isEditMode, id]);

  const loadUserTonePreference = async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .from("profiles")
        .select("ai_tone_preference")
        .eq("id", user.id)
        .maybeSingle();

      if (error) throw error;
      
      if (data?.ai_tone_preference) {
        setAiTone(data.ai_tone_preference);
      }
    } catch (error) {
      console.error("Failed to load tone preference:", error);
    }
  };

  const loadLongTermVisions = async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .from("user_visions")
        .select("vision_1_year, vision_5_year, vision_10_year")
        .eq("user_id", user.id)
        .maybeSingle();

      if (error && error.code !== "PGRST116") throw error;
      
      if (data) {
        setLongTermVisions(data);
      }
    } catch (error) {
      console.error("Failed to load long-term visions:", error);
    }
  };

  const saveUserTonePreference = async (tone: string) => {
    if (!user) return;
    
    try {
      await supabase
        .from("profiles")
        .update({ ai_tone_preference: tone })
        .eq("id", user.id);
    } catch (error) {
      console.error("Failed to save tone preference:", error);
    }
  };

  const handleToneChange = (tone: string) => {
    setAiTone(tone);
    saveUserTonePreference(tone);
  };

  const loadCurrentTeam = async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .from("team_members")
        .select("team_id, teams(id, name)")
        .eq("user_id", user.id)
        .eq("status", "active")
        .limit(1)
        .single();

      if (error) throw error;
      
      if (data?.teams) {
        setCurrentTeam(data.teams);
      } else {
        toast.error("You need to join a team first");
        navigate("/");
      }
    } catch (error: any) {
      toast.error("Failed to load team");
      console.error(error);
      navigate("/");
    } finally {
      setTeamLoading(false);
    }
  };

  const loadBattlePlan = async (planId: string) => {
    setLoading(true);
    try {
      const { data: plan, error: planError } = await supabase
        .from("battle_plans")
        .select("*")
        .eq("id", planId)
        .single();

      if (planError) throw planError;

      const { data: objectives, error: objError } = await supabase
        .from("quadrant_objectives")
        .select("*")
        .eq("plan_id", planId);

      if (objError) throw objError;

      const { data: checkpoints, error: checkError } = await supabase
        .from("checkpoints")
        .select("*")
        .eq("plan_id", planId);

      if (checkError) throw checkError;

      const formData: any = {
        vision: plan.vision,
        startDate: new Date(plan.start_date),
        endDate: new Date(plan.end_date),
        calibration: { objective: "", primaryTactic: "", secondaryTactic1: "", secondaryTactic2: "", secondaryTactic3: "", checkpoint30: "", checkpoint60: "" },
        connection: { objective: "", primaryTactic: "", secondaryTactic1: "", secondaryTactic2: "", secondaryTactic3: "", checkpoint30: "", checkpoint60: "" },
        condition: { objective: "", primaryTactic: "", secondaryTactic1: "", secondaryTactic2: "", secondaryTactic3: "", checkpoint30: "", checkpoint60: "" },
        contribution: { objective: "", primaryTactic: "", secondaryTactic1: "", secondaryTactic2: "", secondaryTactic3: "", checkpoint30: "", checkpoint60: "" },
      };

      objectives.forEach((obj: any) => {
        const quadrant = obj.quadrant;
        const secondaryTactics = obj.secondary_tactics || [];
        formData[quadrant] = {
          objective: obj.objective,
          primaryTactic: obj.primary_tactic,
          secondaryTactic1: secondaryTactics[0] || "",
          secondaryTactic2: secondaryTactics[1] || "",
          secondaryTactic3: secondaryTactics[2] || "",
          checkpoint30: "",
          checkpoint60: "",
        };
      });

      checkpoints.forEach((cp: any) => {
        const quadrant = cp.quadrant;
        formData[quadrant].checkpoint30 = cp.day_30 || "";
        formData[quadrant].checkpoint60 = cp.day_60 || "";
      });

      form.reset(formData);
    } catch (error) {
      toast.error("Failed to load battle plan");
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const openAIChat = (
    fieldType: "vision" | "objective" | "primary_tactic" | "secondary_tactics" | "checkpoints",
    context: any,
    quadrant?: string
  ) => {
    const startDate = form.getValues("startDate");
    const endDate = form.getValues("endDate");
    
    const enrichedContext = {
      ...context,
      startDate: startDate ? format(startDate, "MMMM dd, yyyy") : undefined,
      endDate: endDate ? format(endDate, "MMMM dd, yyyy") : undefined,
      longTermVisions: longTermVisions,
    };

    setAiChatConfig({
      fieldType,
      context: enrichedContext,
      quadrant
    });
    setAiChatOpen(true);
  };

  const handleAIChatComplete = (result: any) => {
    if (!aiChatConfig) return;

    const { fieldType, context, quadrant } = aiChatConfig;

    try {
      if (fieldType === "secondary_tactics") {
        if (Array.isArray(result)) {
          form.setValue(`${quadrant}.secondaryTactic1` as any, result[0] || "");
          form.setValue(`${quadrant}.secondaryTactic2` as any, result[1] || "");
          form.setValue(`${quadrant}.secondaryTactic3` as any, result[2] || "");
        }
      } else if (fieldType === "checkpoints") {
        if (typeof result === "object" && result.day_30 && result.day_60) {
          form.setValue(`${quadrant}.checkpoint30` as any, result.day_30);
          form.setValue(`${quadrant}.checkpoint60` as any, result.day_60);
        }
      } else if (fieldType === "vision") {
        form.setValue("vision", result, { shouldValidate: true, shouldDirty: true });
      } else if (fieldType === "objective") {
        form.setValue(`${quadrant}.objective` as any, result, { shouldValidate: true, shouldDirty: true });
      } else if (fieldType === "primary_tactic") {
        form.setValue(`${quadrant}.primaryTactic` as any, result, { shouldValidate: true, shouldDirty: true });
      }
    } catch (error) {
      console.error("Error applying AI result:", error);
      toast.error("Failed to apply AI suggestion");
    }
  };

  const handleWizardUpdate = (data: any) => {
    console.log("Wizard update received:", JSON.stringify(data, null, 2));
    
    // Apply all wizard data to form
    if (data.vision) {
      form.setValue("vision", data.vision, { shouldValidate: true, shouldDirty: true });
    }

    const quadrants = ["calibration", "connection", "condition", "contribution"];
    quadrants.forEach(quadrant => {
      // Objective
      if (data[`${quadrant}_objective`]) {
        form.setValue(`${quadrant}.objective` as any, data[`${quadrant}_objective`], { shouldValidate: true });
      }
      
      // Primary tactic
      if (data[`${quadrant}_primary_tactic`]) {
        form.setValue(`${quadrant}.primaryTactic` as any, data[`${quadrant}_primary_tactic`], { shouldValidate: true });
      }
      
      // Secondary tactics - handle both array and string formats
      const secondaryTactics = data[`${quadrant}_secondary_tactics`];
      if (secondaryTactics) {
        if (Array.isArray(secondaryTactics)) {
          form.setValue(`${quadrant}.secondaryTactic1` as any, secondaryTactics[0] || "", { shouldValidate: true });
          form.setValue(`${quadrant}.secondaryTactic2` as any, secondaryTactics[1] || "", { shouldValidate: true });
          form.setValue(`${quadrant}.secondaryTactic3` as any, secondaryTactics[2] || "", { shouldValidate: true });
        } else if (typeof secondaryTactics === 'string') {
          // If it's a string, put it in the first field
          form.setValue(`${quadrant}.secondaryTactic1` as any, secondaryTactics, { shouldValidate: true });
        }
      }
      
      // Checkpoints - handle both object and string formats
      const checkpoints = data[`${quadrant}_checkpoints`];
      if (checkpoints) {
        if (typeof checkpoints === 'object' && checkpoints !== null) {
          // Standard object format with day_30/day_60 keys
          const day30 = checkpoints.day_30 || checkpoints.day30 || "";
          const day60 = checkpoints.day_60 || checkpoints.day60 || "";
          form.setValue(`${quadrant}.checkpoint30` as any, day30, { shouldValidate: true });
          form.setValue(`${quadrant}.checkpoint60` as any, day60, { shouldValidate: true });
        } else if (typeof checkpoints === 'string') {
          // If it's a string, put it in checkpoint30
          form.setValue(`${quadrant}.checkpoint30` as any, checkpoints, { shouldValidate: true });
        }
      }
    });
  };

  const handleImport = (plan: any) => {
    // Apply imported plan data to form
    if (plan.vision) {
      form.setValue("vision", plan.vision, { shouldValidate: true, shouldDirty: true });
    }

    const quadrants = ["calibration", "connection", "condition", "contribution"] as const;
    quadrants.forEach(quadrant => {
      const quadrantData = plan[quadrant];
      if (quadrantData) {
        if (quadrantData.objective) {
          form.setValue(`${quadrant}.objective`, quadrantData.objective, { shouldValidate: true });
        }
        if (quadrantData.primaryTactic) {
          form.setValue(`${quadrant}.primaryTactic`, quadrantData.primaryTactic, { shouldValidate: true });
        }
        if (quadrantData.secondaryTactic1) {
          form.setValue(`${quadrant}.secondaryTactic1`, quadrantData.secondaryTactic1);
        }
        if (quadrantData.secondaryTactic2) {
          form.setValue(`${quadrant}.secondaryTactic2`, quadrantData.secondaryTactic2);
        }
        if (quadrantData.secondaryTactic3) {
          form.setValue(`${quadrant}.secondaryTactic3`, quadrantData.secondaryTactic3);
        }
        if (quadrantData.checkpoint30) {
          form.setValue(`${quadrant}.checkpoint30`, quadrantData.checkpoint30, { shouldValidate: true });
        }
        if (quadrantData.checkpoint60) {
          form.setValue(`${quadrant}.checkpoint60`, quadrantData.checkpoint60, { shouldValidate: true });
        }
      }
    });
  };

  const onSubmit = async (values: BattlePlanFormValues) => {
    if (!user || !currentTeam) return;
    
    setLoading(true);

    try {
      if (isEditMode && id) {
        // Update existing battle plan
        const { error: planError } = await supabase
          .from("battle_plans")
          .update({
            team_id: currentTeam.id,
            vision: values.vision,
            start_date: format(values.startDate, "yyyy-MM-dd"),
            end_date: format(values.endDate, "yyyy-MM-dd"),
          })
          .eq("id", id);

        if (planError) throw planError;

        // Delete existing objectives and checkpoints
        await supabase.from("quadrant_objectives").delete().eq("plan_id", id);
        await supabase.from("checkpoints").delete().eq("plan_id", id);

        // Insert updated objectives and checkpoints
        const quadrants = ["calibration", "connection", "condition", "contribution"] as const;
        
        for (const quadrant of quadrants) {
          const quadrantData = values[quadrant];
          const secondaryTactics = [
            quadrantData.secondaryTactic1,
            quadrantData.secondaryTactic2,
            quadrantData.secondaryTactic3,
          ].filter(Boolean);

          const { error: objError } = await supabase
            .from("quadrant_objectives")
            .insert({
              plan_id: id,
              quadrant: quadrant,
              objective: quadrantData.objective,
              primary_tactic: quadrantData.primaryTactic,
              secondary_tactics: secondaryTactics,
            });

          if (objError) throw objError;

          const { error: checkError } = await supabase
            .from("checkpoints")
            .insert({
              plan_id: id,
              quadrant: quadrant,
              day_30: quadrantData.checkpoint30,
              day_60: quadrantData.checkpoint60,
            });

          if (checkError) throw checkError;
        }

        toast.success("Battle Plan updated successfully!");
      } else {
        // Create new battle plan
        const { data: planData, error: planError } = await supabase
          .from("battle_plans")
          .insert({
            user_id: user.id,
            team_id: currentTeam.id,
            vision: values.vision,
            start_date: format(values.startDate, "yyyy-MM-dd"),
            end_date: format(values.endDate, "yyyy-MM-dd"),
            active: true,
          })
          .select()
          .single();

        if (planError) throw planError;

        // Create objectives for each quadrant
        const quadrants = ["calibration", "connection", "condition", "contribution"] as const;
        
        for (const quadrant of quadrants) {
          const quadrantData = values[quadrant];
          const secondaryTactics = [
            quadrantData.secondaryTactic1,
            quadrantData.secondaryTactic2,
            quadrantData.secondaryTactic3,
          ].filter(Boolean);

          const { error: objError } = await supabase
            .from("quadrant_objectives")
            .insert({
              plan_id: planData.id,
              quadrant: quadrant,
              objective: quadrantData.objective,
              primary_tactic: quadrantData.primaryTactic,
              secondary_tactics: secondaryTactics,
            });

          if (objError) throw objError;

          const { error: checkError } = await supabase
            .from("checkpoints")
            .insert({
              plan_id: planData.id,
              quadrant: quadrant,
              day_30: quadrantData.checkpoint30,
              day_60: quadrantData.checkpoint60,
            });

          if (checkError) throw checkError;
        }

        // Delete draft after successful creation
        await deleteDraft();
        toast.success("Battle Plan created successfully!");
      }

      navigate(`/`);
    } catch (error: any) {
      toast.error(error.message || `Failed to ${isEditMode ? 'update' : 'create'} Battle Plan`);
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const renderQuadrantForm = (quadrant: "calibration" | "connection" | "condition" | "contribution", icon: any, title: string, description: string) => {
    const Icon = icon;
    
    return (
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Icon className="h-5 w-5 text-primary" />
            <CardTitle>{title}</CardTitle>
          </div>
          <CardDescription>{description}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <FormField
            control={form.control}
            name={`${quadrant}.objective`}
            render={({ field }) => (
              <FormItem>
                <div className="flex items-center justify-between">
                  <FormLabel>SMART Objective</FormLabel>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => openAIChat("objective", { 
                      quadrant, 
                      vision: form.getValues("vision") 
                    }, quadrant)}
                    disabled={!form.getValues("vision")}
                  >
                    <Sparkles className="h-4 w-4 mr-2" />
                    AI Chat
                  </Button>
                </div>
                <FormControl>
                  <Textarea
                    placeholder="Specific, Measurable, Achievable, Relevant, Time-bound objective..."
                    className="min-h-[80px]"
                    {...field}
                  />
                </FormControl>
                <FormDescription>
                  What specific, measurable outcome do you want to achieve in this quadrant?
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name={`${quadrant}.primaryTactic`}
            render={({ field }) => (
              <FormItem>
                <div className="flex items-center justify-between">
                  <FormLabel>Primary Tactic</FormLabel>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => openAIChat("primary_tactic", {
                      quadrant,
                      objective: form.getValues(`${quadrant}.objective`)
                    }, quadrant)}
                    disabled={!form.getValues(`${quadrant}.objective`)}
                  >
                    <Sparkles className="h-4 w-4 mr-2" />
                    AI Chat
                  </Button>
                </div>
                <FormControl>
                  <Input placeholder="Your main daily action..." {...field} />
                </FormControl>
                <FormDescription>
                  The one thing you'll do every day to achieve this objective
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <FormLabel>Secondary Tactics (2-3)</FormLabel>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => openAIChat("secondary_tactics", {
                  quadrant,
                  objective: form.getValues(`${quadrant}.objective`),
                  primaryTactic: form.getValues(`${quadrant}.primaryTactic`)
                }, quadrant)}
                disabled={!form.getValues(`${quadrant}.primaryTactic`)}
              >
                <Sparkles className="h-4 w-4 mr-2" />
                AI Chat
              </Button>
            </div>
            <FormField
              control={form.control}
              name={`${quadrant}.secondaryTactic1`}
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <Input placeholder="Secondary tactic 1..." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name={`${quadrant}.secondaryTactic2`}
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <Input placeholder="Secondary tactic 2 (optional)..." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name={`${quadrant}.secondaryTactic3`}
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <Input placeholder="Secondary tactic 3 (optional)..." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <FormLabel>Checkpoints</FormLabel>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => openAIChat("checkpoints", {
                  quadrant,
                  objective: form.getValues(`${quadrant}.objective`)
                }, quadrant)}
                disabled={!form.getValues(`${quadrant}.objective`)}
              >
                <Sparkles className="h-4 w-4 mr-2" />
                AI Chat
              </Button>
            </div>
            <FormDescription>
              Set measurable milestones to track your progress
            </FormDescription>
          </div>

          <FormField
            control={form.control}
            name={`${quadrant}.checkpoint30`}
            render={({ field }) => (
              <FormItem>
                <FormLabel>30-Day Checkpoint</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="What measurable progress should you see at 30 days?"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name={`${quadrant}.checkpoint60`}
            render={({ field }) => (
              <FormItem>
                <FormLabel>60-Day Checkpoint</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="What measurable progress should you see at 60 days?"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="container max-w-5xl mx-auto py-4 sm:py-8 px-3 sm:px-4">
      <div className="mb-6 sm:mb-8">
        <h1 className="text-2xl sm:text-3xl font-bold mb-2">{isEditMode ? 'Edit' : 'Create'} Battle Plan</h1>
        <p className="text-sm sm:text-base text-muted-foreground">
          {isEditMode ? 'Update your' : 'Define your'} 12-week vision and objectives across all four quadrants
        </p>
      </div>

      {/* AI Wizard */}
      <BattlePlanWizard
        open={wizardOpen}
        onOpenChange={setWizardOpen}
        context={{
          startDate: form.watch("startDate") ? format(form.watch("startDate"), "MMMM dd, yyyy") : undefined,
          endDate: form.watch("endDate") ? format(form.watch("endDate"), "MMMM dd, yyyy") : undefined,
        }}
        tone={aiTone}
        onUpdate={handleWizardUpdate}
        isFormEmpty={() => {
          const values = form.getValues();
          return !values.vision && 
            !values.calibration?.objective && 
            !values.connection?.objective && 
            !values.condition?.objective && 
            !values.contribution?.objective;
        }}
        existingFormData={form.getValues()}
      />

      {/* AI Chat Dialog */}
      {aiChatConfig && (
        <BattlePlanAIChat
          open={aiChatOpen}
          onOpenChange={setAiChatOpen}
          fieldType={aiChatConfig.fieldType}
          context={aiChatConfig.context}
          tone={aiTone}
          onComplete={handleAIChatComplete}
        />
      )}

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Timeline & Dates</CardTitle>
              <CardDescription>Set your 12-week battle plan timeframe</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Users className="h-4 w-4" />
                <span>Team: <strong>{teamLoading ? "Loading..." : currentTeam?.name || "No team"}</strong></span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="startDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Start Date</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={(date) => {
                              field.onChange(date);
                              if (date) {
                                const endDate = new Date(date);
                                endDate.setDate(endDate.getDate() + 84); // 12 weeks = 84 days
                                form.setValue("endDate", endDate);
                              }
                            }}
                            initialFocus
                            className="pointer-events-auto"
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="endDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>End Date</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            initialFocus
                            className="pointer-events-auto"
                          />
                        </PopoverContent>
                      </Popover>
                      <FormDescription>Should be 12 weeks from start date</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </CardContent>
          </Card>

          {/* AI Tools Card */}
          {!isEditMode && (
            <Card className="border-2 border-primary/20 bg-primary/5">
              <CardContent className="py-4 sm:py-6 px-4 sm:px-6">
                <div className="flex flex-col gap-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex-1">
                      <h3 className="text-base sm:text-lg font-semibold mb-1 flex items-center gap-2">
                        <Wand2 className="h-5 w-5 text-primary" />
                        Let AI Help You Build Your Battle Plan
                      </h3>
                      <p className="text-xs sm:text-sm text-muted-foreground">
                        Have a guided conversation to create your entire battle plan—vision, objectives, tactics, and checkpoints across all quadrants.
                      </p>
                    </div>
                    <Button
                      type="button"
                      size="lg"
                      onClick={() => {
                        const startDate = form.getValues("startDate");
                        const endDate = form.getValues("endDate");
                        
                        if (!startDate || !endDate) {
                          toast.error("Please select start and end dates first");
                          return;
                        }
                        
                        setWizardOpen(true);
                      }}
                      className="gap-2 w-full sm:w-auto"
                    >
                      <Wand2 className="h-5 w-5" />
                      Start Wizard
                    </Button>
                  </div>

                  {/* AI Tone Selection */}
                  <div className="border-t border-primary/20 pt-4">
                    <div className="p-3 bg-background/50 rounded-md space-y-3">
                      <div className="flex items-center gap-2">
                        <Label htmlFor="ai-tone" className="text-sm font-medium whitespace-nowrap">AI Tone:</Label>
                        <select
                          id="ai-tone"
                          value={aiTone}
                          onChange={(e) => handleToneChange(e.target.value)}
                          className="flex-1 bg-background border border-input rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                        >
                          <option value="motivational">Motivational</option>
                          <option value="tactical">Direct & Tactical</option>
                          <option value="professional">Professional</option>
                          <option value="casual">Conversational</option>
                          <option value="drill-sergeant">Drill Sergeant</option>
                          <option value="coach">Coach & Mentor</option>
                          <option value="stoic">Stoic & Philosophical</option>
                          <option value="brotherhood">Brotherhood</option>
                        </select>
                      </div>
                      <div className="text-xs text-muted-foreground italic border-l-2 border-primary/30 pl-3">
                        {aiTone === 'motivational' && '"Let\'s GO! This is YOUR moment to rise. What fire burns inside you? Let\'s channel that energy into unstoppable momentum!"'}
                        {aiTone === 'tactical' && '"State your primary objective. Be specific. Measurable. Time-bound. No fluff—just the mission."'}
                        {aiTone === 'professional' && '"Let\'s establish your strategic objectives. What specific outcomes do you aim to achieve within this 12-week period?"'}
                        {aiTone === 'casual' && '"Hey, so what\'s on your mind? What are you hoping to accomplish? Let\'s chat through it together."'}
                        {aiTone === 'drill-sergeant' && '"Listen up! I need to know what you\'re fighting for. No excuses, no maybes. What\'s the ONE thing you WILL achieve?"'}
                        {aiTone === 'coach' && '"I\'m here to help you succeed. Tell me—what matters most to you right now? Let\'s work through this together, step by step."'}
                        {aiTone === 'stoic' && '"Consider: what is truly within your control? Focus there. External circumstances matter less than your response to them."'}
                        {aiTone === 'brotherhood' && '"Brother, we\'re in this together. What battle are WE fighting? Your victory is our victory. Speak freely."'}
                      </div>
                    </div>
                  </div>
                  
                  <div className="border-t border-primary/20 pt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex-1">
                      <h3 className="text-base sm:text-lg font-semibold mb-1 flex items-center gap-2">
                        <Upload className="h-5 w-5 text-primary" />
                        Import Existing Battle Plan
                      </h3>
                      <p className="text-xs sm:text-sm text-muted-foreground">
                        Have an old plan or one written elsewhere? Paste the text and AI will extract the structured data.
                      </p>
                    </div>
                    <BattlePlanImport onImport={handleImport} />
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Long-Term Vision Context */}
          {longTermVisions && (longTermVisions.vision_1_year || longTermVisions.vision_5_year || longTermVisions.vision_10_year) && (
            <Card className="border-primary/20 bg-primary/5">
              <CardHeader className="pb-2">
                <button
                  type="button"
                  onClick={() => setVisionsExpanded(!visionsExpanded)}
                  className="flex items-center justify-between w-full text-left"
                >
                  <div className="flex items-center gap-2">
                    <Compass className="h-5 w-5 text-primary" />
                    <CardTitle className="text-base">Your Long-Term Vision</CardTitle>
                  </div>
                  {visionsExpanded ? (
                    <ChevronUp className="h-4 w-4 text-muted-foreground" />
                  ) : (
                    <ChevronDown className="h-4 w-4 text-muted-foreground" />
                  )}
                </button>
                <CardDescription className="text-xs">
                  Your 12-week plan should move you toward this bigger picture
                </CardDescription>
              </CardHeader>
              {visionsExpanded && (
                <CardContent className="pt-2 space-y-3">
                  {longTermVisions.vision_1_year && (
                    <div className="space-y-1">
                      <p className="text-xs font-medium text-primary">1-Year Vision</p>
                      <p className="text-sm text-muted-foreground">{longTermVisions.vision_1_year}</p>
                    </div>
                  )}
                  {longTermVisions.vision_5_year && (
                    <div className="space-y-1">
                      <p className="text-xs font-medium text-primary">5-Year Vision</p>
                      <p className="text-sm text-muted-foreground">{longTermVisions.vision_5_year}</p>
                    </div>
                  )}
                  {longTermVisions.vision_10_year && (
                    <div className="space-y-1">
                      <p className="text-xs font-medium text-primary">10-Year Vision</p>
                      <p className="text-sm text-muted-foreground">{longTermVisions.vision_10_year}</p>
                    </div>
                  )}
                  <Button
                    type="button"
                    variant="link"
                    size="sm"
                    onClick={() => navigate("/vision")}
                    className="p-0 h-auto text-xs"
                  >
                    Edit your long-term vision →
                  </Button>
                </CardContent>
              )}
            </Card>
          )}

          {/* Link to create long-term vision if not set */}
          {(!longTermVisions || (!longTermVisions.vision_1_year && !longTermVisions.vision_5_year && !longTermVisions.vision_10_year)) && (
            <Card className="border-dashed border-muted-foreground/30">
              <CardContent className="py-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Compass className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Define Your Long-Term Vision</p>
                      <p className="text-xs text-muted-foreground">Connect your 12-week plan to your bigger picture</p>
                    </div>
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => navigate("/vision")}
                  >
                    Create Vision
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle>12-Week Vision Statement</CardTitle>
              <CardDescription>What does winning look like for you in 12 weeks?</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="vision"
                render={({ field }) => (
                  <FormItem>
                    <div className="flex items-center justify-between">
                      <FormLabel>Vision Statement</FormLabel>
                        <Button
                         type="button"
                         variant="outline"
                         size="sm"
                         onClick={() => openAIChat("vision", { vision: form.getValues("vision") || "" })}
                       >
                          <Sparkles className="h-4 w-4 mr-2" />
                        AI Chat
                      </Button>
                    </div>
                    <FormControl>
                      <Textarea
                        placeholder="What does winning look like for you over the next 12 weeks?"
                        className="min-h-[120px]"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      Your overarching goal and what success looks like at the end of 12 weeks
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <Tabs defaultValue="calibration" className="w-full">
            <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 h-auto">
              <TabsTrigger value="calibration" className="text-xs sm:text-sm py-2">
                <Brain className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
                <span className="hidden sm:inline">Calibration</span>
                <span className="sm:hidden">Calib.</span>
              </TabsTrigger>
              <TabsTrigger value="connection" className="text-xs sm:text-sm py-2">
                <Users className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
                <span className="hidden sm:inline">Connection</span>
                <span className="sm:hidden">Conn.</span>
              </TabsTrigger>
              <TabsTrigger value="condition" className="text-xs sm:text-sm py-2">
                <Heart className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
                <span className="hidden sm:inline">Condition</span>
                <span className="sm:hidden">Cond.</span>
              </TabsTrigger>
              <TabsTrigger value="contribution" className="text-xs sm:text-sm py-2">
                <TrendingUp className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
                <span className="hidden sm:inline">Contribution</span>
                <span className="sm:hidden">Contrib.</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="calibration" className="mt-6">
              {renderQuadrantForm("calibration", Brain, "Calibration", "Mental, Spiritual & Emotional Development")}
            </TabsContent>

            <TabsContent value="connection" className="mt-6">
              {renderQuadrantForm("connection", Users, "Connection", "Relationships & Community")}
            </TabsContent>

            <TabsContent value="condition" className="mt-6">
              {renderQuadrantForm("condition", Heart, "Condition", "Physical Health & Fitness")}
            </TabsContent>

            <TabsContent value="contribution" className="mt-6">
              {renderQuadrantForm("contribution", TrendingUp, "Contribution", "Wealth, Value & Impact")}
            </TabsContent>
          </Tabs>

          {/* Auto-save indicator */}
          {!isEditMode && lastSaved && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground self-center">
              {draftSaving ? (
                <>
                  <Loader2 className="h-3 w-3 animate-spin" />
                  <span>Saving...</span>
                </>
              ) : (
                <>
                  <Cloud className="h-3 w-3 text-green-500" />
                  <span>Draft saved {lastSaved.toLocaleTimeString()}</span>
                </>
              )}
            </div>
          )}

          <div className="flex flex-col-reverse sm:flex-row gap-3 sm:gap-4">
            <Button type="button" variant="outline" onClick={() => navigate("/")} className="w-full sm:w-auto">
              Cancel
            </Button>
            {!isEditMode && (
              <Button 
                type="button" 
                variant="secondary" 
                onClick={() => saveDraft(false)} 
                disabled={draftSaving || !currentTeam}
                className="w-full sm:w-auto gap-2"
              >
                {draftSaving ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Save className="h-4 w-4" />
                )}
                Save as Draft
              </Button>
            )}
            <Button type="submit" disabled={loading} className="w-full sm:w-auto">
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {isEditMode ? 'Updating...' : 'Creating...'}
                </>
              ) : (
                isEditMode ? 'Update Battle Plan' : 'Create Battle Plan'
              )}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default CreateBattlePlan;
