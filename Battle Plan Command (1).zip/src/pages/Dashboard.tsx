import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { LogOut, Plus, Users, Target, TrendingUp, Shield, Compass, ClipboardList, Settings } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { BattlePlanTimeline } from "@/components/BattlePlanTimeline";
import { VisionDashboardCard } from "@/components/VisionDashboardCard";

interface Team {
  id: string;
  name: string;
  description: string;
  role: string;
}

const Dashboard = () => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [teams, setTeams] = useState<Team[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [battlePlans, setBattlePlans] = useState<any[]>([]);
  const [plansLoading, setPlansLoading] = useState(true);
  const [streak, setStreak] = useState(0);
  const [completionRate, setCompletionRate] = useState(0);
  const [displayName, setDisplayName] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      checkAdminStatus();
      loadTeams();
      loadBattlePlans();
      calculateStreak();
      calculateCompletionRate();
      loadProfile();
    }
  }, [user]);

  const loadProfile = async () => {
    try {
      const { data } = await supabase
        .from("profiles")
        .select("display_name")
        .eq("id", user?.id)
        .maybeSingle();
      
      setDisplayName(data?.display_name || null);
    } catch (error) {
      console.error("Error loading profile:", error);
    }
  };

  const checkAdminStatus = async () => {
    try {
      const { data } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user?.id)
        .eq("role", "admin")
        .maybeSingle();
      
      setIsAdmin(!!data);
    } catch (error) {
      console.error("Error checking admin status:", error);
    }
  };

  const loadTeams = async () => {
    try {
      const { data, error } = await supabase
        .from("team_members")
        .select(`
          role,
          status,
          teams (
            id,
            name,
            description
          )
        `)
        .eq("user_id", user?.id)
        .eq("status", "active");

      if (error) throw error;

      const formattedTeams = data?.map((item: any) => ({
        id: item.teams.id,
        name: item.teams.name,
        description: item.teams.description,
        role: item.role,
      })) || [];

      setTeams(formattedTeams);
    } catch (error) {
      console.error("Error loading teams:", error);
    } finally {
      setLoading(false);
    }
  };

  const loadBattlePlans = async () => {
    try {
      const { data, error } = await supabase
        .from("battle_plans")
        .select(`
          id,
          vision,
          start_date,
          end_date,
          active,
          teams (
            name
          )
        `)
        .eq("user_id", user?.id)
        .order("created_at", { ascending: false });

      if (error) throw error;

      setBattlePlans(data || []);
    } catch (error) {
      console.error("Error loading battle plans:", error);
    } finally {
      setPlansLoading(false);
    }
  };

  const calculateStreak = async () => {
    try {
      const { data, error } = await supabase
        .from("daily_logs")
        .select("log_date, non_negotiables, tasks, objectives")
        .eq("user_id", user?.id)
        .order("log_date", { ascending: false });

      if (error) throw error;
      if (!data || data.length === 0) {
        setStreak(0);
        return;
      }

      let currentStreak = 0;
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      // Check each day starting from today going backwards
      for (let i = 0; i < 365; i++) {
        const checkDate = new Date(today);
        checkDate.setDate(today.getDate() - i);
        const dateString = checkDate.toISOString().split('T')[0];

        const log = data.find(l => l.log_date === dateString);
        
        if (!log) {
          // If we're checking today or yesterday and there's no log, streak might still be valid
          if (i <= 1) continue;
          break;
        }

        // Check if any items were completed
        const nonNegotiables = Array.isArray(log.non_negotiables) ? log.non_negotiables : [];
        const tasks = Array.isArray(log.tasks) ? log.tasks : [];
        const objectives = Array.isArray(log.objectives) ? log.objectives : [];

        const hasCompletedItems = 
          nonNegotiables.some((item: any) => item.completed) ||
          tasks.some((item: any) => item.completed) ||
          objectives.some((item: any) => item.completed);

        if (hasCompletedItems) {
          currentStreak++;
        } else if (i > 1) {
          break;
        }
      }

      setStreak(currentStreak);
    } catch (error) {
      console.error("Error calculating streak:", error);
      setStreak(0);
    }
  };

  const calculateCompletionRate = async () => {
    try {
      const { data, error } = await supabase
        .from("daily_logs")
        .select("non_negotiables, tasks, objectives")
        .eq("user_id", user?.id);

      if (error) throw error;
      if (!data || data.length === 0) {
        setCompletionRate(0);
        return;
      }

      let totalItems = 0;
      let completedItems = 0;

      data.forEach(log => {
        const nonNegotiables = Array.isArray(log.non_negotiables) ? log.non_negotiables : [];
        const tasks = Array.isArray(log.tasks) ? log.tasks : [];
        const objectives = Array.isArray(log.objectives) ? log.objectives : [];

        const allItems = [...nonNegotiables, ...tasks, ...objectives];
        
        allItems.forEach((item: any) => {
          totalItems++;
          if (item.completed) {
            completedItems++;
          }
        });
      });

      const rate = totalItems > 0 ? Math.round((completedItems / totalItems) * 100) : 0;
      setCompletionRate(rate);
    } catch (error) {
      console.error("Error calculating completion rate:", error);
      setCompletionRate(0);
    }
  };

  const calculateProgress = (startDate: string, endDate: string) => {
    const start = new Date(startDate).getTime();
    const end = new Date(endDate).getTime();
    const now = Date.now();

    if (now < start) return 0;
    if (now > end) return 100;

    const total = end - start;
    const elapsed = now - start;
    return Math.round((elapsed / total) * 100);
  };

  const getStatusBadge = (active: boolean, startDate: string, endDate: string) => {
    const now = Date.now();
    const start = new Date(startDate).getTime();
    const end = new Date(endDate).getTime();

    if (!active) return { label: "Inactive", color: "bg-muted text-muted-foreground" };
    if (now < start) return { label: "Upcoming", color: "bg-blue-500/20 text-blue-500" };
    if (now > end) return { label: "Completed", color: "bg-green-500/20 text-green-500" };
    return { label: "Active", color: "bg-primary/20 text-primary" };
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-3 sm:px-4 py-3 sm:py-4">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 sm:gap-4 min-w-0">
              <h1 className="text-lg sm:text-2xl font-display font-bold whitespace-nowrap">BATTLE PLAN</h1>
              {teams.length > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => navigate(`/teams/${teams[0].id}`)}
                  className="hidden sm:flex items-center gap-2"
                >
                  <Users className="w-4 h-4" />
                  {teams[0].name}
                </Button>
              )}
            </div>
            <div className="flex items-center gap-2 sm:gap-4">
              {isAdmin && (
                <Button 
                  variant="secondary" 
                  size="sm" 
                  onClick={() => navigate("/admin")}
                  className="hidden sm:flex"
                >
                  <Shield className="w-4 h-4 mr-2" />
                  Admin Panel
                </Button>
              )}
              {isAdmin && (
                <Button 
                  variant="secondary" 
                  size="icon" 
                  onClick={() => navigate("/admin")}
                  className="sm:hidden"
                >
                  <Shield className="w-4 h-4" />
                </Button>
              )}
              <span className="text-sm text-muted-foreground hidden lg:inline">{user?.email}</span>
              <Button variant="ghost" size="icon" onClick={() => navigate("/settings")} title="Settings">
                <Settings className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={signOut} className="hidden sm:flex">
                <LogOut className="w-4 h-4 mr-2" />
                Sign Out
              </Button>
              <Button variant="outline" size="icon" onClick={signOut} className="sm:hidden">
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
          {/* Mobile team button */}
          {teams.length > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate(`/teams/${teams[0].id}`)}
              className="sm:hidden mt-2 w-full flex items-center justify-center gap-2"
            >
              <Users className="w-4 h-4" />
              {teams[0].name}
            </Button>
          )}
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8 animate-fade-in">
          <h2 className="text-2xl sm:text-3xl font-display font-bold mb-2">
            Welcome Back{displayName ? `, ${displayName}` : ''}
          </h2>
          <p className="text-muted-foreground text-sm sm:text-base">
            Ready to execute your battle plan and achieve mission success.
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <Card className="shadow-tactical">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Current Streak</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{streak} {streak === 1 ? 'Day' : 'Days'} {streak > 0 && '🔥'}</div>
            </CardContent>
          </Card>

          <Card className="shadow-tactical">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Completion Rate</CardTitle>
              <Target className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{completionRate}%</div>
            </CardContent>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
          <Button 
            variant="outline" 
            className="h-auto py-4 px-6 flex items-center justify-start gap-4 shadow-tactical hover:shadow-command transition-shadow"
            onClick={() => navigate("/vision")}
          >
            <div className="p-2 rounded-lg bg-primary/10">
              <Compass className="h-5 w-5 text-primary" />
            </div>
            <div className="text-left">
              <div className="font-semibold">Long-Term Vision</div>
              <div className="text-sm text-muted-foreground">Define your 1, 5, and 10 year vision</div>
            </div>
          </Button>

          <Button 
            variant="outline" 
            className="h-auto py-4 px-6 flex items-center justify-start gap-4 shadow-tactical hover:shadow-command transition-shadow"
            onClick={() => navigate("/after-action-reviews")}
          >
            <div className="p-2 rounded-lg bg-primary/10">
              <ClipboardList className="h-5 w-5 text-primary" />
            </div>
            <div className="text-left">
              <div className="font-semibold">After Action Reviews</div>
              <div className="text-sm text-muted-foreground">Quarterly & yearly reflections</div>
            </div>
          </Button>
        </div>

        {/* No Team Warning */}
        {!loading && teams.length === 0 && (
          <Card className="shadow-tactical mb-8">
            <CardContent className="py-12 text-center">
              <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h4 className="text-lg font-semibold mb-2">No Battle Team</h4>
              <p className="text-muted-foreground mb-4">
                {isAdmin 
                  ? "Create a battle team to get started or join an existing one with an invite code."
                  : "Join a battle team with an invite code from your team leader to access all features."}
              </p>
              <div className="flex gap-2 justify-center">
                {isAdmin && (
                  <Button onClick={() => navigate("/teams/create")}>
                    <Plus className="w-4 h-4 mr-2" />
                    Create Team
                  </Button>
                )}
                <Button variant={isAdmin ? "outline" : "default"} onClick={() => navigate("/teams/join")}>
                  Join Team
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Battle Plans Section */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
            <h3 className="text-lg sm:text-xl font-display font-bold">Your Battle Plans</h3>
            <Button onClick={() => navigate("/battle-plans/create")} className="w-full sm:w-auto">
              <Plus className="w-4 h-4 mr-2" />
              Create Battle Plan
            </Button>
          </div>

          {plansLoading ? (
            <Card>
              <CardContent className="py-8 text-center text-muted-foreground">
                Loading your battle plans...
              </CardContent>
            </Card>
          ) : battlePlans.length === 0 ? (
            <Card className="shadow-tactical">
              <CardContent className="py-12 text-center">
                <Target className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h4 className="text-lg font-semibold mb-2">No Active Battle Plans</h4>
                <p className="text-muted-foreground mb-4">
                  Create your first 12-week battle plan to define your vision and objectives.
                </p>
                <Button onClick={() => navigate("/battle-plans/create")}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Battle Plan
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {battlePlans.map((plan) => {
                const progress = calculateProgress(plan.start_date, plan.end_date);
                const status = getStatusBadge(plan.active, plan.start_date, plan.end_date);
                
                return (
                  <div key={plan.id} className="space-y-4">
                    <Card className="shadow-tactical hover:shadow-command transition-shadow">
                      <CardHeader className="p-4 sm:p-6">
                        <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                          <span className={`text-xs px-2 py-1 rounded-md ${status.color}`}>
                            {status.label}
                          </span>
                          <span className="text-[10px] sm:text-xs text-muted-foreground">
                            {new Date(plan.start_date).toLocaleDateString()} - {new Date(plan.end_date).toLocaleDateString()}
                          </span>
                        </div>
                        <CardTitle className="text-base sm:text-lg leading-relaxed text-center">{plan.vision}</CardTitle>
                        <CardDescription>{plan.teams?.name}</CardDescription>
                      </CardHeader>
                      <CardContent className="p-4 sm:p-6 pt-0 sm:pt-0">
                        <div className="space-y-4">
                          
                          {/* Animated Timeline */}
                          <div className="animate-fade-in">
                            <BattlePlanTimeline 
                              startDate={new Date(plan.start_date)} 
                              endDate={new Date(plan.end_date)} 
                            />
                          </div>
                          
                          <div className="flex flex-col sm:flex-row gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={(e) => {
                                e.stopPropagation();
                                navigate(`/battle-plans/edit/${plan.id}`);
                              }}
                              className="w-full sm:w-auto"
                            >
                              Edit
                            </Button>
                            <Button
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation();
                                navigate(`/battle-plans/${plan.id}/metrics`);
                              }}
                              className="w-full sm:w-auto"
                            >
                              Submit Metrics
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Quick Actions */}
        <Card className="shadow-tactical">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <Button
              variant="outline"
              className="justify-start"
              disabled={teams.length === 0}
              onClick={() => {
                if (teams.length > 0) {
                  navigate(`/teams/${teams[0].id}/plans`);
                }
              }}
            >
              <Users className="w-4 h-4 mr-2" />
              View Team Plans
              {teams.length === 0 && (
                <span className="ml-2 text-xs text-muted-foreground">(Join a team first)</span>
              )}
            </Button>
            <Button
              variant="outline"
              className="justify-start"
              disabled={battlePlans.length === 0}
              onClick={() => {
                if (battlePlans.length > 0) {
                  navigate(`/battle-plans/${battlePlans[0].id}/metrics`);
                }
              }}
            >
              <TrendingUp className="w-4 h-4 mr-2" />
              Log Weekly Metrics
              {battlePlans.length === 0 && (
                <span className="ml-2 text-xs text-muted-foreground">(Create a Battle Plan first)</span>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Vision Dashboard Card */}
        <div className="mt-8">
          <VisionDashboardCard />
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
