import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { ArrowLeft, Users } from "lucide-react";

const JoinTeam = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [inviteCode, setInviteCode] = useState("");
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!inviteCode.trim()) {
      toast({
        title: "Invalid Code",
        description: "Please enter an invite code",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      // Check if user is already in a team
      const { data: existingMembership, error: checkError } = await supabase
        .from("team_members")
        .select("id, teams(name)")
        .eq("user_id", user?.id)
        .eq("status", "active")
        .maybeSingle();

      if (checkError) throw checkError;

      if (existingMembership) {
        toast({
          title: "Already in a Team",
          description: `You are already a member of ${(existingMembership as any).teams?.name}. Please leave your current team first.`,
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      // Find team by invite code from the secure invite codes table
      const { data: inviteData, error: inviteError } = await supabase
        .from("team_invite_codes")
        .select("team_id, teams(id, name)")
        .eq("invite_code", inviteCode.trim().toUpperCase())
        .single();

      const team = inviteData?.teams as { id: string; name: string } | null;
      const teamError = inviteError;

      if (teamError || !team) {
        toast({
          title: "Invalid Invite Code",
          description: "No team found with this invite code. Please check and try again.",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      // Add user to team
      const { error: memberError } = await supabase
        .from("team_members")
        .insert({
          team_id: team.id,
          user_id: user?.id,
          role: "member",
          status: "active",
        });

      if (memberError) {
        // Check if it's a duplicate entry error
        if (memberError.code === "23505") {
          toast({
            title: "Already Requested",
            description: "You have already requested to join this team.",
            variant: "destructive",
          });
        } else {
          throw memberError;
        }
        setIsLoading(false);
        return;
      }

      toast({
        title: "Welcome Aboard!",
        description: `You have successfully joined ${team.name}.`,
      });

      navigate(`/teams/${team.id}`);
    } catch (error: any) {
      toast({
        title: "Failed to Join Team",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <Button variant="ghost" onClick={() => navigate("/")}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-2xl">
        <div className="mb-6 animate-fade-in text-center">
          <div className="flex justify-center mb-4">
            <div className="p-4 bg-primary/10 rounded-full">
              <Users className="w-12 h-12 text-primary" />
            </div>
          </div>
          <h1 className="text-3xl font-display font-bold mb-2">Join a Battle Team</h1>
          <p className="text-muted-foreground">
            Enter the invite code provided by your team leader to join.
          </p>
        </div>

        <Card className="shadow-tactical">
          <CardHeader>
            <CardTitle>Enter Invite Code</CardTitle>
            <CardDescription>
              The invite code is a 6-character alphanumeric code (e.g., ABC123)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="inviteCode">Invite Code *</Label>
                <Input
                  id="inviteCode"
                  name="inviteCode"
                  placeholder="ABC123"
                  value={inviteCode}
                  onChange={(e) => setInviteCode(e.target.value.toUpperCase())}
                  required
                  maxLength={6}
                  className="text-center text-2xl font-mono tracking-widest"
                />
                <p className="text-xs text-muted-foreground">
                  Invite codes are not case-sensitive
                </p>
              </div>

              <div className="flex gap-3">
                <Button type="submit" disabled={isLoading} className="flex-1">
                  {isLoading ? "Joining..." : "Join Team"}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate("/")}
                  disabled={isLoading}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        <div className="mt-6 p-4 bg-muted rounded-lg">
          <h3 className="font-semibold mb-2">Don't have an invite code?</h3>
          <p className="text-sm text-muted-foreground">
            Contact your team leader or administrator to get an invite code. You can only be a member of one team at a time.
          </p>
        </div>
      </main>
    </div>
  );
};

export default JoinTeam;
