import { useNavigate, useParams } from "react-router-dom";
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Minus, History } from "lucide-react";

const quadrantMetricsSchema = z.object({
  progress: z.string().min(1, "Progress description is required"),
  wins: z.string().optional(),
  challenges: z.string().optional(),
  score: z.string().regex(/^\d+$/, "Must be a number").transform(Number).pipe(z.number().min(1).max(10)),
});

const weeklyMetricsSchema = z.object({
  calibration: quadrantMetricsSchema,
  connection: quadrantMetricsSchema,
  condition: quadrantMetricsSchema,
  contribution: quadrantMetricsSchema,
});

type WeeklyMetricsFormValues = z.infer<typeof weeklyMetricsSchema>;

export default function SubmitWeeklyMetrics() {
  const navigate = useNavigate();
  const { id } = useParams();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [battlePlan, setBattlePlan] = useState<any>(null);
  const [objectives, setObjectives] = useState<any[]>([]);
  const [currentWeek, setCurrentWeek] = useState(1);
  const [historicalMetrics, setHistoricalMetrics] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState("submit");

  const form = useForm<WeeklyMetricsFormValues>({
    resolver: zodResolver(weeklyMetricsSchema),
    defaultValues: {
      calibration: { progress: "", wins: "", challenges: "", score: 5 },
      connection: { progress: "", wins: "", challenges: "", score: 5 },
      condition: { progress: "", wins: "", challenges: "", score: 5 },
      contribution: { progress: "", wins: "", challenges: "", score: 5 },
    },
  });

  useEffect(() => {
    if (id) {
      loadBattlePlan(id);
      loadHistoricalMetrics(id);
    }
  }, [id]);

  const loadBattlePlan = async (planId: string) => {
    setIsLoading(true);
    try {
      const { data: plan, error: planError } = await supabase
        .from("battle_plans")
        .select("*, teams(name)")
        .eq("id", planId)
        .single();

      if (planError) throw planError;

      const { data: objs, error: objError } = await supabase
        .from("quadrant_objectives")
        .select("*")
        .eq("plan_id", planId);

      if (objError) throw objError;

      setBattlePlan(plan);
      setObjectives(objs);

      // Calculate current week
      const startDate = new Date(plan.start_date);
      const today = new Date();
      const diffTime = today.getTime() - startDate.getTime();
      const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
      const weekNum = Math.min(Math.floor(diffDays / 7) + 1, 12);
      setCurrentWeek(weekNum);
    } catch (error) {
      console.error("Error loading battle plan:", error);
      toast({
        title: "Error",
        description: "Failed to load battle plan",
        variant: "destructive",
      });
      navigate("/");
    } finally {
      setIsLoading(false);
    }
  };

  const onSubmit = async (values: WeeklyMetricsFormValues) => {
    if (!id) return;

    setIsLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({
          title: "Error",
          description: "You must be logged in",
          variant: "destructive",
        });
        return;
      }

      const quadrantData = {
        calibration: values.calibration,
        connection: values.connection,
        condition: values.condition,
        contribution: values.contribution,
      };

      const { error } = await supabase
        .from("weekly_metrics")
        .insert({
          user_id: user.id,
          plan_id: id,
          week_number: currentWeek,
          quadrant_data: quadrantData,
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: `Week ${currentWeek} metrics submitted successfully!`,
      });

      // Reload historical metrics
      await loadHistoricalMetrics(id);
      
      // Switch to history tab
      setActiveTab("history");
      
      // Reset form
      form.reset();
    } catch (error) {
      console.error("Error submitting metrics:", error);
      toast({
        title: "Error",
        description: "Failed to submit metrics. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const loadHistoricalMetrics = async (planId: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from("weekly_metrics")
        .select("*")
        .eq("plan_id", planId)
        .eq("user_id", user.id)
        .order("week_number", { ascending: false });

      if (error) throw error;
      setHistoricalMetrics(data || []);
    } catch (error) {
      console.error("Error loading historical metrics:", error);
    }
  };

  const getObjectivesForQuadrant = (quadrant: string) => {
    return objectives.filter(obj => obj.quadrant === quadrant);
  };

  const getScoreTrend = (quadrant: string, currentWeek: number) => {
    if (historicalMetrics.length < 2) return null;
    
    const sortedMetrics = [...historicalMetrics].sort((a, b) => a.week_number - b.week_number);
    const currentMetric = sortedMetrics.find(m => m.week_number === currentWeek);
    const previousMetric = sortedMetrics.find(m => m.week_number === currentWeek - 1);
    
    if (!currentMetric || !previousMetric) return null;
    
    const currentScore = currentMetric.quadrant_data[quadrant]?.score || 0;
    const previousScore = previousMetric.quadrant_data[quadrant]?.score || 0;
    
    if (currentScore > previousScore) return "up";
    if (currentScore < previousScore) return "down";
    return "same";
  };

  const getAverageScore = (quadrant: string) => {
    if (historicalMetrics.length === 0) return 0;
    const scores = historicalMetrics.map(m => m.quadrant_data[quadrant]?.score || 0);
    return (scores.reduce((a, b) => a + b, 0) / scores.length).toFixed(1);
  };

  if (isLoading || !battlePlan) {
    return (
      <div className="container mx-auto p-6">
        <div className="text-center">Loading...</div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <div className="mb-6">
        <h1 className="text-3xl font-display font-bold">Weekly Metrics</h1>
        <p className="text-muted-foreground mt-2">
          Week {currentWeek} of 12 - {battlePlan.teams?.name}
        </p>
        <p className="text-sm text-muted-foreground">
          Vision: {battlePlan.vision}
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="submit">Submit Metrics</TabsTrigger>
          <TabsTrigger value="history">
            <History className="w-4 h-4 mr-2" />
            History ({historicalMetrics.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="submit">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {(['calibration', 'connection', 'condition', 'contribution'] as const).map((quadrant) => {
                const quadrantObjs = getObjectivesForQuadrant(quadrant);
                const quadrantName = quadrant.charAt(0).toUpperCase() + quadrant.slice(1);
                const avgScore = getAverageScore(quadrant);
                
                return (
                  <Card key={quadrant}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle>{quadrantName}</CardTitle>
                        {historicalMetrics.length > 0 && (
                          <Badge variant="outline">Avg Score: {avgScore}/10</Badge>
                        )}
                      </div>
                      <CardDescription>
                        {quadrantObjs.length > 0 && (
                          <div className="mt-2">
                            <strong>Objectives:</strong>
                            <ul className="list-disc list-inside mt-1 text-sm">
                              {quadrantObjs.map((obj, idx) => (
                                <li key={idx}>{obj.objective}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </CardDescription>
                    </CardHeader>
                <CardContent className="space-y-4">
                  <FormField
                    control={form.control}
                    name={`${quadrant}.progress`}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Progress Summary *</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Describe your progress this week..."
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name={`${quadrant}.wins`}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Wins</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="What went well this week?"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name={`${quadrant}.challenges`}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Challenges</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="What obstacles did you face?"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name={`${quadrant}.score`}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Score (1-10) *</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            min="1"
                            max="10"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>
            );
          })}

          <div className="flex gap-4">
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Submitting..." : "Submit Metrics"}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate("/")}
            >
              Cancel
            </Button>
          </div>
        </form>
      </Form>
    </TabsContent>

    <TabsContent value="history">
      {historicalMetrics.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <History className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No History Yet</h3>
            <p className="text-muted-foreground">
              Submit your first weekly metrics to start tracking your progress.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {historicalMetrics.map((metric) => (
            <Card key={metric.id} className="shadow-tactical">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Week {metric.week_number}</CardTitle>
                  <Badge variant="secondary">
                    {new Date(metric.submission_date).toLocaleDateString()}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {(['calibration', 'connection', 'condition', 'contribution'] as const).map((quadrant) => {
                    const data = metric.quadrant_data[quadrant];
                    const quadrantName = quadrant.charAt(0).toUpperCase() + quadrant.slice(1);
                    const trend = getScoreTrend(quadrant, metric.week_number);
                    
                    return (
                      <div key={quadrant} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="font-semibold">{quadrantName}</h4>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">{data?.score || 0}/10</Badge>
                            {trend === "up" && <TrendingUp className="w-4 h-4 text-green-500" />}
                            {trend === "down" && <TrendingDown className="w-4 h-4 text-red-500" />}
                            {trend === "same" && <Minus className="w-4 h-4 text-muted-foreground" />}
                          </div>
                        </div>
                        
                        {data?.progress && (
                          <div className="mb-2">
                            <p className="text-xs font-medium text-muted-foreground mb-1">Progress</p>
                            <p className="text-sm">{data.progress}</p>
                          </div>
                        )}
                        
                        {data?.wins && (
                          <div className="mb-2">
                            <p className="text-xs font-medium text-muted-foreground mb-1">Wins</p>
                            <p className="text-sm">{data.wins}</p>
                          </div>
                        )}
                        
                        {data?.challenges && (
                          <div>
                            <p className="text-xs font-medium text-muted-foreground mb-1">Challenges</p>
                            <p className="text-sm">{data.challenges}</p>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
      
      <div className="mt-6">
        <Button variant="outline" onClick={() => navigate("/")}>
          Back to Dashboard
        </Button>
      </div>
    </TabsContent>
  </Tabs>
    </div>
  );
}
