import { useEffect, useState, useRef } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Sparkles, Save, Loader2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { VisionGoingDeeper } from "@/components/VisionGoingDeeper";

type VisionTimeframe = "1_year" | "5_year" | "10_year";

interface Message {
  role: "assistant" | "user";
  content: string;
}

interface GoingDeeperData {
  yearly_theme: string;
  life_categories: Record<string, { target1: string; target2: string; target3: string }>;
  body_metrics: Record<string, string>;
  financial_metrics: Record<string, string>;
  bucket_list: string[];
  accountability_needs: string;
  help_needed: string;
}

const LongTermVision = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [visions, setVisions] = useState({
    vision_1_year: "",
    vision_5_year: "",
    vision_10_year: "",
  });
  const [goingDeeper, setGoingDeeper] = useState<GoingDeeperData>({
    yearly_theme: "",
    life_categories: {},
    body_metrics: {},
    financial_metrics: {},
    bucket_list: [],
    accountability_needs: "",
    help_needed: "",
  });
  
  // AI Chat state
  const [chatOpen, setChatOpen] = useState(false);
  const [activeTimeframe, setActiveTimeframe] = useState<VisionTimeframe>("1_year");
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [conversationHistory, setConversationHistory] = useState<any[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  // Refocus input when AI loading completes
  useEffect(() => {
    if (!aiLoading && chatOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [aiLoading, chatOpen]);

  useEffect(() => {
    loadVisions();
  }, [user]);

  const loadVisions = async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .from("user_visions")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle();

      if (error && error.code !== "PGRST116") throw error;

      if (data) {
        setVisions({
          vision_1_year: data.vision_1_year || "",
          vision_5_year: data.vision_5_year || "",
          vision_10_year: data.vision_10_year || "",
        });
        setGoingDeeper({
          yearly_theme: data.yearly_theme || "",
          life_categories: (data.life_categories as Record<string, { target1: string; target2: string; target3: string }>) || {},
          body_metrics: (data.body_metrics as Record<string, string>) || {},
          financial_metrics: (data.financial_metrics as Record<string, string>) || {},
          bucket_list: (data.bucket_list as string[]) || [],
          accountability_needs: data.accountability_needs || "",
          help_needed: data.help_needed || "",
        });
      }
    } catch (error) {
      console.error("Error loading visions:", error);
      toast.error("Failed to load your visions");
    } finally {
      setLoading(false);
    }
  };

  const saveVisions = async () => {
    if (!user) return;
    
    setSaving(true);
    try {
      const { error } = await supabase
        .from("user_visions")
        .upsert({
          user_id: user.id,
          vision_1_year: visions.vision_1_year || null,
          vision_5_year: visions.vision_5_year || null,
          vision_10_year: visions.vision_10_year || null,
          yearly_theme: goingDeeper.yearly_theme || null,
          life_categories: goingDeeper.life_categories,
          body_metrics: goingDeeper.body_metrics,
          financial_metrics: goingDeeper.financial_metrics,
          bucket_list: goingDeeper.bucket_list,
          accountability_needs: goingDeeper.accountability_needs || null,
          help_needed: goingDeeper.help_needed || null,
        }, { onConflict: "user_id" });

      if (error) throw error;
      toast.success("Visions saved successfully");
    } catch (error) {
      console.error("Error saving visions:", error);
      toast.error("Failed to save visions");
    } finally {
      setSaving(false);
    }
  };

  const openAIChat = (timeframe: VisionTimeframe) => {
    setActiveTimeframe(timeframe);
    setMessages([]);
    setConversationHistory([]);
    setInput("");
    setChatOpen(true);
    startConversation(timeframe);
  };

  const startConversation = async (timeframe: VisionTimeframe) => {
    setAiLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("long-term-vision-ai", {
        body: {
          timeframe,
          conversationHistory: [],
          userInput: "",
          existingVisions: visions,
        },
      });

      if (error) throw error;
      
      setMessages([{ role: "assistant", content: data.suggestion }]);
    } catch (error) {
      console.error("Error starting AI conversation:", error);
      toast.error("Failed to start AI conversation");
    } finally {
      setAiLoading(false);
    }
  };

  const sendMessage = async () => {
    if (!input.trim() || aiLoading) return;

    const userMessage = input.trim();
    setInput("");
    
    const newMessages = [...messages, { role: "user" as const, content: userMessage }];
    setMessages(newMessages);
    
    const newHistory = [
      ...conversationHistory,
      { role: "assistant", content: messages[messages.length - 1]?.content || "" },
      { role: "user", content: userMessage },
    ];
    setConversationHistory(newHistory);

    setAiLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("long-term-vision-ai", {
        body: {
          timeframe: activeTimeframe,
          conversationHistory: newHistory,
          userInput: userMessage,
          existingVisions: visions,
        },
      });

      if (error) throw error;
      
      setMessages([...newMessages, { role: "assistant", content: data.suggestion }]);

      // Check if AI has formatted a final vision
      const response = data.suggestion;
      if (response.includes("Here's your") || response.includes("Your vision:")) {
        // Extract the vision text
        const visionMatch = response.match(/(?:Here's your|Your vision:)[^:]*:?\s*[""]?([^""]+)[""]?/i) ||
                          response.match(/[""]([^""]+)[""]/) ||
                          response.match(/:\s*(.+)$/m);
        
        if (visionMatch) {
          const fieldKey = `vision_${activeTimeframe}` as keyof typeof visions;
          setVisions(prev => ({ ...prev, [fieldKey]: visionMatch[1].trim() }));
        }
      }
    } catch (error) {
      console.error("Error in AI conversation:", error);
      toast.error("Failed to get AI response");
    } finally {
      setAiLoading(false);
    }
  };

  const getTimeframeLabel = (timeframe: VisionTimeframe) => {
    switch (timeframe) {
      case "1_year": return "1 Year";
      case "5_year": return "5 Year";
      case "10_year": return "10 Year";
    }
  };

  const getTimeframeDescription = (timeframe: VisionTimeframe) => {
    switch (timeframe) {
      case "1_year": return "What do you want to accomplish in the next 12 months?";
      case "5_year": return "Where do you see yourself in 5 years?";
      case "10_year": return "What's your ultimate long-term vision?";
    }
  };

  const examplePrompts: Record<VisionTimeframe, string[]> = {
    "1_year": [
      "I want to be healthier and more financially stable",
      "I'm focused on career growth and family time",
      "I want to break some bad habits and build better ones"
    ],
    "5_year": [
      "I want to be debt-free with a growing business",
      "I see myself in a leadership role with a strong family life",
      "I want financial freedom and location independence"
    ],
    "10_year": [
      "I want to have built generational wealth",
      "I see myself mentoring others and giving back",
      "I want to be known for making a real impact"
    ]
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-xl sm:text-2xl font-display font-bold">Long-Term Vision</h1>
              <p className="text-sm text-muted-foreground">Define where you're headed</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-8">
          <p className="text-muted-foreground">
            Your long-term vision guides your 12-week battle plans. Think big, be specific, and remember - this is YOUR vision.
          </p>
        </div>

        <div className="space-y-6">
          {(["1_year", "5_year", "10_year"] as VisionTimeframe[]).map((timeframe) => {
            const fieldKey = `vision_${timeframe}` as keyof typeof visions;
            
            return (
              <Card key={timeframe} className="shadow-tactical">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-lg">{getTimeframeLabel(timeframe)} Vision</CardTitle>
                      <CardDescription>{getTimeframeDescription(timeframe)}</CardDescription>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => openAIChat(timeframe)}
                      className="gap-2"
                    >
                      <Sparkles className="w-4 h-4" />
                      AI Guide
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <Textarea
                    placeholder={`Describe your ${getTimeframeLabel(timeframe).toLowerCase()} vision...`}
                    value={visions[fieldKey]}
                    onChange={(e) => setVisions(prev => ({ ...prev, [fieldKey]: e.target.value }))}
                    className="min-h-[120px] resize-none"
                  />
                </CardContent>
              </Card>
            );
          })}

          {/* Going Deeper Section */}
          <VisionGoingDeeper
            yearlyTheme={goingDeeper.yearly_theme}
            lifeCategories={goingDeeper.life_categories}
            bodyMetrics={goingDeeper.body_metrics}
            financialMetrics={goingDeeper.financial_metrics}
            bucketList={goingDeeper.bucket_list}
            accountabilityNeeds={goingDeeper.accountability_needs}
            helpNeeded={goingDeeper.help_needed}
            onChange={(field, value) => setGoingDeeper(prev => ({ ...prev, [field]: value }))}
          />
        </div>

        <div className="mt-8 flex justify-end">
          <Button onClick={saveVisions} disabled={saving} className="gap-2">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            Save Visions
          </Button>
        </div>
      </main>

      {/* AI Chat Dialog */}
      <Dialog open={chatOpen} onOpenChange={setChatOpen}>
        <DialogContent className="w-[95vw] max-w-2xl h-[85vh] sm:h-[600px] flex flex-col p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-primary" />
              {getTimeframeLabel(activeTimeframe)} Vision Guide
            </DialogTitle>
            <DialogDescription>
              Let's discover what you truly want for your future
            </DialogDescription>
          </DialogHeader>

          <ScrollArea className="flex-1 pr-4">
            <div className="space-y-4">
              {messages.map((msg, idx) => (
                <div
                  key={idx}
                  className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[85%] rounded-lg px-4 py-2 text-sm ${
                      msg.role === "user"
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-foreground"
                    }`}
                  >
                    {msg.content}
                  </div>
                </div>
              ))}
              {aiLoading && (
                <div className="flex justify-start">
                  <div className="bg-muted rounded-lg px-4 py-2">
                    <Loader2 className="w-4 h-4 animate-spin" />
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>

          {/* Example prompts */}
          {messages.length === 1 && !aiLoading && (
            <div className="px-1 py-2 border-t border-border/50">
              <p className="text-xs text-muted-foreground mb-2">Not sure what to say? Try one of these:</p>
              <div className="flex flex-wrap gap-2">
                {examplePrompts[activeTimeframe].map((prompt, index) => (
                  <button
                    key={index}
                    onClick={() => setInput(prompt)}
                    className="text-xs px-3 py-1.5 rounded-full bg-muted hover:bg-muted/80 text-muted-foreground hover:text-foreground transition-colors text-left"
                  >
                    {prompt}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="flex gap-2 pt-3 border-t">
            <Input
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && sendMessage()}
              placeholder="Share your thoughts..."
              disabled={aiLoading}
              autoFocus
            />
            <Button onClick={sendMessage} disabled={aiLoading || !input.trim()}>
              Send
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default LongTermVision;
