import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Copy, Users, Calendar, Shield, TrendingUp, LogOut } from "lucide-react";
import { Loader2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface Team {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
  created_by: string | null;
  invite_code?: string; // Only available to leaders/XOs
  logo_url?: string | null;
}

interface TeamMember {
  id: string;
  user_id: string;
  role: string;
  status: string;
  joined_at: string;
  profiles: {
    display_name: string | null;
    avatar_url: string | null;
  } | null;
}

const TeamDetail = () => {
  const { teamId } = useParams<{ teamId: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [team, setTeam] = useState<Team | null>(null);
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isLeaderOrXO, setIsLeaderOrXO] = useState(false);
  const [currentUserMember, setCurrentUserMember] = useState<TeamMember | null>(null);
  const [isLeavingTeam, setIsLeavingTeam] = useState(false);

  useEffect(() => {
    if (!teamId) return;
    
    const loadTeamData = async () => {
      try {
        // Load team details
        const { data: teamData, error: teamError } = await supabase
          .from("teams")
          .select("id, name, description, created_at, created_by, logo_url")
          .eq("id", teamId)
          .single();

        if (teamError) throw teamError;

        // Load team members with limited profile data (no email for privacy)
        const { data: membersData, error: membersError } = await supabase
          .from("team_members")
          .select(`
            *,
            profiles:user_id (
              display_name,
              avatar_url
            )
          `)
          .eq("team_id", teamId);

        if (membersError) throw membersError;
        setMembers(membersData || []);

        // Check if current user is leader or XO
        let inviteCode: string | undefined;
        if (user) {
          const currentMember = membersData?.find(m => m.user_id === user.id);
          setCurrentUserMember(currentMember || null);
          if (currentMember && ["leader", "xo"].includes(currentMember.role)) {
            setIsLeaderOrXO(true);
            // Fetch invite code for leaders/XOs
            const { data: inviteData } = await supabase
              .from("team_invite_codes")
              .select("invite_code")
              .eq("team_id", teamId)
              .single();
            inviteCode = inviteData?.invite_code;
          }
        }
        setTeam({ ...teamData, invite_code: inviteCode });
      } catch (error: any) {
        toast({
          title: "Failed to Load Team",
          description: error.message,
          variant: "destructive",
        });
        navigate("/");
      } finally {
        setIsLoading(false);
      }
    };

    loadTeamData();
  }, [teamId, navigate, toast]);

  const copyInviteCode = () => {
    if (team?.invite_code) {
      navigator.clipboard.writeText(team.invite_code);
      toast({
        title: "Copied!",
        description: "Invite code copied to clipboard",
      });
    }
  };

  const handleLeaveTeam = async () => {
    if (!currentUserMember || !user) return;

    // Prevent the last leader from leaving
    if (currentUserMember.role === "leader") {
      const leaderCount = members.filter(m => m.role === "leader" && m.status === "active").length;
      if (leaderCount <= 1) {
        toast({
          title: "Cannot Leave Team",
          description: "You are the only leader. Please assign another leader before leaving or delete the team.",
          variant: "destructive",
        });
        return;
      }
    }

    setIsLeavingTeam(true);
    try {
      const { error } = await supabase
        .from("team_members")
        .delete()
        .eq("id", currentUserMember.id);

      if (error) throw error;

      toast({
        title: "Left Team",
        description: "You have successfully left the team.",
      });

      navigate("/");
    } catch (error: any) {
      toast({
        title: "Failed to Leave Team",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLeavingTeam(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!team) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Button variant="ghost" onClick={() => navigate("/")}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
          <div className="flex items-center gap-2">
            {isLeaderOrXO && (
              <div className="flex gap-2">
                <Button onClick={() => navigate(`/teams/${teamId}/analytics`)}>
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Team Analytics
                </Button>
                <Button variant="secondary" onClick={() => navigate(`/teams/${teamId}/admin`)}>
                  <Shield className="w-4 h-4 mr-2" />
                  Team Admin
                </Button>
              </div>
            )}
            {currentUserMember && (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive" size="sm">
                    <LogOut className="w-4 h-4 mr-2" />
                    Leave Team
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Leave Team?</AlertDialogTitle>
                    <AlertDialogDescription>
                      Are you sure you want to leave this team? You'll need a new invite code to rejoin.
                      {currentUserMember.role === "leader" && (
                        <span className="block mt-2 text-destructive font-semibold">
                          Warning: As a team leader, make sure there's another leader before leaving.
                        </span>
                      )}
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={handleLeaveTeam}
                      disabled={isLeavingTeam}
                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    >
                      {isLeavingTeam ? "Leaving..." : "Leave Team"}
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-8 animate-fade-in flex items-center gap-4">
          {team.logo_url && (
            <img
              src={team.logo_url}
              alt={`${team.name} logo`}
              className="w-16 h-16 rounded-lg object-cover border border-border"
            />
          )}
          <div>
            <h1 className="text-4xl font-display font-bold mb-2">{team.name}</h1>
            {team.description && (
              <p className="text-muted-foreground text-lg">{team.description}</p>
            )}
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-2 mb-8">
          {isLeaderOrXO && team.invite_code && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Copy className="w-5 h-5" />
                  Invite Code
                </CardTitle>
                <CardDescription>Share this code to invite members (Leaders/XOs only)</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <code className="flex-1 bg-muted px-4 py-2 rounded font-mono text-lg">
                    {team.invite_code}
                  </code>
                  <Button onClick={copyInviteCode} variant="outline" size="icon">
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Team Info
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Created</span>
                <span className="font-medium">
                  {new Date(team.created_at).toLocaleDateString()}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Members</span>
                <span className="font-medium">{members.length}</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              Team Members
            </CardTitle>
            <CardDescription>Active members of your battle team</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {members.map((member) => (
                <div
                  key={member.id}
                  className="flex items-center justify-between p-3 rounded-lg border border-border"
                >
                  <div>
                    <p className="font-medium">
                      {member.profiles?.display_name || "Unknown User"}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-medium capitalize px-3 py-1 rounded-full bg-primary/10 text-primary">
                      {member.role}
                    </span>
                    {member.status === "pending" && (
                      <span className="text-sm text-muted-foreground">Pending</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default TeamDetail;
