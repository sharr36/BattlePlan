import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Target, Users, Calendar } from "lucide-react";
import { Loader2 } from "lucide-react";
import { BattlePlanTimeline } from "@/components/BattlePlanTimeline";

interface TeamPlan {
  id: string;
  vision: string;
  start_date: string;
  end_date: string;
  active: boolean;
  user_id: string;
  profiles: {
    display_name: string | null;
  } | null;
}

interface Team {
  id: string;
  name: string;
}

const TeamPlans = () => {
  const { teamId } = useParams<{ teamId: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [team, setTeam] = useState<Team | null>(null);
  const [plans, setPlans] = useState<TeamPlan[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!teamId || !user) return;
    loadData();
  }, [teamId, user]);

  const loadData = async () => {
    try {
      // Load team info
      const { data: teamData, error: teamError } = await supabase
        .from("teams")
        .select("id, name")
        .eq("id", teamId)
        .single();

      if (teamError) throw teamError;
      setTeam(teamData);

      // Load battle plans for this team with user profiles
      const { data: plansData, error: plansError } = await supabase
        .from("battle_plans")
        .select(`
          id,
          vision,
          start_date,
          end_date,
          active,
          user_id,
          profiles:user_id (
            display_name
          )
        `)
        .eq("team_id", teamId)
        .order("start_date", { ascending: false });

      if (plansError) throw plansError;
      setPlans(plansData || []);
    } catch (error) {
      console.error("Error loading team plans:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusBadge = (active: boolean, startDate: string, endDate: string) => {
    const now = Date.now();
    const start = new Date(startDate).getTime();
    const end = new Date(endDate).getTime();

    if (!active) return { label: "Inactive", color: "bg-muted text-muted-foreground" };
    if (now < start) return { label: "Upcoming", color: "bg-blue-500/20 text-blue-500" };
    if (now > end) return { label: "Completed", color: "bg-green-500/20 text-green-500" };
    return { label: "Active", color: "bg-primary/20 text-primary" };
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Button variant="ghost" onClick={() => navigate("/")}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
          <Button variant="outline" onClick={() => navigate(`/teams/${teamId}`)}>
            <Users className="w-4 h-4 mr-2" />
            Team Dashboard
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-8 animate-fade-in">
          <h1 className="text-3xl font-display font-bold mb-2">
            {team?.name} Battle Plans
          </h1>
          <p className="text-muted-foreground">
            View all battle plans from your team members
          </p>
        </div>

        {plans.length === 0 ? (
          <Card className="shadow-tactical">
            <CardContent className="py-12 text-center">
              <Target className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h4 className="text-lg font-semibold mb-2">No Team Battle Plans</h4>
              <p className="text-muted-foreground mb-4">
                No battle plans have been created for this team yet.
              </p>
              <Button onClick={() => navigate("/battle-plans/create")}>
                Create Battle Plan
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {plans.map((plan) => {
              const status = getStatusBadge(plan.active, plan.start_date, plan.end_date);
              const isOwnPlan = plan.user_id === user?.id;

              return (
                <Card 
                  key={plan.id} 
                  className={`shadow-tactical hover:shadow-command transition-shadow ${isOwnPlan ? 'ring-1 ring-primary/30' : ''}`}
                >
                  <CardHeader className="pb-2">
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2">
                        <span className={`text-xs px-2 py-1 rounded-md ${status.color}`}>
                          {status.label}
                        </span>
                        {isOwnPlan && (
                          <span className="text-xs px-2 py-1 rounded-md bg-primary/10 text-primary">
                            Your Plan
                          </span>
                        )}
                      </div>
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {new Date(plan.start_date).toLocaleDateString()} - {new Date(plan.end_date).toLocaleDateString()}
                      </span>
                    </div>
                    <CardTitle className="text-lg">{plan.vision}</CardTitle>
                    <CardDescription className="flex items-center gap-1">
                      <Users className="w-3 h-3" />
                      {plan.profiles?.display_name || "Unknown User"}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <BattlePlanTimeline 
                      startDate={new Date(plan.start_date)} 
                      endDate={new Date(plan.end_date)} 
                    />
                    
                    {isOwnPlan && (
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => navigate(`/battle-plans/edit/${plan.id}`)}
                        >
                          Edit
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => navigate(`/battle-plans/${plan.id}/metrics`)}
                        >
                          Submit Metrics
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
};

export default TeamPlans;
