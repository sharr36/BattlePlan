import { useState, useEffect, useRef } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

import { Progress } from "@/components/ui/progress";
import { Loader2, Send, Sparkles, CheckCircle2, Minimize2, RotateCcw, Play, ArrowRight, MessageCircle, Clock, Pencil, BookOpen } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import type { Json } from "@/integrations/supabase/types";

interface Message {
  role: "user" | "assistant";
  content: string;
}

interface WizardStep {
  id: string;
  label: string;
  fieldType: "vision" | "objective" | "primary_tactic" | "secondary_tactics" | "checkpoints" | "non_negotiables";
  quadrant?: "calibration" | "connection" | "condition" | "contribution";
  completed: boolean;
}

interface BattlePlanWizardProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  context: {
    startDate?: string;
    endDate?: string;
  };
  tone: string;
  onUpdate: (data: any) => void;
  isFormEmpty?: () => boolean;
  existingFormData?: {
    vision?: string;
    calibration?: { objective?: string; primaryTactic?: string; secondaryTactic1?: string; secondaryTactic2?: string; secondaryTactic3?: string; checkpoint30?: string; checkpoint60?: string; };
    connection?: { objective?: string; primaryTactic?: string; secondaryTactic1?: string; secondaryTactic2?: string; secondaryTactic3?: string; checkpoint30?: string; checkpoint60?: string; };
    condition?: { objective?: string; primaryTactic?: string; secondaryTactic1?: string; secondaryTactic2?: string; secondaryTactic3?: string; checkpoint30?: string; checkpoint60?: string; };
    contribution?: { objective?: string; primaryTactic?: string; secondaryTactic1?: string; secondaryTactic2?: string; secondaryTactic3?: string; checkpoint30?: string; checkpoint60?: string; };
  };
}

export const BattlePlanWizard = ({ 
  open, 
  onOpenChange, 
  context,
  tone,
  onUpdate,
  isFormEmpty,
  existingFormData
}: BattlePlanWizardProps) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [collectedData, setCollectedData] = useState<any>({});
  const [currentQuadrant, setCurrentQuadrant] = useState<string>("");
  const [isMinimized, setIsMinimized] = useState(false);
  const [showResumePrompt, setShowResumePrompt] = useState(false);
  const [savedProgress, setSavedProgress] = useState<any>(null);
  const [pendingAdvance, setPendingAdvance] = useState<{ nextIndex: number; data: any } | null>(null);
  const [editingStepIndex, setEditingStepIndex] = useState<number | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const isAtBottomRef = useRef(true);

  const handleChatScroll = () => {
    const el = scrollContainerRef.current;
    if (!el) return;
    const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    isAtBottomRef.current = distanceFromBottom < 40;
  };
  const STORAGE_KEY = "battle-plan-wizard-progress";

  const steps: WizardStep[] = [
    { id: "vision", label: "Vision Statement", fieldType: "vision", completed: false },
    { id: "calibration-obj", label: "Calibration Objective", fieldType: "objective", quadrant: "calibration", completed: false },
    { id: "calibration-tactic", label: "Calibration Primary Tactic", fieldType: "primary_tactic", quadrant: "calibration", completed: false },
    { id: "calibration-secondary", label: "Calibration Secondary Tactics", fieldType: "secondary_tactics", quadrant: "calibration", completed: false },
    { id: "calibration-checkpoints", label: "Calibration Checkpoints", fieldType: "checkpoints", quadrant: "calibration", completed: false },
    { id: "connection-obj", label: "Connection Objective", fieldType: "objective", quadrant: "connection", completed: false },
    { id: "connection-tactic", label: "Connection Primary Tactic", fieldType: "primary_tactic", quadrant: "connection", completed: false },
    { id: "connection-secondary", label: "Connection Secondary Tactics", fieldType: "secondary_tactics", quadrant: "connection", completed: false },
    { id: "connection-checkpoints", label: "Connection Checkpoints", fieldType: "checkpoints", quadrant: "connection", completed: false },
    { id: "condition-obj", label: "Condition Objective", fieldType: "objective", quadrant: "condition", completed: false },
    { id: "condition-tactic", label: "Condition Primary Tactic", fieldType: "primary_tactic", quadrant: "condition", completed: false },
    { id: "condition-secondary", label: "Condition Secondary Tactics", fieldType: "secondary_tactics", quadrant: "condition", completed: false },
    { id: "condition-checkpoints", label: "Condition Checkpoints", fieldType: "checkpoints", quadrant: "condition", completed: false },
    { id: "contribution-obj", label: "Contribution Objective", fieldType: "objective", quadrant: "contribution", completed: false },
    { id: "contribution-tactic", label: "Contribution Primary Tactic", fieldType: "primary_tactic", quadrant: "contribution", completed: false },
    { id: "contribution-secondary", label: "Contribution Secondary Tactics", fieldType: "secondary_tactics", quadrant: "contribution", completed: false },
    { id: "contribution-checkpoints", label: "Contribution Checkpoints", fieldType: "checkpoints", quadrant: "contribution", completed: false },
    { id: "non-negotiables", label: "Daily Non-Negotiables", fieldType: "non_negotiables", completed: false },
  ];

  const isWizardComplete = currentStepIndex >= steps.length;
  const progress = isWizardComplete ? 100 : (currentStepIndex / steps.length) * 100;
  const WIZARD_TYPE = "battle_plan";

  const completionPatterns: Record<WizardStep["fieldType"], RegExp[]> = {
    vision: [/(?:^|\n)\s*your\s+(?:90[- ]day\s+)?vision\s*:/i, /\b90[- ]day\s+vision\s*:/i, /\byour\s+vision\s*:/i],
    objective: [/here'?s\s+your\s+(?:smart\s+)?objective\s*:/i, /\bsmart\s+objective\s*:/i, /\byour\s+(?:\w+\s+){0,3}objective\s*:/i, /\*\*(?:your\s+)?(?:\w+\s+)?objective:\*\*/i],
    primary_tactic: [/\byour\s+(?:\w+\s+){0,3}(?:primary\s+)?(?:daily\s+)?tactic\s*:/i, /\bprimary\s+tactic\s*:/i],
    secondary_tactics: [
      /here\s+are\s+your\s+(?:\w+\s+){0,3}supporting\s+(?:\w+\s+){0,2}tactics\s*:/i,
      /\bsupporting\s+(?:\w+\s+){0,2}tactics\b/i,
      /\bsecondary\s+tactics\b/i,
    ],
    checkpoints: [/here\s+are\s+your\s+(?:\w+\s+){0,3}checkpoints\s*:/i, /\byour\s+(?:\w+\s+){0,3}checkpoints\s*:/i],
    non_negotiables: [/here\s+are\s+your\s+(?:daily\s+)?non[- ]negotiables\s*:/i, /\byour\s+non[- ]negotiables\s*:/i, /\bnon[- ]negotiables\s*:/i],
  };

  const stripTrailingFollowup = (text: string) =>
    text
      .replace(/(?:\r?\n){1,2}(?:with that|now we|let's|now,|moving forward|this completes|that completes|we can now|shall we|ready to|how does|does this)[\s\S]*$/i, "")
      .trim();

  const sanitizeCapturedText = (text: string) => text.replace(/^["'*]+|["'*]+$/g, "").trim();

  const isStepCompleteFromText = (fieldType: WizardStep["fieldType"], text: string) => {
    const raw = String(text ?? "");

    // FIRST: Check for explicit completion markers - these DIRECTLY indicate completion
    // Trust these markers without requiring additional pattern matches
    const hasExplicitCompletion = /has been saved|✅|we've now completed|that completes|here are your confirmed|i'm glad|excellent!/i.test(raw);
    
    // If we have explicit completion markers, trust them immediately
    if (hasExplicitCompletion) {
      return true;
    }

    // For secondary_tactics: check for JSON array OR numbered list format
    if (fieldType === "secondary_tactics") {
      // Check for JSON (legacy)
      const codeBlockMatch = raw.match(/```(?:json)?\s*([\s\S]*?)```/i);
      const candidate = (codeBlockMatch ? codeBlockMatch[1] : raw).trim();
      const jsonMatch = candidate.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        try {
          JSON.parse(jsonMatch[0]);
          return true;
        } catch { /* fall through */ }
      }
      // Check for numbered list after "here are your ... tactics"
      if (/here\s+are\s+your\s+(?:\w+\s+)*tactics/i.test(raw) && /^\s*\d+\.\s+/m.test(raw)) {
        return true;
      }
    }

    // For checkpoints: check for JSON object OR markdown **Day 30/60:** format
    if (fieldType === "checkpoints") {
      // Check for JSON (legacy)
      const codeBlockMatch = raw.match(/```(?:json)?\s*([\s\S]*?)```/i);
      const candidate = (codeBlockMatch ? codeBlockMatch[1] : raw).trim();
      const jsonMatch = candidate.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        try {
          JSON.parse(jsonMatch[0]);
          return true;
        } catch { /* fall through */ }
      }
      // Check for markdown Day 30/60 format
      if (/\*\*Day\s*30\b/i.test(raw) && /\*\*Day\s*60\b/i.test(raw)) {
        return true;
      }
    }

    // Otherwise, check if the AI is asking questions (waiting for feedback)
    const lastParagraph = raw.split(/\n\n/).pop() || raw;
    const hasQuestionInLastParagraph = /\?/.test(lastParagraph);
    
    // Common question patterns that indicate the AI wants user input
    const questionPatterns = [
      /how does (?:this|that|it|the)\b/i,
      /does (?:this|that|it|achieving)\b.*\?/i,
      /what (?:aspect|do you|would you|feels|is)\b/i,
      /could you (?:tell|share|describe)/i,
      /can you (?:tell|share|describe)/i,
      /feel (?:right|challenging|achievable|free)/i,
      /sound (?:right|good|okay)/i,
      /too (?:conservative|ambitious|aggressive|easy)/i,
      /we could adjust/i,
      /want to (?:tweak|adjust|change|modify)/i,
      /anything (?:else|you'd like)/i,
      /thoughts on/i,
      /what do you think/i,
      /let me know/i,
      /when you think about/i,
      /how (?:does|do) (?:that|this) connect/i,
    ];
    
    const hasConversationalQuestion = questionPatterns.some(re => re.test(raw));
    
    // If the last paragraph has a question mark OR contains conversational question patterns, 
    // the AI is waiting for feedback
    if (hasQuestionInLastParagraph || hasConversationalQuestion) {
      return false;
    }

    return completionPatterns[fieldType].some((re) => re.test(raw));
  };

  const extractResultFromAIResponse = (step: WizardStep, aiResponse: string) => {
    let result: any = aiResponse;

    if (step.fieldType === "vision") {
      const visionMatch = aiResponse.match(
        /(?:your )?(?:90-day )?vision:\s*([\s\S]*?)(?=(?:\r?\n){1,2}(?:with that|now we|let's|now,|moving forward|this completes|that completes|we can now|shall we|ready to|how does|does this)|$)/i
      );
      if (visionMatch) result = sanitizeCapturedText(visionMatch[1].trim());
      result = stripTrailingFollowup(String(result));
    } else if (step.fieldType === "objective") {
      // Match various objective formats including "**Your Connection Objective:**"
      const objMatch = aiResponse.match(
        /\*\*(?:your )?(?:\w+ )?objective:\*\*\s*([\s\S]*?)(?=(?:\r?\n){2,}(?:how does|does this|with that|now we|let's|moving forward)|$)/i
      ) || aiResponse.match(
        /(?:your )?(?:\w+ )?objective:\s*([\s\S]*?)(?=(?:\r?\n){1,2}(?:with that|now we|let's|now,|moving forward|this completes|shall we|ready to|how does|does this)|$)/i
      );
      if (objMatch) result = sanitizeCapturedText(objMatch[1].trim());
    } else if (step.fieldType === "primary_tactic") {
      const tacticMatch = aiResponse.match(
        /(?:your )?(?:primary )?(?:daily )?tactic:\s*([\s\S]*?)(?=(?:\r?\n){1,2}(?:with that|now we|let's|now,|moving forward|this completes|shall we|ready to|how does|does this)|$)/i
      );
      if (tacticMatch) result = sanitizeCapturedText(tacticMatch[1].trim());
    } else if (step.fieldType === "secondary_tactics") {
      // First try JSON (legacy support)
      const codeBlockMatch = String(result).match(/```(?:json)?\s*([\s\S]*?)```/);
      const jsonString = codeBlockMatch ? codeBlockMatch[1].trim() : String(result);
      const jsonMatch = jsonString.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        try {
          result = JSON.parse(jsonMatch[0]);
          return result;
        } catch { /* fall through to plain text parsing */ }
      }
      
      // Parse numbered list format: "1. Tactic description"
      const tacticsMatch = aiResponse.match(/here are your (?:\w+\s+)?(?:supporting\s+)?tactics[:\s]*([\s\S]*?)(?=(?:\r?\n){2,}|$)/i);
      if (tacticsMatch) {
        const listText = tacticsMatch[1];
        const items = listText.match(/^\s*\d+\.\s*(.+)/gm);
        if (items) {
          result = items.map(item => item.replace(/^\s*\d+\.\s*/, '').trim());
        }
      }
    } else if (step.fieldType === "checkpoints") {
      // First try JSON (legacy support)
      const codeBlockMatch = String(result).match(/```(?:json)?\s*([\s\S]*?)```/);
      const jsonString = codeBlockMatch ? codeBlockMatch[1].trim() : String(result);
      const jsonMatch = jsonString.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        try {
          const parsed = JSON.parse(jsonMatch[0]);
          // Handle nested checkpoint objects (e.g., { day_30: { push_ups: "...", mile_time: "..." } })
          const flattenCheckpoint = (checkpoint: any): string => {
            if (typeof checkpoint === 'string') return checkpoint;
            if (typeof checkpoint === 'object' && checkpoint !== null) {
              // Convert nested object to bullet points
              return Object.entries(checkpoint)
                .map(([key, value]) => `• ${key.replace(/_/g, ' ')}: ${value}`)
                .join('\n');
            }
            return String(checkpoint);
          };
          
          result = {
            day_30: flattenCheckpoint(parsed.day_30),
            day_60: flattenCheckpoint(parsed.day_60)
          };
          return result;
        } catch { /* fall through to plain text parsing */ }
      }
      
      // Parse markdown format: **Day 30:** description
      const day30Match = aiResponse.match(/\*\*Day\s*30[:\*]*\*?\*?\s*:?\s*(.+?)(?=\*\*Day\s*60|\n\n|$)/is);
      const day60Match = aiResponse.match(/\*\*Day\s*60[:\*]*\*?\*?\s*:?\s*(.+?)(?=\n\n|$)/is);
      
      if (day30Match || day60Match) {
        result = {
          day_30: day30Match ? day30Match[1].trim() : "",
          day_60: day60Match ? day60Match[1].trim() : ""
        };
      }
    } else if (step.fieldType === "non_negotiables") {
      // Parse numbered list format for non-negotiables
      const nnMatch = aiResponse.match(/(?:here are your (?:daily )?non[- ]negotiables|your non[- ]negotiables)[:\s]*([\s\S]*?)(?=(?:\r?\n){2,}|$)/i);
      if (nnMatch) {
        const listText = nnMatch[1];
        const items = listText.match(/^\s*\d+\.\s*(.+)/gm);
        if (items) {
          result = items.map(item => item.replace(/^\s*\d+\.\s*/, '').trim());
        }
      } else {
        // Try to extract from numbered list anywhere in response
        const items = aiResponse.match(/^\s*\d+\.\s*.+/gm);
        if (items && items.length >= 4) {
          result = items.map(item => item.replace(/^\s*\d+\.\s*/, '').trim());
        }
      }
    }

    return result;
  };

  // Save progress to database - accepts optional overrides for immediate saves
  const saveProgressToDb = async (overrides?: {
    stepIndex?: number;
    data?: any;
    msgs?: Message[];
    quadrant?: string;
  }) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) {
        console.log("No session, falling back to localStorage");
        const stepToSave = overrides?.stepIndex ?? currentStepIndex;
        const dataToSave = overrides?.data ?? collectedData;
        const msgsToSave = overrides?.msgs ?? messages;
        const quadrantToSave = overrides?.quadrant ?? currentQuadrant;
        
        localStorage.setItem(STORAGE_KEY, JSON.stringify({
          currentStepIndex: stepToSave,
          collectedData: dataToSave,
          messages: msgsToSave,
          currentQuadrant: quadrantToSave,
          savedAt: new Date().toISOString()
        }));
        return;
      }

      const stepToSave = overrides?.stepIndex ?? currentStepIndex;
      const dataToSave = overrides?.data ?? collectedData;
      const msgsToSave = overrides?.msgs ?? messages;
      const quadrantToSave = overrides?.quadrant ?? currentQuadrant;

      console.log("Saving wizard progress to DB:", { stepToSave, dataKeys: Object.keys(dataToSave), quadrant: quadrantToSave });

      const progressData = {
        user_id: session.user.id,
        wizard_type: WIZARD_TYPE,
        current_step_index: stepToSave,
        collected_data: dataToSave as Json,
        messages: msgsToSave as unknown as Json,
        current_quadrant: quadrantToSave
      };

      const { error } = await supabase
        .from('wizard_progress')
        .upsert([progressData], { onConflict: 'user_id,wizard_type' });

      if (error) {
        console.error("Failed to save wizard progress:", error);
        // Fallback to localStorage
        localStorage.setItem(STORAGE_KEY, JSON.stringify({
          currentStepIndex: stepToSave,
          collectedData: dataToSave,
          messages: msgsToSave,
          currentQuadrant: quadrantToSave,
          savedAt: new Date().toISOString()
        }));
      } else {
        console.log("Wizard progress saved successfully");
        // Also update localStorage as backup
        localStorage.setItem(STORAGE_KEY, JSON.stringify({
          currentStepIndex: stepToSave,
          collectedData: dataToSave,
          messages: msgsToSave,
          currentQuadrant: quadrantToSave,
          savedAt: new Date().toISOString()
        }));
      }
    } catch (e) {
      console.error("Error saving wizard progress:", e);
    }
  };

  // Save progress whenever collected data changes - save immediately (critical for cross-device sync)
  useEffect(() => {
    if (open && !showResumePrompt && Object.keys(collectedData).length > 0) {
      // Save immediately when data changes (important for cross-device sync)
      console.log("Auto-saving due to collectedData change:", Object.keys(collectedData));
      saveProgressToDb();
    }
  }, [collectedData]); // Trigger on collected data changes

  // Also save when messages change (but debounce to avoid too frequent saves)
  useEffect(() => {
    if (open && !showResumePrompt && messages.length > 0) {
      const timeout = setTimeout(() => {
        saveProgressToDb();
      }, 300);
      return () => clearTimeout(timeout);
    }
  }, [messages]);

  // Save on step changes
  useEffect(() => {
    if (open && currentStepIndex > 0 && !showResumePrompt) {
      saveProgressToDb();
    }
  }, [currentStepIndex, currentQuadrant]);

  // Clear saved progress from database
  const clearSavedProgress = async () => {
    localStorage.removeItem(STORAGE_KEY);
    setSavedProgress(null);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        await supabase
          .from('wizard_progress')
          .delete()
          .eq('user_id', session.user.id)
          .eq('wizard_type', WIZARD_TYPE);
      }
    } catch (e) {
      console.error("Error clearing wizard progress:", e);
    }
  };

  // Load saved progress from database when wizard opens
  useEffect(() => {
    const loadProgress = async () => {
      if (!open) return;

      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (!session?.user) {
          console.log("No session found, starting fresh");
          startFresh();
          return;
        }

        console.log("Loading wizard progress for user:", session.user.id);

        // Try database first - force fresh fetch (no cache)
        const { data: dbProgress, error } = await supabase
          .from('wizard_progress')
          .select('*')
          .eq('user_id', session.user.id)
          .eq('wizard_type', WIZARD_TYPE)
          .maybeSingle();

        console.log("DB progress result:", { dbProgress, error });

        // Check if there's meaningful progress (either step > 0 or messages exist or collected data)
        const hasCollectedData = dbProgress?.collected_data && Object.keys(dbProgress.collected_data as object).length > 0;
        if (!error && dbProgress && (dbProgress.current_step_index > 0 || (dbProgress.messages as any[])?.length > 0 || hasCollectedData)) {
          console.log("Found saved progress:", { 
            stepIndex: dbProgress.current_step_index, 
            dataKeys: hasCollectedData ? Object.keys(dbProgress.collected_data as object) : [],
            messageCount: (dbProgress.messages as any[])?.length || 0
          });
          
          const progressData = {
            currentStepIndex: dbProgress.current_step_index,
            collectedData: dbProgress.collected_data,
            messages: dbProgress.messages,
            currentQuadrant: dbProgress.current_quadrant,
            savedAt: dbProgress.updated_at
          };
          
          // Always update the form with collected data when loading from database
          // This ensures cross-device sync works properly
          if (hasCollectedData) {
            console.log("Syncing collected data to form:", Object.keys(dbProgress.collected_data as object));
            onUpdate(dbProgress.collected_data);
          }
          
          setSavedProgress(progressData);
          setShowResumePrompt(true);
          return;
        }

        // Fallback to localStorage only if database has no progress
        const localSaved = localStorage.getItem(STORAGE_KEY);
        if (localSaved) {
          try {
            const parsed = JSON.parse(localSaved);
            const localHasData = parsed.collectedData && Object.keys(parsed.collectedData).length > 0;
            if (parsed.currentStepIndex > 0 || localHasData) {
              console.log("Loading from localStorage:", { 
                stepIndex: parsed.currentStepIndex, 
                dataKeys: localHasData ? Object.keys(parsed.collectedData) : [] 
              });
              
              // If the form is empty and we have collected data, auto-populate it
              if (localHasData) {
                onUpdate(parsed.collectedData);
              }
              
              setSavedProgress(parsed);
              setShowResumePrompt(true);
              return;
            }
          } catch (e) {
            console.error("Failed to parse local wizard progress:", e);
            localStorage.removeItem(STORAGE_KEY);
          }
        }

        // No saved progress - start fresh
        console.log("No saved progress found, starting fresh");
        startFresh();
      } catch (e) {
        console.error("Error loading wizard progress:", e);
        startFresh();
      }
    };

    loadProgress();
  }, [open]);

  // Convert existing form data to wizard's collected data format
  const convertFormDataToCollectedData = () => {
    if (!existingFormData) return {};
    
    const data: any = {};
    
    if (existingFormData.vision) data.vision = existingFormData.vision;
    
    const quadrants = ['calibration', 'connection', 'condition', 'contribution'] as const;
    quadrants.forEach(q => {
      const quadrantData = existingFormData[q];
      if (quadrantData) {
        if (quadrantData.objective) data[`${q}_objective`] = quadrantData.objective;
        if (quadrantData.primaryTactic) data[`${q}_primary_tactic`] = quadrantData.primaryTactic;
        if (quadrantData.secondaryTactic1 || quadrantData.secondaryTactic2 || quadrantData.secondaryTactic3) {
          data[`${q}_secondary_tactics`] = [
            quadrantData.secondaryTactic1,
            quadrantData.secondaryTactic2,
            quadrantData.secondaryTactic3
          ].filter(Boolean);
        }
        if (quadrantData.checkpoint30 || quadrantData.checkpoint60) {
          data[`${q}_checkpoints`] = {
            day_30: quadrantData.checkpoint30 || '',
            day_60: quadrantData.checkpoint60 || ''
          };
        }
      }
    });
    
    return data;
  };

  const startFresh = () => {
    setMessages([]);
    setInput("");
    
    // Check if there's existing form data to pre-populate
    const existingData = convertFormDataToCollectedData();
    const hasExistingData = Object.keys(existingData).length > 0;
    
    if (hasExistingData) {
      console.log("Found existing form data, pre-populating wizard:", Object.keys(existingData));
      setCollectedData(existingData);
      
      // Find the first incomplete step
      let firstIncompleteStep = 0;
      for (let i = 0; i < steps.length; i++) {
        const step = steps[i];
        let hasData = false;
        if (step.fieldType === "vision") {
          hasData = !!existingData.vision;
        } else if (step.quadrant) {
          const key = `${step.quadrant}_${step.fieldType === "objective" ? "objective" : step.fieldType === "primary_tactic" ? "primary_tactic" : step.fieldType === "secondary_tactics" ? "secondary_tactics" : "checkpoints"}`;
          hasData = !!existingData[key];
        }
        if (!hasData) {
          firstIncompleteStep = i;
          break;
        }
        if (i === steps.length - 1 && hasData) {
          firstIncompleteStep = steps.length; // All complete
        }
      }
      
      setCurrentStepIndex(firstIncompleteStep);
      setCurrentQuadrant(steps[firstIncompleteStep]?.quadrant || "");
      setIsMinimized(false);
      setShowResumePrompt(false);
      clearSavedProgress();
      
      toast.success(`Found ${Object.keys(existingData).length} existing fields. Starting at step ${firstIncompleteStep + 1}.`);
      startWizardStep(firstIncompleteStep, [], existingData);
    } else {
      setCurrentStepIndex(0);
      setCollectedData({});
      setCurrentQuadrant("");
      setIsMinimized(false);
      setShowResumePrompt(false);
      clearSavedProgress();
      startWizardStep(0, []);
    }
  };

  const resumeProgress = () => {
    if (savedProgress) {
      const restoredData = savedProgress.collectedData || {};
      const dataKeys = Object.keys(restoredData);
      
      console.log("Resuming progress:", { stepIndex: savedProgress.currentStepIndex, dataKeys });
      
      setMessages(savedProgress.messages || []);
      setCollectedData(restoredData);
      setCurrentQuadrant(savedProgress.currentQuadrant || "");
      setIsMinimized(false);
      setShowResumePrompt(false);
      
      // CRITICAL: Sync restored data to the form immediately
      if (dataKeys.length > 0) {
        console.log("Syncing restored data to form");
        onUpdate(restoredData);
        toast.success(`Restored ${dataKeys.length} saved fields to the form`);
      }
      
      // Find the correct step to resume at - check if current step's data already exists
      let resumeStepIndex = savedProgress.currentStepIndex || 0;
      
      // Check if the saved step's data already exists - if so, advance to the next incomplete step
      const checkStepDataExists = (stepIdx: number): boolean => {
        if (stepIdx >= steps.length) return false;
        const step = steps[stepIdx];
        if (step.fieldType === "vision") {
          return !!restoredData.vision;
        } else if (step.quadrant) {
          const key = `${step.quadrant}_${step.fieldType === "objective" ? "objective" : step.fieldType === "primary_tactic" ? "primary_tactic" : step.fieldType === "secondary_tactics" ? "secondary_tactics" : "checkpoints"}`;
          return !!restoredData[key];
        }
        return false;
      };
      
      // Advance past any steps that already have data
      while (resumeStepIndex < steps.length && checkStepDataExists(resumeStepIndex)) {
        console.log(`Step ${resumeStepIndex} (${steps[resumeStepIndex].label}) already has data, advancing...`);
        resumeStepIndex++;
      }
      
      console.log("Final resume step index:", resumeStepIndex);
      setCurrentStepIndex(resumeStepIndex);
      
      // Build a summary of what's been completed
      const completedSummary = buildCompletedSummary(restoredData);
      const currentStepLabel = steps[resumeStepIndex]?.label || "completion";
      
      // Add a resume message with context
      setMessages(prev => [...prev, {
        role: "assistant",
        content: `Welcome back! ${completedSummary}\n\nYou were working on: **${currentStepLabel}**. Let's continue where you left off.\n\n💡 *Tip: If I missed filling any form fields, just ask me "fill the form" or "populate the fields" and I'll update them with what we've discussed.*`
      }]);
      
      // Scroll to bottom after resume
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
      }, 100);
      
      // Continue from the correct step with the restored context
      startWizardStep(resumeStepIndex, [], restoredData);
    }
  };

  // Build a summary of completed fields for context
  const buildCompletedSummary = (data: any): string => {
    const completed: string[] = [];
    
    if (data.vision) completed.push("Vision");
    
    const quadrants = ["calibration", "connection", "condition", "contribution"];
    quadrants.forEach(q => {
      const quadrantName = q.charAt(0).toUpperCase() + q.slice(1);
      if (data[`${q}_objective`]) completed.push(`${quadrantName} Objective`);
      if (data[`${q}_primary_tactic`]) completed.push(`${quadrantName} Primary Tactic`);
      if (data[`${q}_secondary_tactics`]) completed.push(`${quadrantName} Secondary Tactics`);
      if (data[`${q}_checkpoints`]) completed.push(`${quadrantName} Checkpoints`);
    });
    
    if (completed.length === 0) {
      return "We're just getting started.";
    }
    
    return `So far we've completed: **${completed.join(", ")}**.`;
  };

  useEffect(() => {
    // Auto-scroll to bottom when new messages arrive (only if the user is already near the bottom)
    if (isAtBottomRef.current) {
      messagesEndRef.current?.scrollIntoView({ behavior: "auto" });
    }

    // Focus input after AI response (when loading finishes)
    if (!loading && open && !isMinimized) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  }, [messages, loading, open, isMinimized]);

  const startWizardStep = async (stepIndex: number, conversationHistory: any[], overrideData?: any) => {
    // Use overrideData if provided (for when called from handleContinueToNextStep with latest data)
    const dataToUse = overrideData || collectedData;
    
    if (stepIndex >= steps.length) {
      // Wizard complete - clear saved progress
      clearSavedProgress();
      
      setMessages(prev => [...prev, { 
        role: "assistant", 
        content: "🎉 Outstanding! Your complete battle plan is ready. I've filled in all the fields for you. Take a look and save when ready!" 
      }]);
      
      setTimeout(() => {
        onUpdate(dataToUse);
        toast.success("Battle plan wizard complete!");
        onOpenChange(false);
      }, 2000);
      return;
    }

    const step = steps[stepIndex];
    
    // Show quadrant transition message
    if (step.quadrant && step.quadrant !== currentQuadrant) {
      setCurrentQuadrant(step.quadrant);
      const quadrantNames = {
        calibration: "Calibration (Mind, Spirit & Emotion)",
        connection: "Connection (Relationships)",
        condition: "Condition (Physical Health)",
        contribution: "Contribution (Wealth & Value)"
      };
      setMessages(prev => [...prev, { 
        role: "assistant", 
        content: `\n---\n\n**Moving to ${quadrantNames[step.quadrant]}**\n\nLet's work through this quadrant together.\n\n---\n` 
      }]);
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    
    setLoading(true);

    const maxRetries = 3;
    let lastError: any = null;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        // Refresh the session to ensure we have a valid token
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();
        if (sessionError || !session) {
          toast.error("Your session has expired. Please log in again.");
          setLoading(false);
          return;
        }

        const stepContext: any = {
          ...context,
          vision: dataToUse.vision,
          // Pass all collected data for better AI context
          completedData: dataToUse,
        };

        if (step.quadrant) {
          stepContext.quadrant = step.quadrant;
          if (step.fieldType === "objective") {
            stepContext.vision = dataToUse.vision;
          } else if (step.fieldType === "primary_tactic") {
            stepContext.objective = dataToUse[`${step.quadrant}_objective`];
          } else if (step.fieldType === "secondary_tactics") {
            stepContext.objective = dataToUse[`${step.quadrant}_objective`];
            stepContext.primaryTactic = dataToUse[`${step.quadrant}_primary_tactic`];
          } else if (step.fieldType === "checkpoints") {
            stepContext.objective = dataToUse[`${step.quadrant}_objective`];
          }
        }

        // For non-negotiables, pass all primary tactics from each quadrant
        if (step.fieldType === "non_negotiables") {
          stepContext.calibrationTactic = dataToUse.calibration_primary_tactic;
          stepContext.connectionTactic = dataToUse.connection_primary_tactic;
          stepContext.conditionTactic = dataToUse.condition_primary_tactic;
          stepContext.contributionTactic = dataToUse.contribution_primary_tactic;
        }

        const { data, error } = await supabase.functions.invoke('battle-plan-ai', {
          body: { 
            type: step.fieldType,
            context: stepContext,
            tone,
            conversationMode: true,
            conversationHistory,
            wizardMode: true,
            currentStep: step.label,
            isResuming: conversationHistory.length > 0
          }
        });

        if (error) throw error;

        if (data?.suggestion) {
          setMessages(prev => [...prev, { role: "assistant", content: data.suggestion }]);
        }
        
        // Success - exit retry loop
        setLoading(false);
        return;
      } catch (error: any) {
        console.error(`Error in wizard step (attempt ${attempt}/${maxRetries}):`, error);
        lastError = error;
        
        // Check if it's a network/fetch error that might be recoverable
        const isNetworkError = error?.name === 'FunctionsFetchError' || 
                               error?.message?.includes('Load failed') ||
                               error?.message?.includes('network') ||
                               error?.message?.includes('fetch');
        
        if (isNetworkError && attempt < maxRetries) {
          // Wait before retrying (exponential backoff)
          await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
          continue;
        }
        
        // Non-recoverable error or max retries reached
        break;
      }
    }

    // All retries failed
    console.error("All wizard step attempts failed:", lastError);
    toast.error("Connection issue. Please check your network and try again.");
    setLoading(false);
  };

  const sendMessage = async () => {
    if (!input.trim()) return;

    const userMessage = input.trim();
    setInput("");
    
    // Check if user is asking to fill the form
    const fillFormPatterns = /\b(fill|populate|update|sync|apply|put in|add to)\b.*(form|field|fields|input|inputs)\b/i;
    if (fillFormPatterns.test(userMessage) && Object.keys(collectedData).length > 0) {
      onUpdate(collectedData);
      setMessages(prev => [...prev, 
        { role: "user", content: userMessage },
        { role: "assistant", content: "Done! I've updated the form with all the data we've collected so far. Check the form fields - they should now reflect what we've discussed." }
      ]);
      toast.success("Form fields updated with collected data");
      return;
    }
    
    const updatedMessages: Message[] = [...messages, { role: "user", content: userMessage }];
    setMessages(updatedMessages);
    setLoading(true);

    const maxRetries = 3;
    let lastError: any = null;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        // Refresh the session to ensure we have a valid token
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();
        if (sessionError || !session) {
          toast.error("Your session has expired. Please log in again.");
          setLoading(false);
          return;
        }

        const step = steps[currentStepIndex];
        const conversationHistory = updatedMessages.map(msg => ({
          role: msg.role,
          content: msg.content
        }));

        const stepContext: any = {
          ...context,
          vision: collectedData.vision,
          // Pass all collected data for better AI context
          completedData: collectedData,
        };

        if (step.quadrant) {
          stepContext.quadrant = step.quadrant;
          if (step.fieldType === "objective") {
            stepContext.vision = collectedData.vision;
          } else if (step.fieldType === "primary_tactic") {
            stepContext.objective = collectedData[`${step.quadrant}_objective`];
          } else if (step.fieldType === "secondary_tactics") {
            stepContext.objective = collectedData[`${step.quadrant}_objective`];
            stepContext.primaryTactic = collectedData[`${step.quadrant}_primary_tactic`];
          } else if (step.fieldType === "checkpoints") {
            stepContext.objective = collectedData[`${step.quadrant}_objective`];
          }
        }

        // For non-negotiables, pass all primary tactics
        if (step.fieldType === "non_negotiables") {
          stepContext.calibrationTactic = collectedData.calibration_primary_tactic;
          stepContext.connectionTactic = collectedData.connection_primary_tactic;
          stepContext.conditionTactic = collectedData.condition_primary_tactic;
          stepContext.contributionTactic = collectedData.contribution_primary_tactic;
        }

        const { data, error } = await supabase.functions.invoke('battle-plan-ai', {
          body: { 
            type: step.fieldType,
            context: stepContext,
            tone,
            conversationMode: true,
            userInput: userMessage,
            conversationHistory,
            wizardMode: true
          }
        });

        if (error) throw error;

        if (data?.suggestion) {
          const aiResponse = data.suggestion;
          setMessages(prev => [...prev, { role: "assistant", content: aiResponse }]);
          
          // Check if this is a final answer
          const isFinalAnswer = isStepCompleteFromText(step.fieldType, aiResponse);

          if (isFinalAnswer) {
            // Extract and save the result
            const result = extractResultFromAIResponse(step, aiResponse);

            // Save to collected data
            const newData = { ...collectedData };
            if (step.fieldType === "vision") {
              newData.vision = result;
            } else if (step.fieldType === "non_negotiables") {
              newData.non_negotiables = result;
            } else if (step.quadrant) {
              const key = `${step.quadrant}_${
                step.fieldType === "objective"
                  ? "objective"
                  : step.fieldType === "primary_tactic"
                    ? "primary_tactic"
                    : step.fieldType === "secondary_tactics"
                      ? "secondary_tactics"
                      : "checkpoints"
              }`;
              newData[key] = result;
            }
            setCollectedData(newData);

            // Immediately update the form with collected data so far
            onUpdate(newData);

            // If we're editing a step, handle differently
            if (editingStepIndex !== null) {
              const allMessages: Message[] = [...updatedMessages, { role: "assistant", content: aiResponse }];
              
              // Find the next incomplete step to return to
              const highestCompleted = steps.findIndex((s, i) => {
                if (s.fieldType === "vision") return !newData.vision;
                if (s.quadrant) {
                  const key = `${s.quadrant}_${s.fieldType}`;
                  return !newData[key];
                }
                return true;
              });
              
              const nextStepIndex = highestCompleted === -1 ? steps.length : highestCompleted;
              
              await saveProgressToDb({
                stepIndex: nextStepIndex,
                data: newData,
                msgs: allMessages,
                quadrant: step.quadrant || currentQuadrant,
              });

              toast.success(`${step.label} updated!`);
              setEditingStepIndex(null);
              
              // Show confirmation and option to continue
              setMessages(prev => [...prev, { 
                role: "assistant", 
                content: `✅ **${step.label}** has been updated! Click another completed step to edit it, or "Continue to Next Step" to proceed.` 
              }]);
              
              // Set up pending advance to continue from where we left off
              setPendingAdvance({ nextIndex: nextStepIndex, data: newData });
              setCurrentStepIndex(nextStepIndex);
            } else {
              // Normal flow - not editing
              // Save progress before moving to next step (ensure we include the user's message too)
              const nextIndex = currentStepIndex + 1;
              const allMessages: Message[] = [...updatedMessages, { role: "assistant", content: aiResponse }];
              await saveProgressToDb({
                stepIndex: nextIndex,
                data: newData,
                msgs: allMessages,
                quadrant: step.quadrant || currentQuadrant,
              });

              toast.success(`${step.label} saved!`);

              // Set pending advance - wait for user confirmation before moving to next step
              setPendingAdvance({ nextIndex, data: newData });
              setMessages(prev => [...prev, { 
                role: "assistant", 
                content: `✅ **${step.label}** has been saved. Click "Continue to Next Step" when you're ready to proceed.` 
              }]);
            }
          }
        }
        
        // Success - exit retry loop
        setLoading(false);
        return;
      } catch (error: any) {
        console.error(`Error sending message (attempt ${attempt}/${maxRetries}):`, error);
        lastError = error;
        
        // Check if it's a network/fetch error that might be recoverable
        const isNetworkError = error?.name === 'FunctionsFetchError' || 
                               error?.message?.includes('Load failed') ||
                               error?.message?.includes('network') ||
                               error?.message?.includes('fetch');
        
        if (isNetworkError && attempt < maxRetries) {
          // Wait before retrying (exponential backoff)
          await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
          continue;
        }
        
        // Non-recoverable error or max retries reached
        break;
      }
    }

    // All retries failed
    console.error("All message attempts failed:", lastError);
    toast.error("Connection issue. Please check your network and try again.");
    setLoading(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleContinueToNextStep = () => {
    if (!pendingAdvance) return;
    const { nextIndex, data } = pendingAdvance;
    setPendingAdvance(null);
    setEditingStepIndex(null);
    setCurrentStepIndex(nextIndex);
    startWizardStep(nextIndex, [], data);
  };

  // Jump back to edit a completed step
  const handleEditStep = (stepIndex: number) => {
    const step = steps[stepIndex];
    setEditingStepIndex(stepIndex);
    setCurrentStepIndex(stepIndex);
    setPendingAdvance(null);
    
    // Get the current value for this step
    let currentValue = "";
    if (step.fieldType === "vision") {
      currentValue = collectedData.vision || "";
    } else if (step.quadrant) {
      const key = `${step.quadrant}_${step.fieldType}`;
      const val = collectedData[key];
      if (Array.isArray(val)) {
        currentValue = val.join(", ");
      } else if (typeof val === "object" && val !== null) {
        currentValue = `Day 30: ${val.day_30 || val.day30 || ""}, Day 60: ${val.day_60 || val.day60 || ""}`;
      } else {
        currentValue = val || "";
      }
    }
    
    // Add an edit context message
    setMessages(prev => [...prev, {
      role: "assistant",
      content: `📝 **Editing: ${step.label}**\n\nCurrent value:\n"${currentValue}"\n\nTell me how you'd like to change this, or provide a new value directly.`
    }]);
    
    // Scroll to bottom
    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  };

  // Handle saving an edited step
  const handleSaveEdit = (stepIndex: number, newValue: any) => {
    const step = steps[stepIndex];
    const newData = { ...collectedData };
    
    if (step.fieldType === "vision") {
      newData.vision = newValue;
    } else if (step.quadrant) {
      const key = `${step.quadrant}_${step.fieldType}`;
      newData[key] = newValue;
    }
    
    setCollectedData(newData);
    onUpdate(newData);
    setEditingStepIndex(null);
    
    // Return to the highest completed step + 1, or stay at current if editing the last completed
    const highestCompleted = steps.findIndex((s, i) => {
      if (s.fieldType === "vision") return !newData.vision;
      if (s.quadrant) {
        const key = `${s.quadrant}_${s.fieldType}`;
        return !newData[key];
      }
      return true;
    });
    
    const nextStepIndex = highestCompleted === -1 ? steps.length : highestCompleted;
    setCurrentStepIndex(nextStepIndex);
    
    toast.success(`${step.label} updated!`);
    
    // Save progress
    saveProgressToDb({
      stepIndex: nextStepIndex,
      data: newData,
      msgs: messages,
      quadrant: step.quadrant || currentQuadrant,
    });
  };
  // Minimized floating button for mobile
  if (open && isMinimized) {
    return (
      <Button
        onClick={() => setIsMinimized(false)}
        className="fixed bottom-20 right-4 z-50 h-14 w-14 rounded-full shadow-lg animate-scale-in sm:hidden"
        size="icon"
      >
        <div className="relative">
          <Sparkles className="h-6 w-6" />
          <span className="absolute -top-1 -right-1 h-4 w-4 bg-primary-foreground text-primary text-[10px] font-bold rounded-full flex items-center justify-center">
            {Math.round(progress)}
          </span>
        </div>
      </Button>
    );
  }

  return (
    <Dialog open={open && !isMinimized} onOpenChange={onOpenChange}>
      <DialogContent className="w-[95vw] max-w-3xl max-h-[85vh] sm:max-h-[700px] flex flex-col p-4 sm:p-6">
        <DialogHeader className="space-y-1 sm:space-y-2 flex-shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
              <DialogTitle className="text-base sm:text-lg">Battle Plan Wizard</DialogTitle>
            </div>
            <div className="flex items-center gap-1">
              {!showResumePrompt && currentStepIndex > 0 && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => {
                    if (confirm("Reset wizard and start over? All progress will be lost.")) {
                      startFresh();
                    }
                  }}
                  title="Reset wizard"
                >
                  <RotateCcw className="h-4 w-4" />
                </Button>
              )}
              <Button
                variant="ghost"
                size="icon"
                className="sm:hidden h-8 w-8"
                onClick={() => setIsMinimized(true)}
              >
                <Minimize2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <DialogDescription className="text-xs sm:text-sm flex items-center gap-2 flex-wrap">
            <span>Let's build your 12-week battle plan step by step</span>
            <span className="inline-flex items-center gap-1 text-[10px] sm:text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">
              <BookOpen className="h-3 w-3" />
              <span className="hidden sm:inline">AAR insights connected</span>
              <span className="sm:hidden">AAR</span>
            </span>
          </DialogDescription>
        </DialogHeader>

        {/* Resume Prompt */}
        {showResumePrompt && savedProgress && (
          <div className="bg-muted/50 border rounded-lg p-4 space-y-3">
            <div className="text-sm">
              <p className="font-medium">Resume your progress?</p>
              <p className="text-muted-foreground text-xs mt-1">
                You were on step {savedProgress.currentStepIndex + 1} of {steps.length} ({steps[savedProgress.currentStepIndex]?.label})
                {savedProgress.savedAt && (
                  <span> • Saved {new Date(savedProgress.savedAt).toLocaleDateString()}</span>
                )}
              </p>
            </div>
            <div className="flex gap-2">
              <Button onClick={resumeProgress} size="sm" className="gap-1.5">
                <Play className="h-3.5 w-3.5" />
                Resume
              </Button>
              <Button onClick={startFresh} variant="outline" size="sm" className="gap-1.5">
                <RotateCcw className="h-3.5 w-3.5" />
                Start Fresh
              </Button>
            </div>
          </div>
        )}

        {!showResumePrompt && (
          <>

        {/* Progress Bar */}
        <div className="space-y-1 sm:space-y-2 flex-shrink-0">
          <div className="flex items-center justify-between text-xs sm:text-sm">
            <span className="text-muted-foreground truncate pr-2">
              {editingStepIndex !== null ? (
                <>Editing: {steps[editingStepIndex]?.label}</>
              ) : isWizardComplete ? (
                <>✅ Battle Plan Complete!</>
              ) : (
                <>Step {currentStepIndex + 1}/{steps.length}: {steps[currentStepIndex]?.label}</>
              )}
            </span>
            <span className="font-medium flex-shrink-0">{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-1.5 sm:h-2" />
          
          {/* Status Indicator */}
          {!loading && messages.length > 0 && messages[messages.length - 1]?.role === 'assistant' && (
            <div className="flex items-center gap-1.5 mt-1">
              {editingStepIndex !== null ? (
                <div className="flex items-center gap-1.5 text-xs text-blue-600 bg-blue-500/10 px-2 py-1 rounded-full">
                  <Pencil className="h-3 w-3" />
                  <span>Editing mode • Make your changes</span>
                </div>
              ) : pendingAdvance ? (
                <div className="flex items-center gap-1.5 text-xs text-green-600 bg-green-500/10 px-2 py-1 rounded-full">
                  <CheckCircle2 className="h-3 w-3" />
                  <span>Step saved • Ready to continue</span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 text-xs text-amber-600 bg-amber-500/10 px-2 py-1 rounded-full">
                  <MessageCircle className="h-3 w-3" />
                  <span>Awaiting your feedback</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Completed Steps - Scrollable on mobile, clickable to edit */}
        {(() => {
          // Calculate which steps are actually completed (have data)
          const completedStepIndices = steps.map((step, idx) => {
            if (step.fieldType === "vision") return collectedData.vision ? idx : -1;
            if (step.quadrant) {
              const key = `${step.quadrant}_${step.fieldType}`;
              return collectedData[key] ? idx : -1;
            }
            return -1;
          }).filter(idx => idx !== -1);
          
          if (completedStepIndices.length === 0) return null;
          
          return (
            <div className="flex overflow-x-auto gap-1.5 sm:gap-2 pb-2 border-b scrollbar-hide flex-shrink-0">
              {completedStepIndices.map((stepIdx) => {
                const step = steps[stepIdx];
                return (
                  <button
                    key={step.id}
                    onClick={() => handleEditStep(stepIdx)}
                    className={`flex items-center gap-1 text-[10px] sm:text-xs px-1.5 sm:px-2 py-0.5 sm:py-1 rounded-md whitespace-nowrap flex-shrink-0 transition-colors group ${
                      editingStepIndex === stepIdx 
                        ? "bg-primary/20 text-primary ring-1 ring-primary/30" 
                        : "bg-green-500/10 text-green-600 hover:bg-green-500/20"
                    }`}
                    title={`Click to edit ${step.label}`}
                  >
                    {editingStepIndex === stepIdx ? (
                      <Pencil className="h-2.5 w-2.5 sm:h-3 sm:w-3" />
                    ) : (
                      <>
                        <CheckCircle2 className="h-2.5 w-2.5 sm:h-3 sm:w-3 group-hover:hidden" />
                        <Pencil className="h-2.5 w-2.5 sm:h-3 sm:w-3 hidden group-hover:block" />
                      </>
                    )}
                    <span className="hidden sm:inline">{step.label}</span>
                    <span className="sm:hidden">{step.label.split(' ').slice(-1)[0]}</span>
                  </button>
                );
              })}
            </div>
          );
        })()}

        <div
          ref={scrollContainerRef}
          onScroll={handleChatScroll}
          className="flex-1 min-h-0 overflow-y-auto overscroll-contain pr-2 sm:pr-4 -mr-2 sm:-mr-4"
        >
          <div className="space-y-3 sm:space-y-4 pb-4">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[90%] sm:max-w-[85%] rounded-lg px-3 sm:px-4 py-2 sm:py-3 ${
                    message.role === "user"
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted"
                  }`}
                >
                  <p className="text-xs sm:text-sm whitespace-pre-wrap">{message.content}</p>
                </div>
              </div>
            ))}
            
            {loading && (
              <div className="flex justify-start">
                <div className="bg-muted rounded-lg px-3 sm:px-4 py-2 sm:py-3">
                  <Loader2 className="h-4 w-4 animate-spin" />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </div>

        <div className="pt-3 sm:pt-4 border-t flex-shrink-0 space-y-2">
          {editingStepIndex !== null && !pendingAdvance && (
            <Button 
              onClick={() => {
                // Cancel editing and return to the furthest incomplete step
                setEditingStepIndex(null);
                const highestCompleted = steps.findIndex((s) => {
                  if (s.fieldType === "vision") return !collectedData.vision;
                  if (s.quadrant) {
                    const key = `${s.quadrant}_${s.fieldType}`;
                    return !collectedData[key];
                  }
                  return true;
                });
                const nextStepIndex = highestCompleted === -1 ? steps.length : highestCompleted;
                setCurrentStepIndex(nextStepIndex);
                setMessages(prev => [...prev, {
                  role: "assistant",
                  content: `Edit cancelled. Returning to ${steps[nextStepIndex]?.label || "the next step"}.`
                }]);
              }}
              variant="outline"
              className="w-full gap-2"
              size="default"
            >
              <RotateCcw className="h-4 w-4" />
              Cancel Edit
            </Button>
          )}
          {pendingAdvance && (
            <Button 
              onClick={handleContinueToNextStep} 
              className="w-full gap-2"
              size="default"
            >
              <ArrowRight className="h-4 w-4" />
              Continue to Next Step
            </Button>
          )}
          <div className="flex gap-2">
            <Input
              ref={inputRef}
              placeholder={
                editingStepIndex !== null 
                  ? "Describe how to change this step..." 
                  : pendingAdvance 
                    ? "Or ask a follow-up question..." 
                    : "Type your response..."
              }
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              disabled={loading}
              className="text-sm sm:text-base"
            />
            <Button onClick={sendMessage} disabled={loading || !input.trim()} size="default" className="px-3 sm:px-4">
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
        </>
        )}
      </DialogContent>
    </Dialog>
  );
};
