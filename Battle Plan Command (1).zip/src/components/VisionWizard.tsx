import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import { 
  ArrowLeft, ArrowRight, Sparkles, Loader2, Check, X, 
  Heart, Brain, Compass, Users, Briefcase, Wallet, Mountain, 
  Activity, Scale, Target, HelpCircle, Send
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface Message {
  role: "assistant" | "user";
  content: string;
}

interface LifeCategory {
  target1: string;
  target2: string;
  target3: string;
}

interface WizardData {
  yearly_theme: string;
  life_categories: Record<string, LifeCategory>;
  body_metrics: Record<string, string>;
  financial_metrics: Record<string, string>;
  bucket_list: string[];
  accountability_needs: string;
  help_needed: string;
}

interface VisionWizardProps {
  initialData: WizardData;
  teamId: string | null;
  onComplete: (data: WizardData) => void;
  onCancel: () => void;
}

const STEPS = [
  { id: "yearly_theme", title: "Theme for the Year", type: "ai" as const },
  { id: "life_categories", title: "Life Categories", type: "hybrid" as const },
  { id: "body_metrics", title: "Body & Health Goals", type: "form" as const },
  { id: "financial_metrics", title: "Financial Goals", type: "form" as const },
  { id: "bucket_list", title: "Bucket List Adventures", type: "ai" as const },
  { id: "accountability", title: "Accountability & Help", type: "ai" as const },
];

const LIFE_CATEGORIES = [
  { id: "health", label: "Health & Nutrition", icon: Heart, color: "text-red-400" },
  { id: "spiritual", label: "Spiritual & Growth", icon: Sparkles, color: "text-purple-400" },
  { id: "adventure", label: "Lifestyle & Adventure", icon: Compass, color: "text-orange-400" },
  { id: "personal_growth", label: "Personal Development", icon: Brain, color: "text-blue-400" },
  { id: "career", label: "Business & Career", icon: Briefcase, color: "text-green-400" },
  { id: "relationships", label: "Family & Relationships", icon: Users, color: "text-pink-400" },
  { id: "financial", label: "Financial & Investment", icon: Wallet, color: "text-yellow-400" },
  { id: "community", label: "Community & Tribe", icon: Mountain, color: "text-cyan-400" },
];

const BODY_METRICS = [
  { id: "weight", label: "Weight Goal", placeholder: "e.g., 180 lbs" },
  { id: "body_fat", label: "Body Fat % Goal", placeholder: "e.g., 15%" },
  { id: "blood_pressure", label: "Blood Pressure Goal", placeholder: "e.g., 120/80" },
  { id: "fitness_score", label: "Fitness Score Goal", placeholder: "e.g., Run 5k in 25 min" },
];

const FINANCIAL_METRICS = [
  { id: "net_worth_goal", label: "Net Worth Goal", placeholder: "e.g., $500,000" },
  { id: "income_goal", label: "Annual Income Goal", placeholder: "e.g., $150,000" },
  { id: "savings_rate", label: "Savings Rate Goal (%)", placeholder: "e.g., 30%" },
  { id: "debt_payoff", label: "Debt Payoff Goal", placeholder: "e.g., $0 debt" },
];

export function VisionWizard({ initialData, teamId, onComplete, onCancel }: VisionWizardProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [data, setData] = useState<WizardData>(initialData);
  
  // AI chat state
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [conversationHistory, setConversationHistory] = useState<any[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const step = STEPS[currentStep];
  const progress = ((currentStep + 1) / STEPS.length) * 100;

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Start AI conversation when entering AI step
  useEffect(() => {
    if (step.type === "ai" || step.type === "hybrid") {
      setMessages([]);
      setConversationHistory([]);
      startAIConversation();
    }
  }, [currentStep]);

  // Focus input after AI response
  useEffect(() => {
    if (!aiLoading && (step.type === "ai" || step.type === "hybrid")) {
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [aiLoading, step.type]);

  const startAIConversation = async () => {
    setAiLoading(true);
    try {
      const section = step.id === "accountability" ? "accountability" : step.id;
      const { data: response, error } = await supabase.functions.invoke("vision-wizard-ai", {
        body: { section, conversationHistory: [], userInput: "", currentData: data },
      });

      if (error) throw error;
      setMessages([{ role: "assistant", content: response.suggestion }]);
    } catch (error) {
      console.error("Error starting AI conversation:", error);
      toast.error("Failed to start AI conversation");
    } finally {
      setAiLoading(false);
    }
  };

  const sendMessage = async () => {
    if (!input.trim() || aiLoading) return;

    const userMessage = input.trim();
    setInput("");
    
    const newMessages = [...messages, { role: "user" as const, content: userMessage }];
    setMessages(newMessages);
    
    const newHistory = [
      ...conversationHistory,
      { role: "assistant", content: messages[messages.length - 1]?.content || "" },
      { role: "user", content: userMessage },
    ];
    setConversationHistory(newHistory);

    setAiLoading(true);
    try {
      const section = step.id === "accountability" ? "accountability" : step.id;
      const { data: response, error } = await supabase.functions.invoke("vision-wizard-ai", {
        body: { section, conversationHistory: newHistory, userInput: userMessage, currentData: data },
      });

      if (error) throw error;
      setMessages([...newMessages, { role: "assistant", content: response.suggestion }]);

      // Extract data from conversation based on step
      extractDataFromConversation(userMessage, response.suggestion);
    } catch (error) {
      console.error("Error in AI conversation:", error);
      toast.error("Failed to get AI response");
    } finally {
      setAiLoading(false);
    }
  };

  const extractDataFromConversation = (userMessage: string, aiResponse: string) => {
    if (step.id === "yearly_theme") {
      // If user provides a short theme-like response, use it
      if (userMessage.split(" ").length <= 5) {
        setData(prev => ({ ...prev, yearly_theme: userMessage }));
      }
    } else if (step.id === "bucket_list") {
      // Add mentioned adventures to bucket list
      const currentList = data.bucket_list.filter(Boolean);
      if (currentList.length < 5 && userMessage.length > 10) {
        // Simple extraction - user's input might contain an adventure
        const newList = [...currentList];
        if (!currentList.includes(userMessage) && newList.length < 5) {
          newList.push(userMessage);
          setData(prev => ({ ...prev, bucket_list: newList }));
        }
      }
    } else if (step.id === "accountability") {
      // Capture accountability needs
      if (userMessage.length > 20) {
        setData(prev => ({
          ...prev,
          accountability_needs: prev.accountability_needs 
            ? `${prev.accountability_needs}\n${userMessage}` 
            : userMessage
        }));
      }
    }
  };

  const updateLifeCategory = (categoryId: string, field: keyof LifeCategory, value: string) => {
    setData(prev => ({
      ...prev,
      life_categories: {
        ...prev.life_categories,
        [categoryId]: {
          ...(prev.life_categories[categoryId] || { target1: "", target2: "", target3: "" }),
          [field]: value,
        },
      },
    }));
  };

  const handleNext = () => {
    if (currentStep < STEPS.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete(data);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const renderAIChat = () => (
    <div className="flex flex-col h-[400px]">
      <ScrollArea className="flex-1 pr-4">
        <div className="space-y-4">
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[85%] rounded-lg px-4 py-2 text-sm ${
                  msg.role === "user"
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-foreground"
                }`}
              >
                {msg.content}
              </div>
            </div>
          ))}
          {aiLoading && (
            <div className="flex justify-start">
              <div className="bg-muted rounded-lg px-4 py-2">
                <Loader2 className="w-4 h-4 animate-spin" />
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>

      <div className="flex gap-2 pt-4 border-t mt-4">
        <Input
          ref={inputRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && sendMessage()}
          placeholder="Share your thoughts..."
          disabled={aiLoading}
        />
        <Button onClick={sendMessage} disabled={aiLoading || !input.trim()} size="icon">
          <Send className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );

  const renderFormStep = () => {
    if (step.id === "body_metrics") {
      return (
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-4">
            <Activity className="h-5 w-5 text-red-400" />
            <p className="text-sm text-muted-foreground">Set specific, measurable health goals</p>
          </div>
          {BODY_METRICS.map((metric) => (
            <div key={metric.id} className="space-y-1">
              <Label>{metric.label}</Label>
              <Input
                placeholder={metric.placeholder}
                value={data.body_metrics[metric.id] || ""}
                onChange={(e) => setData(prev => ({
                  ...prev,
                  body_metrics: { ...prev.body_metrics, [metric.id]: e.target.value }
                }))}
              />
            </div>
          ))}
        </div>
      );
    }

    if (step.id === "financial_metrics") {
      return (
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-4">
            <Scale className="h-5 w-5 text-green-400" />
            <p className="text-sm text-muted-foreground">Define your financial targets</p>
          </div>
          {FINANCIAL_METRICS.map((metric) => (
            <div key={metric.id} className="space-y-1">
              <Label>{metric.label}</Label>
              <Input
                placeholder={metric.placeholder}
                value={data.financial_metrics[metric.id] || ""}
                onChange={(e) => setData(prev => ({
                  ...prev,
                  financial_metrics: { ...prev.financial_metrics, [metric.id]: e.target.value }
                }))}
              />
            </div>
          ))}
        </div>
      );
    }

    return null;
  };

  const renderHybridStep = () => {
    if (step.id === "life_categories") {
      return (
        <div className="space-y-4">
          {/* AI Chat section */}
          <div className="border rounded-lg p-4 bg-muted/20">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium">AI Guide</span>
            </div>
            <div className="h-[200px]">
              <ScrollArea className="h-full pr-2">
                <div className="space-y-2">
                  {messages.map((msg, idx) => (
                    <div
                      key={idx}
                      className={`text-sm ${msg.role === "user" ? "text-right" : ""}`}
                    >
                      <span className={msg.role === "user" ? "bg-primary text-primary-foreground px-2 py-1 rounded" : ""}>
                        {msg.content}
                      </span>
                    </div>
                  ))}
                  {aiLoading && <Loader2 className="w-3 h-3 animate-spin" />}
                </div>
              </ScrollArea>
              <div className="flex gap-2 mt-2">
                <Input
                  ref={inputRef}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && sendMessage()}
                  placeholder="Type here..."
                  className="text-sm h-8"
                  disabled={aiLoading}
                />
                <Button onClick={sendMessage} size="sm" disabled={aiLoading}>
                  <Send className="w-3 h-3" />
                </Button>
              </div>
            </div>
          </div>

          {/* Categories form */}
          <div className="grid gap-3 sm:grid-cols-2 max-h-[300px] overflow-y-auto pr-2">
            {LIFE_CATEGORIES.map((category) => {
              const Icon = category.icon;
              const categoryData = data.life_categories[category.id] || { target1: "", target2: "", target3: "" };

              return (
                <Card key={category.id} className="bg-background/50">
                  <CardHeader className="pb-2 pt-3 px-3">
                    <CardTitle className="text-xs flex items-center gap-2">
                      <Icon className={`h-3 w-3 ${category.color}`} />
                      {category.label}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="px-3 pb-3 space-y-1.5">
                    <Input
                      placeholder="Target 1..."
                      value={categoryData.target1}
                      onChange={(e) => updateLifeCategory(category.id, "target1", e.target.value)}
                      className="text-xs h-7"
                    />
                    <Input
                      placeholder="Target 2..."
                      value={categoryData.target2}
                      onChange={(e) => updateLifeCategory(category.id, "target2", e.target.value)}
                      className="text-xs h-7"
                    />
                    <Input
                      placeholder="Target 3..."
                      value={categoryData.target3}
                      onChange={(e) => updateLifeCategory(category.id, "target3", e.target.value)}
                      className="text-xs h-7"
                    />
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      );
    }

    return null;
  };

  const renderCurrentData = () => {
    if (step.id === "yearly_theme" && data.yearly_theme) {
      return (
        <div className="bg-primary/10 rounded-lg p-3 mb-4">
          <Label className="text-xs text-muted-foreground">Current Theme</Label>
          <Input
            value={data.yearly_theme}
            onChange={(e) => setData(prev => ({ ...prev, yearly_theme: e.target.value }))}
            className="mt-1"
          />
        </div>
      );
    }

    if (step.id === "bucket_list" && data.bucket_list.some(Boolean)) {
      return (
        <div className="bg-primary/10 rounded-lg p-3 mb-4">
          <Label className="text-xs text-muted-foreground mb-2 block">Your Bucket List</Label>
          {data.bucket_list.slice(0, 5).map((item, idx) => (
            <Input
              key={idx}
              value={item}
              onChange={(e) => {
                const updated = [...data.bucket_list];
                updated[idx] = e.target.value;
                setData(prev => ({ ...prev, bucket_list: updated }));
              }}
              placeholder={`Adventure ${idx + 1}...`}
              className="mt-1 text-sm"
            />
          ))}
        </div>
      );
    }

    if (step.id === "accountability") {
      return (
        <div className="bg-primary/10 rounded-lg p-3 mb-4 space-y-3">
          <div>
            <Label className="text-xs text-muted-foreground">Accountability Needs</Label>
            <Textarea
              value={data.accountability_needs}
              onChange={(e) => setData(prev => ({ ...prev, accountability_needs: e.target.value }))}
              className="mt-1 min-h-[60px]"
              placeholder="What do you want to be held accountable for?"
            />
          </div>
          <div>
            <Label className="text-xs text-muted-foreground">Help Needed</Label>
            <Textarea
              value={data.help_needed}
              onChange={(e) => setData(prev => ({ ...prev, help_needed: e.target.value }))}
              className="mt-1 min-h-[60px]"
              placeholder="What do you need help with?"
            />
          </div>
        </div>
      );
    }

    return null;
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <div className="flex items-center justify-between mb-2">
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5 text-primary" />
            Vision Wizard
          </CardTitle>
          <Button variant="ghost" size="icon" onClick={onCancel}>
            <X className="h-4 w-4" />
          </Button>
        </div>
        <CardDescription>
          Step {currentStep + 1} of {STEPS.length}: {step.title}
        </CardDescription>
        <Progress value={progress} className="h-2" />
      </CardHeader>

      <CardContent className="space-y-4">
        {renderCurrentData()}
        
        {step.type === "ai" && renderAIChat()}
        {step.type === "form" && renderFormStep()}
        {step.type === "hybrid" && renderHybridStep()}

        <div className="flex justify-between pt-4 border-t">
          <Button
            variant="outline"
            onClick={handleBack}
            disabled={currentStep === 0}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <Button onClick={handleNext}>
            {currentStep === STEPS.length - 1 ? (
              <>
                <Check className="w-4 h-4 mr-2" />
                Complete
              </>
            ) : (
              <>
                Next
                <ArrowRight className="w-4 h-4 ml-2" />
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
