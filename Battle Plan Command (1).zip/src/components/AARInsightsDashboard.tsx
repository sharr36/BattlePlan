import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  TrendingUp, 
  TrendingDown, 
  Minus, 
  Sparkles, 
  RefreshCw, 
  Target, 
  Lightbulb, 
  AlertCircle,
  CheckCircle2,
  ArrowUp,
  BarChart3,
  Star
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface Theme {
  name: string;
  description: string;
  frequency: "high" | "medium" | "low";
  sentiment: "positive" | "negative" | "neutral";
}

interface Trend {
  area: string;
  direction: "improving" | "declining" | "stable";
  insight: string;
}

interface Recommendation {
  priority: "high" | "medium" | "low";
  action: string;
  rationale: string;
}

interface Stats {
  total: number;
  avgRating: number;
  quarterlyCount: number;
  yearlyCount: number;
  completedActions: number;
  totalActions: number;
}

interface Insights {
  summary: string;
  themes: Theme[];
  trends: Trend[];
  strengths: string[];
  growthAreas: string[];
  recommendations: Recommendation[];
  stats: Stats;
  analyzedAt: string;
}

export const AARInsightsDashboard = () => {
  const [insights, setInsights] = useState<Insights | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadInsights = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke("analyze-aar-insights");
      
      if (fnError) throw fnError;
      if (data.error) throw new Error(data.error);
      
      setInsights(data.insights);
    } catch (err) {
      console.error("Error loading insights:", err);
      setError(err instanceof Error ? err.message : "Failed to load insights");
      toast.error("Failed to analyze AARs");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadInsights();
  }, []);

  const getTrendIcon = (direction: string) => {
    switch (direction) {
      case "improving": return <TrendingUp className="w-4 h-4 text-green-500" />;
      case "declining": return <TrendingDown className="w-4 h-4 text-red-500" />;
      default: return <Minus className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const getFrequencyColor = (frequency: string) => {
    switch (frequency) {
      case "high": return "bg-red-500/10 text-red-600 border-red-500/20";
      case "medium": return "bg-yellow-500/10 text-yellow-600 border-yellow-500/20";
      default: return "bg-blue-500/10 text-blue-600 border-blue-500/20";
    }
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case "positive": return "bg-green-500/10 text-green-600 border-green-500/20";
      case "negative": return "bg-red-500/10 text-red-600 border-red-500/20";
      default: return "bg-muted text-muted-foreground";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-red-500/10 text-red-600 border-red-500/20";
      case "medium": return "bg-yellow-500/10 text-yellow-600 border-yellow-500/20";
      default: return "bg-green-500/10 text-green-600 border-green-500/20";
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="py-12">
          <div className="flex flex-col items-center justify-center gap-4">
            <div className="relative">
              <Sparkles className="w-12 h-12 text-primary animate-pulse" />
            </div>
            <div className="text-center">
              <h3 className="font-semibold">Analyzing Your AARs</h3>
              <p className="text-sm text-muted-foreground">
                AI is identifying patterns and generating insights...
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <CardContent className="py-12">
          <div className="flex flex-col items-center justify-center gap-4">
            <AlertCircle className="w-12 h-12 text-destructive" />
            <div className="text-center">
              <h3 className="font-semibold">Analysis Failed</h3>
              <p className="text-sm text-muted-foreground mb-4">{error}</p>
              <Button onClick={loadInsights} variant="outline" className="gap-2">
                <RefreshCw className="w-4 h-4" />
                Try Again
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!insights || insights.stats.total === 0) {
    return (
      <Card>
        <CardContent className="py-12">
          <div className="flex flex-col items-center justify-center gap-4">
            <BarChart3 className="w-12 h-12 text-muted-foreground" />
            <div className="text-center">
              <h3 className="font-semibold">No Data to Analyze</h3>
              <p className="text-sm text-muted-foreground">
                Create some After Action Reviews to see AI-powered insights!
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const actionCompletionRate = insights.stats.totalActions > 0 
    ? Math.round((insights.stats.completedActions / insights.stats.totalActions) * 100) 
    : 0;

  return (
    <div className="space-y-6">
      {/* Header with Refresh */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-display font-bold flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-primary" />
            AI Insights
          </h2>
          <p className="text-sm text-muted-foreground">
            Last analyzed: {new Date(insights.analyzedAt).toLocaleString()}
          </p>
        </div>
        <Button onClick={loadInsights} variant="outline" size="sm" className="gap-2">
          <RefreshCw className="w-4 h-4" />
          Refresh Analysis
        </Button>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{insights.stats.total}</p>
                <p className="text-xs text-muted-foreground">Total AARs</p>
              </div>
              <BarChart3 className="w-8 h-8 text-primary/20" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold flex items-center gap-1">
                  {insights.stats.avgRating.toFixed(1)}
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                </p>
                <p className="text-xs text-muted-foreground">Avg Rating</p>
              </div>
              <Star className="w-8 h-8 text-yellow-400/20" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{actionCompletionRate}%</p>
                <p className="text-xs text-muted-foreground">Actions Done</p>
              </div>
              <CheckCircle2 className="w-8 h-8 text-green-500/20" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">
                  {insights.stats.quarterlyCount}/{insights.stats.yearlyCount}
                </p>
                <p className="text-xs text-muted-foreground">Quarterly/Yearly</p>
              </div>
              <Target className="w-8 h-8 text-blue-500/20" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Executive Summary */}
      <Card className="bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="w-5 h-5 text-primary" />
            Executive Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-foreground leading-relaxed">{insights.summary}</p>
        </CardContent>
      </Card>

      {/* Themes & Trends Row */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Recurring Themes */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Recurring Themes</CardTitle>
            <CardDescription>Patterns identified across your reviews</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {insights.themes.length === 0 ? (
              <p className="text-sm text-muted-foreground">No recurring themes identified yet.</p>
            ) : (
              insights.themes.map((theme, idx) => (
                <div key={idx} className="p-3 rounded-lg border bg-card">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <span className="font-medium">{theme.name}</span>
                    <div className="flex gap-1">
                      <Badge variant="outline" className={getFrequencyColor(theme.frequency)}>
                        {theme.frequency}
                      </Badge>
                      <Badge variant="outline" className={getSentimentColor(theme.sentiment)}>
                        {theme.sentiment}
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">{theme.description}</p>
                </div>
              ))
            )}
          </CardContent>
        </Card>

        {/* Trends */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Trends Over Time</CardTitle>
            <CardDescription>How things are changing</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {insights.trends.length === 0 ? (
              <p className="text-sm text-muted-foreground">Need more AARs to identify trends.</p>
            ) : (
              insights.trends.map((trend, idx) => (
                <div key={idx} className="p-3 rounded-lg border bg-card">
                  <div className="flex items-center gap-2 mb-1">
                    {getTrendIcon(trend.direction)}
                    <span className="font-medium">{trend.area}</span>
                    <Badge variant="outline" className={
                      trend.direction === "improving" ? "bg-green-500/10 text-green-600" :
                      trend.direction === "declining" ? "bg-red-500/10 text-red-600" :
                      "bg-muted text-muted-foreground"
                    }>
                      {trend.direction}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">{trend.insight}</p>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      {/* Strengths & Growth Areas */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-green-500" />
              Your Strengths
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {insights.strengths.length === 0 ? (
                <li className="text-sm text-muted-foreground">Add more AARs to identify strengths.</li>
              ) : (
                insights.strengths.map((strength, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-sm">
                    <ArrowUp className="w-4 h-4 text-green-500 mt-0.5 shrink-0" />
                    <span>{strength}</span>
                  </li>
                ))
              )}
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Target className="w-5 h-5 text-orange-500" />
              Areas for Growth
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {insights.growthAreas.length === 0 ? (
                <li className="text-sm text-muted-foreground">Add more AARs to identify growth areas.</li>
              ) : (
                insights.growthAreas.map((area, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-sm">
                    <Target className="w-4 h-4 text-orange-500 mt-0.5 shrink-0" />
                    <span>{area}</span>
                  </li>
                ))
              )}
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            AI Recommendations
          </CardTitle>
          <CardDescription>Actionable next steps based on your AAR patterns</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {insights.recommendations.length === 0 ? (
            <p className="text-sm text-muted-foreground">Add more AARs to get recommendations.</p>
          ) : (
            insights.recommendations.map((rec, idx) => (
              <div key={idx} className="p-4 rounded-lg border bg-card">
                <div className="flex items-start gap-3">
                  <Badge variant="outline" className={getPriorityColor(rec.priority)}>
                    {rec.priority}
                  </Badge>
                  <div className="flex-1">
                    <p className="font-medium mb-1">{rec.action}</p>
                    <p className="text-sm text-muted-foreground">{rec.rationale}</p>
                  </div>
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
};
