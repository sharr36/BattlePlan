import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Sparkles, Send, Loader2, X, MessageCircle, Copy, Check } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface Message {
  role: "assistant" | "user";
  content: string;
}

interface VisionAIChatProps {
  section?: string;
  currentData?: any;
  onClose?: () => void;
  isOpen: boolean;
  onCopyToField?: (content: string, section: string) => void;
}

const SECTION_LABELS: Record<string, string> = {
  general: "Vision Planning",
  yearly_theme: "Yearly Theme",
  financial: "Financial Goals",
  body_stats: "Health & Body",
  contribution: "Contribution",
  highlights: "Highlights",
  bucket_list: "Bucket List",
  life_categories: "Life Categories",
  accountability: "Accountability",
};

const QUICK_PROMPTS: Record<string, string[]> = {
  general: [
    "Help me set my yearly theme",
    "I need financial goal ideas",
    "What should my bucket list include?",
  ],
  yearly_theme: [
    "What makes a good yearly theme?",
    "I want to focus on growth",
    "Help me narrow down my options",
  ],
  financial: [
    "What's a realistic income goal?",
    "How do I calculate financial freedom?",
    "Help me set net worth targets",
  ],
  body_stats: [
    "What are healthy body goals?",
    "How should I track fitness?",
    "What metrics matter most?",
  ],
  bucket_list: [
    "I love adventure travel",
    "I want meaningful experiences",
    "Help me think bigger",
  ],
  accountability: [
    "What should I be held accountable for?",
    "I struggle with consistency",
    "I need help with discipline",
  ],
};

export function VisionAIChat({ section = "general", currentData, onClose, isOpen, onCopyToField }: VisionAIChatProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      startConversation();
    }
  }, [isOpen, section]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const startConversation = async () => {
    setIsLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error("Please log in to use AI assistance");
        return;
      }

      const { data, error } = await supabase.functions.invoke("vision-wizard-ai", {
        body: { section, conversationHistory: [], currentData },
      });

      if (error) throw error;
      
      setMessages([{ role: "assistant", content: data.suggestion }]);
    } catch (error) {
      console.error("Error starting AI conversation:", error);
      toast.error("Failed to start AI assistant");
    } finally {
      setIsLoading(false);
    }
  };

  const sendMessage = async (messageText?: string) => {
    const text = messageText || input.trim();
    if (!text || isLoading) return;

    const userMessage: Message = { role: "user", content: text };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput("");
    setIsLoading(true);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error("Please log in to use AI assistance");
        return;
      }

      const { data, error } = await supabase.functions.invoke("vision-wizard-ai", {
        body: {
          section,
          conversationHistory: newMessages,
          userInput: text,
          currentData,
        },
      });

      if (error) {
        if (error.message?.includes("429")) {
          toast.error("Rate limit reached. Please wait a moment.");
        } else if (error.message?.includes("402")) {
          toast.error("AI usage limit reached. Please add credits.");
        } else {
          throw error;
        }
        return;
      }

      setMessages([...newMessages, { role: "assistant", content: data.suggestion }]);
    } catch (error) {
      console.error("Error sending message:", error);
      toast.error("Failed to get AI response");
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleCopyToField = (content: string, idx: number) => {
    if (onCopyToField) {
      onCopyToField(content, section);
      setCopiedIndex(idx);
      toast.success("Copied to form field!");
      setTimeout(() => setCopiedIndex(null), 2000);
    }
  };

  const quickPrompts = QUICK_PROMPTS[section] || QUICK_PROMPTS.general;

  if (!isOpen) return null;

  return (
    <Card className="fixed bottom-4 right-4 w-96 h-[500px] shadow-2xl z-50 flex flex-col bg-background border-2">
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle className="text-sm flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          AI Vision Assistant - {SECTION_LABELS[section] || section}
        </CardTitle>
        <Button variant="ghost" size="icon" className="h-6 w-6" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </CardHeader>
      
      <CardContent className="flex-1 flex flex-col p-3 pt-0 overflow-hidden">
        <ScrollArea className="flex-1 pr-2" ref={scrollRef}>
          <div className="space-y-3">
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={`p-3 rounded-lg text-sm ${
                  msg.role === "assistant"
                    ? "bg-muted"
                    : "bg-primary text-primary-foreground ml-6"
                }`}
              >
                <div className="whitespace-pre-wrap">{msg.content}</div>
                {msg.role === "assistant" && onCopyToField && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="mt-2 h-7 text-xs gap-1 text-muted-foreground hover:text-foreground"
                    onClick={() => handleCopyToField(msg.content, idx)}
                  >
                    {copiedIndex === idx ? (
                      <>
                        <Check className="h-3 w-3" />
                        Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="h-3 w-3" />
                        Copy to form
                      </>
                    )}
                  </Button>
                )}
              </div>
            ))}
            {isLoading && (
              <div className="flex items-center gap-2 text-muted-foreground text-sm">
                <Loader2 className="h-4 w-4 animate-spin" />
                Thinking...
              </div>
            )}
          </div>
        </ScrollArea>

        {messages.length <= 1 && !isLoading && (
          <div className="flex flex-wrap gap-1 mt-2">
            {quickPrompts.map((prompt, idx) => (
              <Button
                key={idx}
                variant="outline"
                size="sm"
                className="text-xs h-7"
                onClick={() => sendMessage(prompt)}
              >
                {prompt}
              </Button>
            ))}
          </div>
        )}

        <div className="flex gap-2 mt-3">
          <Input
            placeholder="Ask for ideas..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            disabled={isLoading}
            className="text-sm"
          />
          <Button size="icon" onClick={() => sendMessage()} disabled={isLoading || !input.trim()}>
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

// Floating AI button component
export function AIAssistButton({ onClick, isActive }: { onClick: () => void; isActive: boolean }) {
  return (
    <Button
      onClick={onClick}
      className={`fixed bottom-4 right-4 h-14 w-14 rounded-full shadow-lg z-40 ${
        isActive ? "bg-primary/80" : ""
      }`}
      size="icon"
    >
      {isActive ? (
        <X className="h-6 w-6" />
      ) : (
        <MessageCircle className="h-6 w-6" />
      )}
    </Button>
  );
}
