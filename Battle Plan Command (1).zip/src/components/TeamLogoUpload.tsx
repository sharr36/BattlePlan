import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Upload, X, Image as ImageIcon, Loader2 } from "lucide-react";

interface TeamLogoUploadProps {
  teamId: string;
  currentLogoUrl: string | null;
  onLogoUpdated: (url: string | null) => void;
}

const TeamLogoUpload = ({ teamId, currentLogoUrl, onLogoUpdated }: TeamLogoUploadProps) => {
  const [isUploading, setIsUploading] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith("image/")) {
      toast({
        title: "Invalid File Type",
        description: "Please select an image file (PNG, JPG, WEBP, etc.)",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: "Please select an image smaller than 2MB",
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);

    try {
      // Create unique filename
      const fileExt = file.name.split(".").pop();
      const fileName = `${teamId}/logo-${Date.now()}.${fileExt}`;

      // Delete old logo if exists
      if (currentLogoUrl) {
        const oldPath = currentLogoUrl.split("/team-logos/")[1];
        if (oldPath) {
          await supabase.storage.from("team-logos").remove([oldPath]);
        }
      }

      // Upload new logo
      const { error: uploadError } = await supabase.storage
        .from("team-logos")
        .upload(fileName, file, {
          cacheControl: "3600",
          upsert: true,
        });

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from("team-logos")
        .getPublicUrl(fileName);

      // Update team record
      const { error: updateError } = await supabase
        .from("teams")
        .update({ logo_url: publicUrl })
        .eq("id", teamId);

      if (updateError) throw updateError;

      onLogoUpdated(publicUrl);
      toast({
        title: "Logo Updated",
        description: "Team logo has been uploaded successfully.",
      });
    } catch (error: any) {
      toast({
        title: "Upload Failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  const handleRemoveLogo = async () => {
    if (!currentLogoUrl) return;

    setIsDeleting(true);

    try {
      // Extract path from URL
      const path = currentLogoUrl.split("/team-logos/")[1];
      if (path) {
        await supabase.storage.from("team-logos").remove([path]);
      }

      // Clear logo_url in database
      const { error } = await supabase
        .from("teams")
        .update({ logo_url: null })
        .eq("id", teamId);

      if (error) throw error;

      onLogoUpdated(null);
      toast({
        title: "Logo Removed",
        description: "Team logo has been removed.",
      });
    } catch (error: any) {
      toast({
        title: "Remove Failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        {/* Logo preview */}
        <div className="w-24 h-24 rounded-lg border-2 border-dashed border-border flex items-center justify-center overflow-hidden bg-muted">
          {currentLogoUrl ? (
            <img
              src={currentLogoUrl}
              alt="Team logo"
              className="w-full h-full object-cover"
            />
          ) : (
            <ImageIcon className="w-8 h-8 text-muted-foreground" />
          )}
        </div>

        {/* Upload controls */}
        <div className="flex flex-col gap-2">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileSelect}
            className="hidden"
          />
          <Button
            onClick={() => fileInputRef.current?.click()}
            disabled={isUploading || isDeleting}
            variant="outline"
          >
            {isUploading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Uploading...
              </>
            ) : (
              <>
                <Upload className="w-4 h-4 mr-2" />
                {currentLogoUrl ? "Change Logo" : "Upload Logo"}
              </>
            )}
          </Button>

          {currentLogoUrl && (
            <Button
              onClick={handleRemoveLogo}
              disabled={isUploading || isDeleting}
              variant="ghost"
              size="sm"
              className="text-destructive hover:text-destructive"
            >
              {isDeleting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Removing...
                </>
              ) : (
                <>
                  <X className="w-4 h-4 mr-2" />
                  Remove Logo
                </>
              )}
            </Button>
          )}
        </div>
      </div>

      <p className="text-sm text-muted-foreground">
        Upload a logo for your team. Recommended size: 200x200px. Max file size: 2MB.
      </p>
    </div>
  );
};

export default TeamLogoUpload;
