import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, ChevronUp, Heart, Brain, Compass, Users, Briefcase, Wallet, Mountain, Sparkles, Target, HelpCircle, Scale, Activity } from "lucide-react";
import { Label } from "@/components/ui/label";

interface LifeCategory {
  target1: string;
  target2: string;
  target3: string;
}

interface VisionGoingDeeperProps {
  yearlyTheme: string;
  lifeCategories: Record<string, LifeCategory>;
  bodyMetrics: Record<string, string>;
  financialMetrics: Record<string, string>;
  bucketList: string[];
  accountabilityNeeds: string;
  helpNeeded: string;
  onChange: (field: string, value: any) => void;
}

const LIFE_CATEGORIES = [
  { id: "health", label: "Health & Nutrition", icon: Heart, color: "text-red-400" },
  { id: "spiritual", label: "Spiritual & Growth", icon: Sparkles, color: "text-purple-400" },
  { id: "adventure", label: "Lifestyle & Adventure", icon: Compass, color: "text-orange-400" },
  { id: "personal_growth", label: "Personal Development", icon: Brain, color: "text-blue-400" },
  { id: "career", label: "Business & Career", icon: Briefcase, color: "text-green-400" },
  { id: "relationships", label: "Family & Relationships", icon: Users, color: "text-pink-400" },
  { id: "financial", label: "Financial & Investment", icon: Wallet, color: "text-yellow-400" },
  { id: "community", label: "Community & Tribe", icon: Mountain, color: "text-cyan-400" },
];

const BODY_METRICS = [
  { id: "weight", label: "Weight Goal" },
  { id: "body_fat", label: "Body Fat % Goal" },
  { id: "blood_pressure", label: "Blood Pressure Goal" },
  { id: "fitness_score", label: "Fitness Score Goal" },
];

const FINANCIAL_METRICS = [
  { id: "net_worth_goal", label: "Net Worth Goal" },
  { id: "income_goal", label: "Annual Income Goal" },
  { id: "savings_rate", label: "Savings Rate Goal (%)" },
  { id: "debt_payoff", label: "Debt Payoff Goal" },
];

export function VisionGoingDeeper({
  yearlyTheme,
  lifeCategories,
  bodyMetrics,
  financialMetrics,
  bucketList,
  accountabilityNeeds,
  helpNeeded,
  onChange,
}: VisionGoingDeeperProps) {
  const [isOpen, setIsOpen] = useState(false);

  const updateLifeCategory = (categoryId: string, field: keyof LifeCategory, value: string) => {
    const updated = {
      ...lifeCategories,
      [categoryId]: {
        ...(lifeCategories[categoryId] || { target1: "", target2: "", target3: "" }),
        [field]: value,
      },
    };
    onChange("life_categories", updated);
  };

  const updateBodyMetric = (metricId: string, value: string) => {
    onChange("body_metrics", { ...bodyMetrics, [metricId]: value });
  };

  const updateFinancialMetric = (metricId: string, value: string) => {
    onChange("financial_metrics", { ...financialMetrics, [metricId]: value });
  };

  const updateBucketList = (index: number, value: string) => {
    const updated = [...bucketList];
    updated[index] = value;
    onChange("bucket_list", updated);
  };

  // Ensure bucket list has 5 slots
  const bucketListItems = [...(bucketList || []), "", "", "", "", ""].slice(0, 5);

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <Card className="border-dashed border-primary/30 bg-primary/5">
        <CollapsibleTrigger asChild>
          <CardHeader className="cursor-pointer hover:bg-primary/10 transition-colors rounded-t-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-primary/20">
                  <Target className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <CardTitle className="text-lg">Going Deeper (Optional)</CardTitle>
                  <CardDescription>
                    Detailed life planning across 8 categories, metrics tracking, and bucket list
                  </CardDescription>
                </div>
              </div>
              <Button variant="ghost" size="icon">
                {isOpen ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
              </Button>
            </div>
          </CardHeader>
        </CollapsibleTrigger>

        <CollapsibleContent>
          <CardContent className="space-y-8 pt-0">
            {/* Yearly Theme */}
            <div className="space-y-2">
              <Label className="text-base font-semibold">Theme for the Year</Label>
              <p className="text-sm text-muted-foreground">
                What word or phrase captures your focus for this year?
              </p>
              <Input
                placeholder="e.g., Year of Discipline, Build the Foundation, Breakthrough..."
                value={yearlyTheme}
                onChange={(e) => onChange("yearly_theme", e.target.value)}
                className="text-lg font-medium"
              />
            </div>

            {/* Life Categories - 8 Areas */}
            <div className="space-y-4">
              <div>
                <h3 className="text-base font-semibold flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-primary" />
                  Top 3 Targets by Life Category
                </h3>
                <p className="text-sm text-muted-foreground">
                  Define your top 3 goals in each area of life
                </p>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                {LIFE_CATEGORIES.map((category) => {
                  const Icon = category.icon;
                  const categoryData = lifeCategories[category.id] || { target1: "", target2: "", target3: "" };

                  return (
                    <Card key={category.id} className="bg-background/50">
                      <CardHeader className="pb-2 pt-4 px-4">
                        <CardTitle className="text-sm flex items-center gap-2">
                          <Icon className={`h-4 w-4 ${category.color}`} />
                          {category.label}
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="px-4 pb-4 space-y-2">
                        <Input
                          placeholder="Target 1..."
                          value={categoryData.target1}
                          onChange={(e) => updateLifeCategory(category.id, "target1", e.target.value)}
                          className="text-sm h-8"
                        />
                        <Input
                          placeholder="Target 2..."
                          value={categoryData.target2}
                          onChange={(e) => updateLifeCategory(category.id, "target2", e.target.value)}
                          className="text-sm h-8"
                        />
                        <Input
                          placeholder="Target 3..."
                          value={categoryData.target3}
                          onChange={(e) => updateLifeCategory(category.id, "target3", e.target.value)}
                          className="text-sm h-8"
                        />
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>

            {/* Metrics Section */}
            <div className="grid gap-6 sm:grid-cols-2">
              {/* Body Metrics */}
              <Card className="bg-background/50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Activity className="h-4 w-4 text-red-400" />
                    Body & Health Goals
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {BODY_METRICS.map((metric) => (
                    <div key={metric.id} className="space-y-1">
                      <Label className="text-xs text-muted-foreground">{metric.label}</Label>
                      <Input
                        placeholder={metric.label}
                        value={bodyMetrics[metric.id] || ""}
                        onChange={(e) => updateBodyMetric(metric.id, e.target.value)}
                        className="h-8 text-sm"
                      />
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Financial Metrics */}
              <Card className="bg-background/50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Scale className="h-4 w-4 text-green-400" />
                    Financial Goals
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {FINANCIAL_METRICS.map((metric) => (
                    <div key={metric.id} className="space-y-1">
                      <Label className="text-xs text-muted-foreground">{metric.label}</Label>
                      <Input
                        placeholder={metric.label}
                        value={financialMetrics[metric.id] || ""}
                        onChange={(e) => updateFinancialMetric(metric.id, e.target.value)}
                        className="h-8 text-sm"
                      />
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>

            {/* Bucket List */}
            <div className="space-y-3">
              <div>
                <h3 className="text-base font-semibold flex items-center gap-2">
                  <Mountain className="h-4 w-4 text-orange-400" />
                  Top 5 Bucket List Adventures
                </h3>
                <p className="text-sm text-muted-foreground">
                  Experiences and adventures you want to have
                </p>
              </div>
              <div className="grid gap-2">
                {bucketListItems.map((item, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-primary/20 text-primary text-xs font-bold flex items-center justify-center">
                      {index + 1}
                    </span>
                    <Input
                      placeholder={`Adventure ${index + 1}...`}
                      value={item}
                      onChange={(e) => updateBucketList(index, e.target.value)}
                      className="flex-1"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Accountability & Help */}
            <div className="grid gap-6 sm:grid-cols-2">
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Target className="h-4 w-4 text-primary" />
                  What do you want to be held accountable for?
                </Label>
                <Textarea
                  placeholder="List the specific commitments you want others to hold you to..."
                  value={accountabilityNeeds}
                  onChange={(e) => onChange("accountability_needs", e.target.value)}
                  className="min-h-[100px] resize-none"
                />
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <HelpCircle className="h-4 w-4 text-blue-400" />
                  What do you need help with?
                </Label>
                <Textarea
                  placeholder="What challenges are you facing? What support or resources do you need?"
                  value={helpNeeded}
                  onChange={(e) => onChange("help_needed", e.target.value)}
                  className="min-h-[100px] resize-none"
                />
              </div>
            </div>
          </CardContent>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
}
