import { useState, useRef } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Upload, FileText, Loader2, Sparkles, File, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface ImportedPlan {
  vision: string;
  calibration: QuadrantData;
  connection: QuadrantData;
  condition: QuadrantData;
  contribution: QuadrantData;
}

interface QuadrantData {
  objective: string;
  primaryTactic: string;
  secondaryTactic1: string;
  secondaryTactic2?: string;
  secondaryTactic3?: string;
  checkpoint30: string;
  checkpoint60: string;
}

interface BattlePlanImportProps {
  onImport: (plan: ImportedPlan) => void;
}

export const BattlePlanImport = ({ onImport }: BattlePlanImportProps) => {
  const [open, setOpen] = useState(false);
  const [planText, setPlanText] = useState("");
  const [loading, setLoading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileProcessing, setFileProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const fileName = file.name.toLowerCase();
    const isCSV = fileName.endsWith('.csv');
    const isTXT = fileName.endsWith('.txt');
    const isPDF = fileName.endsWith('.pdf');
    
    if (!isCSV && !isTXT && !isPDF) {
      toast.error("Please upload a PDF, CSV, or TXT file");
      return;
    }

    if (file.size > 5 * 1024 * 1024) { // 5MB limit
      toast.error("File size must be less than 5MB");
      return;
    }

    setSelectedFile(file);
    setFileProcessing(true);

    try {
      if (isPDF) {
        // For PDFs, we need to send to edge function for parsing
        // Read as base64
        const reader = new FileReader();
        reader.onload = async () => {
          const base64 = (reader.result as string).split(',')[1];
          setPlanText(`[PDF file: ${file.name}]\n\nPDF content will be extracted during import. Click "Import with AI" to process.`);
          // Store the base64 in a data attribute for later use
          setSelectedFile(Object.assign(file, { base64Content: base64 }));
        };
        reader.readAsDataURL(file);
        toast.info("PDF loaded. Click 'Import with AI' to extract and process the content.");
      } else {
        // CSV or TXT - read as text directly
        const content = await file.text();
        setPlanText(content);
        toast.success(`File "${file.name}" loaded successfully`);
      }
    } catch (error) {
      console.error("Error processing file:", error);
      toast.error("Failed to process file");
      setSelectedFile(null);
    } finally {
      setFileProcessing(false);
    }
  };

  const clearFile = () => {
    setSelectedFile(null);
    setPlanText("");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleImport = async () => {
    const isPDF = selectedFile?.name.toLowerCase().endsWith('.pdf');
    
    // For PDFs, we have different validation
    if (!isPDF && planText.trim().length < 50) {
      toast.error("Please enter at least 50 characters of battle plan content");
      return;
    }

    setLoading(true);
    try {
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      if (sessionError || !session) {
        toast.error("Your session has expired. Please log in again.");
        setLoading(false);
        return;
      }

      let contentToSend = planText;
      let fileType = 'text';
      
      if (selectedFile) {
        const fileName = selectedFile.name.toLowerCase();
        if (fileName.endsWith('.csv')) {
          fileType = 'csv';
        } else if (fileName.endsWith('.pdf')) {
          fileType = 'pdf';
          // Get the base64 content for PDF
          contentToSend = (selectedFile as any).base64Content || '';
        }
      }

      const { data, error } = await supabase.functions.invoke("import-battle-plan", {
        body: { 
          planText: fileType === 'pdf' ? '' : planText,
          fileContent: contentToSend,
          fileType,
          fileName: selectedFile?.name
        }
      });

      if (error) {
        throw error;
      }

      if (data.error) {
        throw new Error(data.error);
      }

      if (data.success && data.plan) {
        onImport(data.plan);
        toast.success("Battle plan imported successfully!");
        setOpen(false);
        setPlanText("");
        setSelectedFile(null);
      } else {
        throw new Error("Failed to parse battle plan");
      }
    } catch (error) {
      console.error("Import error:", error);
      toast.error(error instanceof Error ? error.message : "Failed to import battle plan");
    } finally {
      setLoading(false);
    }
  };

  const examplePlan = `Example format:

VISION: Become the best version of myself this quarter by focusing on health, relationships, and career growth.

CALIBRATION (Personal Development):
- Objective: Develop a morning routine that sets me up for success
- Primary Tactic: Wake up at 5:30 AM daily and meditate for 20 minutes
- Secondary: Read 30 minutes daily, journal before bed, attend one personal development event
- 30-Day Checkpoint: Completed 25 morning routines without missing
- 60-Day Checkpoint: Morning routine is automatic, reading 2 books completed

CONNECTION (Relationships):
- Objective: Strengthen my marriage and family bonds
- Primary Tactic: Weekly date night with spouse
- Secondary: Daily 15-min quality time with each kid, monthly family adventure
- 30-Day Checkpoint: 4 date nights completed, family adventure planned
- 60-Day Checkpoint: Deeper conversations happening naturally

CONDITION (Physical Health):
- Objective: Lose 15 pounds and increase energy levels
- Primary Tactic: Work out 5 times per week
- Secondary: Meal prep Sundays, drink 100oz water daily, sleep 7+ hours
- 30-Day Checkpoint: Lost 5 pounds, workout habit established
- 60-Day Checkpoint: Lost 10 pounds, energy noticeably improved

CONTRIBUTION (Career/Business):
- Objective: Get promoted to senior position
- Primary Tactic: Complete leadership training program
- Secondary: Mentor 2 junior team members, lead one major project
- 30-Day Checkpoint: Training 50% complete, mentoring relationships started
- 60-Day Checkpoint: Training complete, project proposal approved`;

  const csvExample = `CSV Format Example:
quadrant,objective,primary_tactic,secondary_tactics,checkpoint_30,checkpoint_60
calibration,"Morning routine mastery","Meditate 20 min daily","Read 30 min; Journal nightly","25 sessions done","Habit locked in"
connection,"Strengthen family bonds","Weekly date night","Quality time with kids; Monthly adventure","4 dates done","Deeper connection"
...`;

  const isPDFSelected = selectedFile?.name.toLowerCase().endsWith('.pdf');
  const canImport = isPDFSelected || planText.trim().length >= 50;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Upload className="h-4 w-4" />
          Import Plan
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            AI-Powered Battle Plan Import
          </DialogTitle>
          <DialogDescription>
            Upload a PDF, CSV, or paste your battle plan text and our AI will extract the structured data automatically.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 mt-4">
          {/* File Upload Section */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Upload File (Optional)</label>
            <div className="flex items-center gap-2">
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.csv,.txt"
                onChange={handleFileSelect}
                className="hidden"
              />
              <Button
                type="button"
                variant="outline"
                onClick={() => fileInputRef.current?.click()}
                disabled={fileProcessing}
                className="gap-2"
              >
                {fileProcessing ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <File className="h-4 w-4" />
                    Choose File
                  </>
                )}
              </Button>
              {selectedFile && (
                <div className="flex items-center gap-2 px-3 py-1.5 bg-muted rounded-md text-sm">
                  <FileText className="h-4 w-4 text-primary" />
                  <span className="truncate max-w-[200px]">{selectedFile.name}</span>
                  <button
                    onClick={clearFile}
                    className="text-muted-foreground hover:text-foreground"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              )}
            </div>
            <p className="text-xs text-muted-foreground">
              Supported formats: PDF, CSV, TXT (max 5MB)
            </p>
          </div>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground">Or paste text</span>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Your Battle Plan Text</label>
            <Textarea
              value={planText}
              onChange={(e) => setPlanText(e.target.value)}
              placeholder="Paste your battle plan here... Include your vision, objectives, tactics, and checkpoints for each quadrant."
              className="min-h-[200px] font-mono text-sm"
              disabled={isPDFSelected}
            />
            <p className="text-xs text-muted-foreground">
              {isPDFSelected 
                ? "PDF content will be extracted during import" 
                : `${planText.length} characters • Minimum 50 required`}
            </p>
          </div>

          <details className="group">
            <summary className="flex items-center gap-2 cursor-pointer text-sm text-muted-foreground hover:text-foreground">
              <FileText className="h-4 w-4" />
              See example formats
            </summary>
            <div className="mt-2 space-y-3">
              <div>
                <p className="text-xs font-medium mb-1">Text/PDF Format:</p>
                <pre className="p-3 bg-muted rounded-md text-xs overflow-x-auto whitespace-pre-wrap max-h-[200px]">
                  {examplePlan}
                </pre>
              </div>
              <div>
                <p className="text-xs font-medium mb-1">CSV Format:</p>
                <pre className="p-3 bg-muted rounded-md text-xs overflow-x-auto whitespace-pre-wrap">
                  {csvExample}
                </pre>
              </div>
            </div>
          </details>

          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleImport} disabled={loading || !canImport}>
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  {isPDFSelected ? "Extracting & Analyzing..." : "Analyzing..."}
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 mr-2" />
                  Import with AI
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
