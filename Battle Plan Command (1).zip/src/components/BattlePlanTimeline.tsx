import { format, addWeeks, differenceInDays } from "date-fns";
import { Calendar, Target, Flag, CheckCircle2 } from "lucide-react";
import { useEffect, useState } from "react";

interface BattlePlanTimelineProps {
  startDate: Date;
  endDate: Date;
}

export function BattlePlanTimeline({ startDate, endDate }: BattlePlanTimelineProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [progressWidth, setProgressWidth] = useState(0);
  
  const week4Date = addWeeks(startDate, 4);
  const week8Date = addWeeks(startDate, 8);
  const today = new Date();
  
  // Calculate actual progress based on current date
  const totalDays = differenceInDays(endDate, startDate);
  const daysElapsed = differenceInDays(today, startDate);
  const actualProgress = Math.max(0, Math.min(100, (daysElapsed / totalDays) * 100));
  
  // Check if milestone is completed
  const isCompleted = (date: Date) => today >= date;

  const timelinePoints = [
    {
      label: "Start",
      date: startDate,
      icon: Flag,
      position: 0,
      completed: isCompleted(startDate),
    },
    {
      label: "Week 4",
      date: week4Date,
      icon: Target,
      position: 33.33,
      completed: isCompleted(week4Date),
    },
    {
      label: "Week 8",
      date: week8Date,
      icon: Target,
      position: 66.66,
      completed: isCompleted(week8Date),
    },
    {
      label: "End",
      date: endDate,
      icon: Flag,
      position: 100,
      completed: isCompleted(endDate),
    },
  ];

  useEffect(() => {
    // Trigger animations after mount
    const timer1 = setTimeout(() => setIsVisible(true), 100);
    const timer2 = setTimeout(() => setProgressWidth(actualProgress), 300);
    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
    };
  }, [actualProgress]);

  return (
    <div className="w-full p-4 sm:p-6 bg-gradient-to-br from-muted/40 via-muted/20 to-transparent rounded-xl border border-border/50 backdrop-blur-sm">
      <div className="flex items-center gap-2 mb-6">
        <div className="p-1.5 rounded-lg bg-primary/10">
          <Calendar className="h-4 w-4 text-primary" />
        </div>
        <h3 className="text-sm font-semibold text-foreground">12-Week Battle Plan</h3>
      </div>

      {/* Timeline Container */}
      <div className="relative pt-2 pb-16">
        {/* Background track */}
        <div className="absolute top-6 left-6 right-6 h-1.5 bg-border/50 rounded-full overflow-hidden">
          {/* Animated progress bar */}
          <div 
            className="h-full bg-gradient-to-r from-primary via-accent to-primary rounded-full transition-all duration-1000 ease-out relative"
            style={{ width: `${progressWidth}%` }}
          >
            {/* Shimmer effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-[shimmer_2s_infinite]" />
          </div>
        </div>

        {/* Current day marker */}
        {actualProgress > 0 && actualProgress < 100 && (
          <div 
            className={`absolute top-3 -translate-x-1/2 z-20 transition-all duration-1000 ease-out ${
              isVisible ? 'opacity-100' : 'opacity-0'
            }`}
            style={{ 
              left: `calc(${progressWidth}% * 0.92 + 4%)`,
              transitionDelay: '800ms'
            }}
          >
            <div className="relative flex flex-col items-center">
              {/* Pulsing dot */}
              <div className="relative">
                <div className="absolute inset-0 w-3 h-3 bg-accent rounded-full animate-ping opacity-75" />
                <div className="relative w-3 h-3 bg-accent rounded-full border-2 border-background shadow-lg" />
              </div>
              {/* Today label */}
              <div className="mt-1 px-1.5 py-0.5 bg-accent text-accent-foreground text-[9px] font-bold rounded uppercase tracking-wide whitespace-nowrap">
                Today
              </div>
            </div>
          </div>
        )}

        {/* Timeline Points */}
        <div className="relative flex justify-between px-0">
          {timelinePoints.map((point, index) => (
            <div
              key={index}
              className={`flex flex-col items-center transition-all duration-500 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
              }`}
              style={{ 
                transitionDelay: `${index * 150}ms`,
                width: index === 0 || index === 3 ? 'auto' : '80px'
              }}
            >
              {/* Icon circle with glow */}
              <div className={`relative group ${point.completed ? 'animate-pulse' : ''}`}>
                {/* Glow ring for completed */}
                {point.completed && (
                  <div className="absolute inset-0 rounded-full bg-primary/30 blur-md scale-150" />
                )}
                
                <div className={`
                  relative flex items-center justify-center w-10 h-10 sm:w-12 sm:h-12 rounded-full 
                  border-2 transition-all duration-300 z-10
                  ${point.completed 
                    ? 'border-primary bg-primary/20 text-primary shadow-lg shadow-primary/20' 
                    : 'border-border/60 bg-background text-muted-foreground hover:border-primary/50 hover:text-primary'
                  }
                `}>
                  {point.completed ? (
                    <CheckCircle2 className="h-4 w-4 sm:h-5 sm:w-5" />
                  ) : (
                    <point.icon className="h-4 w-4 sm:h-5 sm:w-5" />
                  )}
                </div>
              </div>

              {/* Label and date */}
              <div className="mt-3 text-center">
                <p className={`text-xs sm:text-sm font-medium transition-colors ${
                  point.completed ? 'text-primary' : 'text-foreground'
                }`}>
                  {point.label}
                </p>
                <p className="text-[10px] sm:text-xs text-muted-foreground mt-0.5">
                  {format(point.date, "MMM d")}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Week indicators */}
      <div className="flex justify-between text-[10px] text-muted-foreground/60 px-1 -mt-2">
        {Array.from({ length: 13 }, (_, i) => (
          <div 
            key={i} 
            className={`font-mono transition-opacity duration-300 ${
              isVisible ? 'opacity-100' : 'opacity-0'
            }`}
            style={{ transitionDelay: `${600 + i * 50}ms` }}
          >
            {i}
          </div>
        ))}
      </div>
    </div>
  );
}
