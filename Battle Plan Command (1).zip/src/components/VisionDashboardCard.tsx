import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Compass, ChevronRight, Users, Target, 
  Wallet, Mountain, Activity 
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

interface UserVision {
  yearly_theme: string | null;
  life_categories: Record<string, { target1: string; target2: string; target3: string }> | null;
  body_metrics: Record<string, string> | null;
  financial_metrics: Record<string, string> | null;
  bucket_list: string[] | null;
  team_id: string | null;
}

export function VisionDashboardCard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [vision, setVision] = useState<UserVision | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) loadVision();
  }, [user]);

  const loadVision = async () => {
    try {
      const { data, error } = await supabase
        .from("user_visions")
        .select("*")
        .eq("user_id", user?.id)
        .maybeSingle();

      if (error && error.code !== "PGRST116") throw error;
      if (data) {
        setVision({
          yearly_theme: data.yearly_theme,
          life_categories: data.life_categories as UserVision["life_categories"],
          body_metrics: data.body_metrics as UserVision["body_metrics"],
          financial_metrics: data.financial_metrics as UserVision["financial_metrics"],
          bucket_list: data.bucket_list as UserVision["bucket_list"],
          team_id: data.team_id,
        });
      }
    } catch (error) {
      console.error("Error loading vision:", error);
    } finally {
      setLoading(false);
    }
  };

  const getCompletedCategories = () => {
    if (!vision?.life_categories) return 0;
    return Object.values(vision.life_categories).filter(
      cat => cat.target1 || cat.target2 || cat.target3
    ).length;
  };

  const hasGoingDeeper = () => {
    return vision?.yearly_theme || 
           getCompletedCategories() > 0 ||
           Object.values(vision?.body_metrics || {}).some(Boolean) ||
           Object.values(vision?.financial_metrics || {}).some(Boolean) ||
           vision?.bucket_list?.some(Boolean);
  };

  if (loading) {
    return (
      <Card className="shadow-tactical animate-pulse">
        <CardHeader className="pb-2">
          <div className="h-5 bg-muted rounded w-1/3" />
        </CardHeader>
        <CardContent>
          <div className="h-20 bg-muted rounded" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-tactical hover:shadow-command transition-shadow">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Compass className="h-5 w-5 text-primary" />
            Going Deeper Vision
          </CardTitle>
          {vision?.team_id && (
            <Badge variant="secondary" className="text-xs">
              <Users className="h-3 w-3 mr-1" />
              Shared
            </Badge>
          )}
        </div>
        <CardDescription>
          Detailed life planning & goals
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {hasGoingDeeper() ? (
          <>
            {/* Theme */}
            {vision?.yearly_theme && (
              <div className="bg-primary/10 rounded-lg p-3">
                <span className="text-xs text-muted-foreground">Theme for the Year</span>
                <p className="font-semibold text-primary">{vision.yearly_theme}</p>
              </div>
            )}

            {/* Quick stats */}
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Target className="h-4 w-4" />
                <span>{getCompletedCategories()}/8 categories</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Mountain className="h-4 w-4" />
                <span>{vision?.bucket_list?.filter(Boolean).length || 0} adventures</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Activity className="h-4 w-4" />
                <span>{Object.values(vision?.body_metrics || {}).filter(Boolean).length} health goals</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Wallet className="h-4 w-4" />
                <span>{Object.values(vision?.financial_metrics || {}).filter(Boolean).length} financial goals</span>
              </div>
            </div>

            <Button 
              className="w-full"
              onClick={() => navigate("/going-deeper")}
            >
              Edit Vision
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </>
        ) : (
          <div className="text-center py-4">
            <Target className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
            <p className="text-sm text-muted-foreground mb-4">
              Define your goals across 8 life categories, set health & financial targets, and plan your bucket list.
            </p>
            <Button onClick={() => navigate("/going-deeper")} className="gap-2">
              Start Vision Planning
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
