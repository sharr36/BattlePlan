import { useState, useEffect, useRef } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Loader2, Send, Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface Message {
  role: "user" | "assistant";
  content: string;
}

interface BattlePlanAIChatProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  fieldType: "vision" | "objective" | "primary_tactic" | "secondary_tactics" | "checkpoints";
  context: any;
  tone: string;
  onComplete: (result: any) => void;
}

export const BattlePlanAIChat = ({ 
  open, 
  onOpenChange, 
  fieldType, 
  context, 
  tone,
  onComplete 
}: BattlePlanAIChatProps) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [conversationComplete, setConversationComplete] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      // Reset state and start conversation
      setMessages([]);
      setInput("");
      setConversationComplete(false);
      startConversation();
    }
  }, [open]);

  useEffect(() => {
    // Auto-scroll to bottom when new messages arrive
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  // Refocus input when loading completes
  useEffect(() => {
    if (!loading && open && !conversationComplete) {
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [loading, open, conversationComplete]);

  const startConversation = async () => {
    setLoading(true);
    try {
      // Refresh the session to ensure we have a valid token
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      if (sessionError || !session) {
        toast.error("Your session has expired. Please log in again.");
        return;
      }

      const { data, error } = await supabase.functions.invoke('battle-plan-ai', {
        body: { 
          type: fieldType, 
          context,
          tone,
          conversationMode: true
        }
      });

      if (error) throw error;

      if (data?.suggestion) {
        setMessages([{ role: "assistant", content: data.suggestion }]);
      }
    } catch (error: any) {
      console.error("Error starting conversation:", error);
      toast.error("Failed to start AI conversation");
    } finally {
      setLoading(false);
    }
  };

  const sendMessage = async () => {
    if (!input.trim()) return;

    const userMessage = input.trim();
    setInput("");
    
    // Add user message to chat
    const updatedMessages: Message[] = [...messages, { role: "user", content: userMessage }];
    setMessages(updatedMessages);
    setLoading(true);

    try {
      // Refresh the session to ensure we have a valid token
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      if (sessionError || !session) {
        toast.error("Your session has expired. Please log in again.");
        setLoading(false);
        return;
      }

      // Send conversation history to maintain context
      const conversationHistory = updatedMessages.map(msg => ({
        role: msg.role,
        content: msg.content
      }));

      const { data, error } = await supabase.functions.invoke('battle-plan-ai', {
        body: { 
          type: fieldType, 
          context,
          tone,
          conversationMode: true,
          userInput: userMessage,
          conversationHistory: conversationHistory
        }
      });

      if (error) throw error;

      if (data?.suggestion) {
        const aiResponse = data.suggestion;
        setMessages(prev => [...prev, { role: "assistant", content: aiResponse }]);
        
        // Detect if this is a final answer by checking for completion phrases
        const completionPhrases = [
          "based on our conversation",
          "here's your smart objective:",
          "your primary daily tactic:",
          "here are your supporting tactics:",
          "here are your checkpoints:"
        ];
        
        const isFinalAnswer = completionPhrases.some(phrase => 
          aiResponse.toLowerCase().includes(phrase)
        );
        
        if (isFinalAnswer) {
          setConversationComplete(true);
          
          // Extract the final content
          try {
            let result = aiResponse;
            
            // For vision and objectives, extract after the intro phrase
            if (fieldType === "vision" || fieldType === "objective" || fieldType === "primary_tactic") {
              const lines = aiResponse.split('\n');
              // Find the actual content (usually after the intro line)
              const contentStart = lines.findIndex(line => 
                line.trim() && !line.includes("Based on") && !line.includes("Here's")
              );
              if (contentStart > 0) {
                result = lines.slice(contentStart).join('\n').trim();
              }
            }
            
            // Handle JSON responses for secondary_tactics and checkpoints
            if (fieldType === "secondary_tactics" || fieldType === "checkpoints") {
              const fenceMatch = result.match(/```[a-zA-Z]*\n?([\s\S]*?)```/);
              if (fenceMatch && fenceMatch[1]) {
                result = fenceMatch[1].trim();
              }
              // Look for JSON in the response
              const jsonMatch = result.match(/\{[\s\S]*\}|\[[\s\S]*\]/);
              if (jsonMatch) {
                result = JSON.parse(jsonMatch[0]);
              }
            }
            
            setTimeout(() => {
              onComplete(result);
              onOpenChange(false);
              toast.success("AI suggestion applied!");
            }, 1500);
          } catch (e) {
            console.error("Parse error:", e);
            // Fallback: use the full response
            onComplete(aiResponse);
            onOpenChange(false);
            toast.success("AI suggestion applied!");
          }
        }
      }
    } catch (error: any) {
      console.error("Error sending message:", error);
      toast.error("Failed to get AI response");
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const getTitle = () => {
    const titles = {
      vision: "Create Your Vision Statement",
      objective: "Define Your Objective",
      primary_tactic: "Choose Your Primary Tactic",
      secondary_tactics: "Add Secondary Tactics",
      checkpoints: "Set Your Checkpoints"
    };
    return titles[fieldType];
  };

  const getDescription = () => {
    const descriptions = {
      vision: "Let's have a conversation to craft a compelling 12-week vision",
      objective: "Answer a few questions to create a SMART objective",
      primary_tactic: "Let's identify your most impactful daily action",
      secondary_tactics: "Let's define supporting tactics to accelerate your progress",
      checkpoints: "Let's set measurable milestones for your journey"
    };
    return descriptions[fieldType];
  };

  const getExamplePrompts = (): string[] => {
    const prompts: Record<typeof fieldType, string[]> = {
      vision: [
        "I want to feel more energized and confident",
        "I'm struggling to balance work and family",
        "I want to build better habits but don't know where to start"
      ],
      objective: [
        "I want to lose weight but I'm not sure how much is realistic",
        "I need to improve my relationship with my spouse",
        "I want to read more but always run out of time"
      ],
      primary_tactic: [
        "I could work out in the morning or evening",
        "I have about 30 minutes free each day",
        "I'm not sure what would have the biggest impact"
      ],
      secondary_tactics: [
        "I could also do meal prep on Sundays",
        "Maybe tracking my progress would help",
        "I'm not sure what else would support my goal"
      ],
      checkpoints: [
        "I'd like to see progress within the first month",
        "I'm not sure how to measure my progress",
        "What milestones should I aim for?"
      ]
    };
    return prompts[fieldType];
  };

  const handleExampleClick = (prompt: string) => {
    setInput(prompt);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-[95vw] max-w-2xl h-[85vh] sm:h-[600px] flex flex-col p-4 sm:p-6">
        <DialogHeader className="space-y-1 sm:space-y-2">
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
            <DialogTitle className="text-base sm:text-lg">{getTitle()}</DialogTitle>
          </div>
          <DialogDescription className="text-xs sm:text-sm">{getDescription()}</DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1 pr-2 sm:pr-4 -mr-2 sm:-mr-4" ref={scrollRef}>
          <div className="space-y-3 sm:space-y-4 pb-4">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[90%] sm:max-w-[80%] rounded-lg px-3 sm:px-4 py-2 ${
                    message.role === "user"
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted"
                  }`}
                >
                  <p className="text-xs sm:text-sm whitespace-pre-wrap">{message.content}</p>
                </div>
              </div>
            ))}
            
            {loading && (
              <div className="flex justify-start">
                <div className="bg-muted rounded-lg px-3 sm:px-4 py-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                </div>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Example prompts - show only at start of conversation */}
        {messages.length === 1 && !loading && !conversationComplete && (
          <div className="px-1 py-2 border-t border-border/50">
            <p className="text-xs text-muted-foreground mb-2">Not sure what to say? Try one of these:</p>
            <div className="flex flex-wrap gap-2">
              {getExamplePrompts().map((prompt, index) => (
                <button
                  key={index}
                  onClick={() => handleExampleClick(prompt)}
                  className="text-xs px-3 py-1.5 rounded-full bg-muted hover:bg-muted/80 text-muted-foreground hover:text-foreground transition-colors text-left"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>
        )}

        {!conversationComplete && (
          <div className="flex gap-2 pt-3 sm:pt-4 border-t">
            <Input
              ref={inputRef}
              placeholder="Type your response..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              disabled={loading}
              className="text-sm"
              autoFocus
            />
            <Button onClick={sendMessage} disabled={loading || !input.trim()} className="px-3 sm:px-4">
              <Send className="h-4 w-4" />
            </Button>
          </div>
        )}

        {conversationComplete && (
          <div className="pt-3 sm:pt-4 border-t text-center text-xs sm:text-sm text-muted-foreground">
            ✓ Suggestion ready! Applying to form...
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
