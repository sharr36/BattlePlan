export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      after_action_reviews: {
        Row: {
          action_items: Json | null
          created_at: string
          id: string
          is_shared: boolean | null
          lessons_learned: string | null
          overall_rating: number | null
          period_end: string
          period_start: string
          review_type: string
          share_token: string | null
          team_id: string
          updated_at: string
          user_id: string
          what_could_improve: string | null
          what_went_well: string | null
        }
        Insert: {
          action_items?: Json | null
          created_at?: string
          id?: string
          is_shared?: boolean | null
          lessons_learned?: string | null
          overall_rating?: number | null
          period_end: string
          period_start: string
          review_type: string
          share_token?: string | null
          team_id: string
          updated_at?: string
          user_id: string
          what_could_improve?: string | null
          what_went_well?: string | null
        }
        Update: {
          action_items?: Json | null
          created_at?: string
          id?: string
          is_shared?: boolean | null
          lessons_learned?: string | null
          overall_rating?: number | null
          period_end?: string
          period_start?: string
          review_type?: string
          share_token?: string | null
          team_id?: string
          updated_at?: string
          user_id?: string
          what_could_improve?: string | null
          what_went_well?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "after_action_reviews_team_id_fkey"
            columns: ["team_id"]
            isOneToOne: false
            referencedRelation: "teams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "after_action_reviews_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      battle_plan_drafts: {
        Row: {
          created_at: string
          form_data: Json
          id: string
          team_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          form_data?: Json
          id?: string
          team_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          form_data?: Json
          id?: string
          team_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "battle_plan_drafts_team_id_fkey"
            columns: ["team_id"]
            isOneToOne: false
            referencedRelation: "teams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "battle_plan_drafts_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      battle_plans: {
        Row: {
          active: boolean | null
          created_at: string | null
          end_date: string
          id: string
          start_date: string
          team_id: string
          updated_at: string | null
          user_id: string
          vision: string
        }
        Insert: {
          active?: boolean | null
          created_at?: string | null
          end_date: string
          id?: string
          start_date: string
          team_id: string
          updated_at?: string | null
          user_id: string
          vision: string
        }
        Update: {
          active?: boolean | null
          created_at?: string | null
          end_date?: string
          id?: string
          start_date?: string
          team_id?: string
          updated_at?: string | null
          user_id?: string
          vision?: string
        }
        Relationships: [
          {
            foreignKeyName: "battle_plans_team_id_fkey"
            columns: ["team_id"]
            isOneToOne: false
            referencedRelation: "teams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "battle_plans_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      challenges: {
        Row: {
          created_at: string | null
          created_by: string | null
          description: string | null
          end_date: string
          id: string
          name: string
          start_date: string
          team_id: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          end_date: string
          id?: string
          name: string
          start_date: string
          team_id: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          end_date?: string
          id?: string
          name?: string
          start_date?: string
          team_id?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "challenges_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "challenges_team_id_fkey"
            columns: ["team_id"]
            isOneToOne: false
            referencedRelation: "teams"
            referencedColumns: ["id"]
          },
        ]
      }
      checkpoints: {
        Row: {
          created_at: string | null
          day_30: string | null
          day_60: string | null
          id: string
          plan_id: string
          quadrant: Database["public"]["Enums"]["quadrant_type"]
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          day_30?: string | null
          day_60?: string | null
          id?: string
          plan_id: string
          quadrant: Database["public"]["Enums"]["quadrant_type"]
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          day_30?: string | null
          day_60?: string | null
          id?: string
          plan_id?: string
          quadrant?: Database["public"]["Enums"]["quadrant_type"]
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "checkpoints_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "battle_plans"
            referencedColumns: ["id"]
          },
        ]
      }
      comments: {
        Row: {
          content: string
          created_at: string | null
          id: string
          post_id: string
          post_type: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string | null
          id?: string
          post_id: string
          post_type: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string | null
          id?: string
          post_id?: string
          post_type?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "comments_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      daily_logs: {
        Row: {
          created_at: string | null
          id: string
          log_date: string
          non_negotiables: Json | null
          objectives: Json | null
          tasks: Json | null
          team_id: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          log_date: string
          non_negotiables?: Json | null
          objectives?: Json | null
          tasks?: Json | null
          team_id: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          log_date?: string
          non_negotiables?: Json | null
          objectives?: Json | null
          tasks?: Json | null
          team_id?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "daily_logs_team_id_fkey"
            columns: ["team_id"]
            isOneToOne: false
            referencedRelation: "teams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "daily_logs_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      emergency_plans: {
        Row: {
          activated_at: string | null
          created_at: string | null
          deactivated_at: string | null
          description: string | null
          id: string
          name: string
          plan_details: Json
          team_id: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          activated_at?: string | null
          created_at?: string | null
          deactivated_at?: string | null
          description?: string | null
          id?: string
          name: string
          plan_details: Json
          team_id: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          activated_at?: string | null
          created_at?: string | null
          deactivated_at?: string | null
          description?: string | null
          id?: string
          name?: string
          plan_details?: Json
          team_id?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "emergency_plans_team_id_fkey"
            columns: ["team_id"]
            isOneToOne: false
            referencedRelation: "teams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "emergency_plans_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          ai_tone_preference: string | null
          avatar_url: string | null
          created_at: string | null
          display_name: string | null
          email: string | null
          id: string
          is_admin: boolean | null
          updated_at: string | null
        }
        Insert: {
          ai_tone_preference?: string | null
          avatar_url?: string | null
          created_at?: string | null
          display_name?: string | null
          email?: string | null
          id: string
          is_admin?: boolean | null
          updated_at?: string | null
        }
        Update: {
          ai_tone_preference?: string | null
          avatar_url?: string | null
          created_at?: string | null
          display_name?: string | null
          email?: string | null
          id?: string
          is_admin?: boolean | null
          updated_at?: string | null
        }
        Relationships: []
      }
      quadrant_objectives: {
        Row: {
          created_at: string | null
          id: string
          objective: string
          plan_id: string
          primary_tactic: string
          quadrant: Database["public"]["Enums"]["quadrant_type"]
          secondary_tactics: Json | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          objective: string
          plan_id: string
          primary_tactic: string
          quadrant: Database["public"]["Enums"]["quadrant_type"]
          secondary_tactics?: Json | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          objective?: string
          plan_id?: string
          primary_tactic?: string
          quadrant?: Database["public"]["Enums"]["quadrant_type"]
          secondary_tactics?: Json | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "quadrant_objectives_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "battle_plans"
            referencedColumns: ["id"]
          },
        ]
      }
      team_invite_codes: {
        Row: {
          created_at: string | null
          id: string
          invite_code: string
          team_id: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          invite_code: string
          team_id: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          invite_code?: string
          team_id?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "team_invite_codes_team_id_fkey"
            columns: ["team_id"]
            isOneToOne: true
            referencedRelation: "teams"
            referencedColumns: ["id"]
          },
        ]
      }
      team_members: {
        Row: {
          id: string
          joined_at: string | null
          role: Database["public"]["Enums"]["app_role"]
          status: string | null
          team_id: string
          user_id: string
        }
        Insert: {
          id?: string
          joined_at?: string | null
          role?: Database["public"]["Enums"]["app_role"]
          status?: string | null
          team_id: string
          user_id: string
        }
        Update: {
          id?: string
          joined_at?: string | null
          role?: Database["public"]["Enums"]["app_role"]
          status?: string | null
          team_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "team_members_team_id_fkey"
            columns: ["team_id"]
            isOneToOne: false
            referencedRelation: "teams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "team_members_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      teams: {
        Row: {
          created_at: string | null
          created_by: string | null
          description: string | null
          id: string
          logo_url: string | null
          name: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          id?: string
          logo_url?: string | null
          name: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          id?: string
          logo_url?: string | null
          name?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string | null
          id: string
          role: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          role: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          role?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_visions: {
        Row: {
          accountability_needs: string | null
          body_metrics: Json | null
          bucket_list: Json | null
          created_at: string
          financial_metrics: Json | null
          help_needed: string | null
          id: string
          life_categories: Json | null
          shared_with_team: boolean
          team_id: string | null
          updated_at: string
          user_id: string
          vision_1_year: string | null
          vision_10_year: string | null
          vision_5_year: string | null
          yearly_theme: string | null
        }
        Insert: {
          accountability_needs?: string | null
          body_metrics?: Json | null
          bucket_list?: Json | null
          created_at?: string
          financial_metrics?: Json | null
          help_needed?: string | null
          id?: string
          life_categories?: Json | null
          shared_with_team?: boolean
          team_id?: string | null
          updated_at?: string
          user_id: string
          vision_1_year?: string | null
          vision_10_year?: string | null
          vision_5_year?: string | null
          yearly_theme?: string | null
        }
        Update: {
          accountability_needs?: string | null
          body_metrics?: Json | null
          bucket_list?: Json | null
          created_at?: string
          financial_metrics?: Json | null
          help_needed?: string | null
          id?: string
          life_categories?: Json | null
          shared_with_team?: boolean
          team_id?: string | null
          updated_at?: string
          user_id?: string
          vision_1_year?: string | null
          vision_10_year?: string | null
          vision_5_year?: string | null
          yearly_theme?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "user_visions_team_id_fkey"
            columns: ["team_id"]
            isOneToOne: false
            referencedRelation: "teams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_visions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      weekly_metrics: {
        Row: {
          created_at: string | null
          id: string
          plan_id: string
          quadrant_data: Json
          submission_date: string | null
          user_id: string
          week_number: number
        }
        Insert: {
          created_at?: string | null
          id?: string
          plan_id: string
          quadrant_data: Json
          submission_date?: string | null
          user_id: string
          week_number: number
        }
        Update: {
          created_at?: string | null
          id?: string
          plan_id?: string
          quadrant_data?: Json
          submission_date?: string | null
          user_id?: string
          week_number?: number
        }
        Relationships: [
          {
            foreignKeyName: "weekly_metrics_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "battle_plans"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "weekly_metrics_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      wizard_progress: {
        Row: {
          collected_data: Json
          created_at: string
          current_quadrant: string | null
          current_step_index: number
          id: string
          messages: Json
          updated_at: string
          user_id: string
          wizard_type: string
        }
        Insert: {
          collected_data?: Json
          created_at?: string
          current_quadrant?: string | null
          current_step_index?: number
          id?: string
          messages?: Json
          updated_at?: string
          user_id: string
          wizard_type?: string
        }
        Update: {
          collected_data?: Json
          created_at?: string
          current_quadrant?: string | null
          current_step_index?: number
          id?: string
          messages?: Json
          updated_at?: string
          user_id?: string
          wizard_type?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      generate_invite_code: { Args: never; Returns: string }
      generate_share_token: { Args: never; Returns: string }
      get_team_member_profiles: {
        Args: { _team_id: string }
        Returns: {
          avatar_url: string
          display_name: string
          id: string
        }[]
      }
      has_role: { Args: { _role: string; _user_id: string }; Returns: boolean }
      is_active_team_member: {
        Args: { _team_id: string; _user_id: string }
        Returns: boolean
      }
      is_app_admin: { Args: never; Returns: boolean }
      is_team_leader_or_xo: {
        Args: { _team_id: string; _user_id: string }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "leader" | "xo" | "member"
      quadrant_type: "calibration" | "connection" | "condition" | "contribution"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["leader", "xo", "member"],
      quadrant_type: ["calibration", "connection", "condition", "contribution"],
    },
  },
} as const
