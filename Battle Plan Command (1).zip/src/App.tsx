import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./contexts/AuthContext";
import ProtectedRoute from "./components/ProtectedRoute";
import Auth from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import CreateTeam from "./pages/CreateTeam";
import LongTermVision from "./pages/LongTermVision";
import GoingDeeper from "./pages/GoingDeeper";
import TeamDetail from "./pages/TeamDetail";
import TeamAdmin from "./pages/TeamAdmin";
import CreateBattlePlan from "./pages/CreateBattlePlan";
import SubmitWeeklyMetrics from "./pages/SubmitWeeklyMetrics";

import TeamAnalytics from "./pages/TeamAnalytics";
import TeamPlans from "./pages/TeamPlans";
import JoinTeam from "./pages/JoinTeam";
import Admin from "./pages/Admin";
import AfterActionReview from "./pages/AfterActionReview";
import SharedReview from "./pages/SharedReview";
import Settings from "./pages/Settings";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <BrowserRouter>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <Routes>
            <Route path="/auth" element={<Auth />} />
            <Route
              path="/"
              element={
                <ProtectedRoute>
                  <Dashboard />
                </ProtectedRoute>
              }
            />
            <Route
              path="/teams/create"
              element={
                <ProtectedRoute>
                  <CreateTeam />
                </ProtectedRoute>
              }
            />
            <Route
              path="/teams/:teamId"
              element={
                <ProtectedRoute>
                  <TeamDetail />
                </ProtectedRoute>
              }
            />
            <Route
              path="/teams/:teamId/admin"
              element={
                <ProtectedRoute>
                  <TeamAdmin />
                </ProtectedRoute>
              }
            />
            <Route
              path="/battle-plans/create"
              element={
                <ProtectedRoute>
                  <CreateBattlePlan />
                </ProtectedRoute>
              }
            />
            <Route
              path="/battle-plans/edit/:id"
              element={
                <ProtectedRoute>
                  <CreateBattlePlan />
                </ProtectedRoute>
              }
            />
            <Route
              path="/battle-plans/:id/metrics"
              element={
                <ProtectedRoute>
                  <SubmitWeeklyMetrics />
                </ProtectedRoute>
              }
            />
            <Route
              path="/teams/:teamId/analytics"
              element={
                <ProtectedRoute>
                  <TeamAnalytics />
                </ProtectedRoute>
              }
            />
            <Route
              path="/teams/:teamId/plans"
              element={
                <ProtectedRoute>
                  <TeamPlans />
                </ProtectedRoute>
              }
            />
            <Route
              path="/teams/join"
              element={
                <ProtectedRoute>
                  <JoinTeam />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin"
              element={
                <ProtectedRoute>
                  <Admin />
                </ProtectedRoute>
              }
            />
            <Route
              path="/vision"
              element={
                <ProtectedRoute>
                  <LongTermVision />
                </ProtectedRoute>
              }
            />
            <Route
              path="/going-deeper"
              element={
                <ProtectedRoute>
                  <GoingDeeper />
                </ProtectedRoute>
              }
            />
            <Route
              path="/after-action-reviews"
              element={
                <ProtectedRoute>
                  <AfterActionReview />
                </ProtectedRoute>
              }
            />
            <Route
              path="/shared-review/:token"
              element={<SharedReview />}
            />
            <Route
              path="/settings"
              element={
                <ProtectedRoute>
                  <Settings />
                </ProtectedRoute>
              }
            />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </TooltipProvider>
      </AuthProvider>
    </BrowserRouter>
  </QueryClientProvider>
);

export default App;
